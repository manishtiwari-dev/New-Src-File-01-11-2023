import React from "react";
import Currency from "hooks/currency";
import { Trans } from "lang";
import { BadgeShow } from "component/UIElement/UIElement";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { useState } from "react";
import { ServiceSubscriptionStatusUrl } from "config";
import POST from "axios/post";
import Moment from "react-moment";
import Notify from "component/Notify";

function TransactionLog({ transactionLog }) {
  console.log("transactionLog", JSON.parse(transactionLog));

  const [transaction, setTransaction] = useState([]);
  const { apiToken, language } = useSelector((state) => state.login);

  useEffect(() => {
    let abortController = new AbortController();
    setTransaction(JSON.parse(transactionLog));
    return () => abortController.abort();
  }, [transactionLog]);

  const ChangeFunction = (quoteId, statusId) => {
    const editData = {
      api_token: apiToken,
      subs_txn_id: quoteId,
      approval_status: statusId,
    };
    POST(ServiceSubscriptionStatusUrl, editData)
      .then((response) => {
        const { message } = response.data;

        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };
  const statusColor = ["danger", "success"];

  const StatusChange = (quoteId, statusId) => {
    ChangeFunction(quoteId, statusId);
  };

  return (
    <div className="row">
      <div className="col-md-12">
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th scope="col">{Trans("INVOICE_NO", language)}</th>
                <th scope="col">{Trans("TRANSACTION_NO", language)}</th>
                <th scope="col">{Trans("PAYMENT_METHOD", language)}</th>
                <th scope="col">{Trans("PAYMENT_AMOUNT", language)}</th>
                <th scope="col">{Trans("APPROVAL_STATUS", language)}</th>
                <th scope="col">{Trans("PAYMENT_STATUS", language)}</th>
                <th scope="col">{Trans("PAYMENT_DATE", language)}</th>
                <th scope="col">{Trans("APPROVAL_DATE", language)}</th>

                <th scope="col">{Trans("ACTION", language)}</th>
              </tr>
            </thead>
            <tbody>
              {transaction ? (
                transaction.map((tr, idx) => {
                  return (
                    <tr key={idx}>
                      <th scope="row">{tr.invoice_no}</th>
                      <td>{tr.transaction_no}</td>
                      <td>{tr.payment_method_name}</td>
                      <td>{Currency("$", tr.payment_amount)}</td>

                      <td className="tx-center">
                        <select
                          className={`badge badge-${
                            statusColor[tr.approval_status]
                          }`}
                          value={tr.approval_status}
                          onChange={(e) => {
                            StatusChange(tr.subs_txn_id, e.target.value);
                          }}
                        >
                          <option value={0}>
                            {Trans("Pending", language)}
                          </option>
                          <option value={1}>
                            {Trans("Approved", language)}
                          </option>
                          <option value={2}>{Trans("Reject", language)}</option>
                        </select>
                      </td>
                      {/* <td>
                        <BadgeShow
                          type={tr.approval_status}
                          content={tr.approval_status}
                        />
                      </td> */}
                      <td>
                        <BadgeShow
                          type={tr.payment_status}
                          content={tr.payment_status}
                        />
                      </td>
                      <td>
                        <Moment format="DD/MM/YYYY">{tr.created_at}</Moment>
                      </td>
                      <td>
                        <Moment format="DD/MM/YYYY">{tr.approved_at}</Moment>
                      </td>
                      <td></td>
                    </tr>
                  );
                })
              ) : (
                <tr>No result found!</tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default TransactionLog;
