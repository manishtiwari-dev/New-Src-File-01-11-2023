import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { servicePlanGroupStoreUrl, ServicePlanCreateUrl } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  StatusSelect,
  IndexSelect,
  IsFeatured,
  Label,
} from "component/UIElement/UIElement";
import Select from "react-select";

import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import MyEditor from "component/MyEditor";
import { ErrorMessage } from "@hookform/error-message";

const Create = (props) => {
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(servicePlanGroupStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };
  const [contentloadingStatus, SetloadingStatus] = useState(false);
  const [currencyList, SetcurrencyList] = useState([]);

  const getAllData = () => {
    SetloadingStatus(true);
    const filterData2 = {
      api_token: apiToken,
      language: language,
    };

    POST(ServicePlanCreateUrl, filterData2)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetcurrencyList(data.currencyList);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };
  useEffect(() => {
    let abortController = new AbortController();
    getAllData();
    return () => abortController.abort(); //getAllData();
  }, []);

  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible>
          {error.msg}
        </Alert>
      )}
      <form
        action="#"
        onSubmit={handleSubmit(onSubmit)}
        noValidate>
        <Row>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("GROUP_NAME", language)}
                label={Trans("GROUP_NAME", language)}
                placeholder={Trans("GROUP_NAME", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register("group_name", {
                  required: Trans("GROUP_NAME_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage
                  errors={errors}
                  name="group_name"
                />
              </span>
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("GROUP_KEY", language)}
                label={Trans("GROUP_KEY", language)}
                placeholder={Trans("GROUP_KEY", language)}
                className="form-control"
                {...register("group_key", {})}
              />
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <IndexSelect
                id={Trans("PLAN_TRIAL", language)}
                label={Trans("PLAN_TRIAL", language)}
                placeholder={Trans("PLAN_TRIAL", language)}
                className="form-control"
                {...register("plan_trial")}
                defaultValue={0}
              />
            </FormGroup>
          </Col>

          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                type="number"
                id={Trans("TRIAL_DAYS", language)}
                label={Trans("TRIAL_DAYS", language)}
                placeholder={Trans("TRIAL_DAYS", language)}
                className="form-control"
                {...register("trial_day")}
              />
            </FormGroup>
          </Col>
          <Col col={12}>
            <FormGroup mb="20px">
              <Input
                type="hidden"
                id={Trans("CURRENCY", language)}
                label={Trans("CURRENCY", language)}
                placeholder={Trans("CURRENCY", language)}
                className="form-control"
                {...register("currency")}
              />

              <Select
                name={Trans("CURRENCY", language)}
                options={currencyList}
                className="basic-multi-select"
                classNamePrefix="select"
                onChange={(newValue, actionMeta) => {
                  // console.log(newValue);
                  setValue("currency", newValue.value);
                }}
              />
            </FormGroup>
          </Col>

          <Col col={4}>
            <LoaderButton
              formLoadStatus={formloadingStatus}
              btnName={Trans("SUBMIT", language)}
              className="btn btn-sm btn-bg btn-block"
            />
          </Col>
        </Row>
      </form>
    </>
  );
};

export default Create;
