import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { servicePlanUpdateUrl, servicePlanEditUrl } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  StatusSelect,
  Label,
  IsFeatured,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import Select from "react-select";
import Loading from "component/Preloader";
import MyEditor from "component/MyEditor";
import { ErrorMessage } from "@hookform/error-message";

const PlanEdit = (props) => {
  const { editData } = props;
  // const { grpId } = props;

  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
  } = useForm();

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [Background, setBackgroundColor] = useState("");

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    saveFormData.industry_id = MultiSelectItem;
    saveFormData.color = Background;

    POST(servicePlanUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [moduleList, SetmoduleList] = useState([]);
  const [defaultSelectValue, SetDefaultSelectValue] = useState();
  const [groupList, SetgrpList] = useState([]);
  const [editInfo, SeteditInfo] = useState("");

  const setValueToField = () => {
    const editInfo = {
      api_token: apiToken,
      plan_id: editData,
    };
    POST(servicePlanEditUrl, editInfo)
      .then((response) => {
        SetloadingStatus(false);

        const { data } = response.data;
        SeteditInfo(data.data_list);

        const fieldList = getValues();
        for (const key in fieldList) {
          // if (key === "color") {
          //   setValue(key, setBackgroundColor(data.data_list[key]));
          // } else {
          //   setValue(key, data.data_list[key]);
          // }

          console.log(data.data_list["color"]);
          setValue(key, data.data_list[key]);
        }
        //setting edit info to show select value
        SetgrpList(data);
        let color_select = "";
        color_select = data.data_list["color"];
        setValue("color", color_select);

        //  setValue("color", setBackgroundColor(data.data_list.color));
        setBackgroundColor(color_select);
        // console.log(data.data_list.color);
      })
      .catch((error) => {
        SetloadingStatus(false);
        alert(error.message);
      });
  };
  useEffect(() => {
    let abortController = new AbortController();
    setValueToField();
    return () => abortController.abort();
  }, []);

  const [MultiSelectItem, SetMultiSelectItem] = useState("");
  const handleMultiSelectChange = (newValue, actionMeta) => {
    console.log("newValue", newValue);
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    listArr = listArr.join(",");
    SetMultiSelectItem(listArr);
  };

  console.log(editInfo);

  return (
    <>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <>
          {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible>
              {error.msg}
            </Alert>
          )}
          <form
            action="#"
            onSubmit={handleSubmit(onSubmit)}
            noValidate>
            <input
              type="hidden"
              {...register("plan_id")}
            />
            <input
              type="hidden"
              {...register("group_id")}
              value={editInfo?.group_id}
            />
            <Row>
              <Col col={6}>
                <FormGroup mb="20px">
                  <Input
                    id={Trans("PLAN_NAME", language)}
                    label={Trans("PLAN_NAME", language)}
                    placeholder={Trans("PLAN_NAME", language)}
                    hint="Enter text" // for bottom hint
                    className="form-control"
                    {...register("plan_name", {
                      required: Trans("PLAN_NAME_REQUIRED", language),
                    })}
                  />
                  <span className="required">
                    <ErrorMessage
                      errors={errors}
                      name="plan_name"
                    />
                  </span>
                </FormGroup>
              </Col>

              <Col col={6}>
                <div class="form-group">
                  <label for="">
                    <b> {Trans("COLOR", language)}</b>
                  </label>
                  <div className="d-flex">
                    <input
                      type="color"
                      value={Background}
                      onChange={(e) => setBackgroundColor(e.target.value)}
                      style={{
                        height: "calc(1.5em + 0.9375rem + 2px)",
                      }}
                    />
                    <input
                      type="text"
                      defaultValue={Background}
                      className="form-control"
                      {...register("color")}
                    />
                  </div>
                </div>
              </Col>

              <Col col={12}>
                <FormGroup mb="20px">
                  <TextArea
                    id={`${Trans("PLAN_DESC", language)}`}
                    label={`${Trans("PLAN_DESC", language)}`}
                    placeholder={`${Trans("PLAN_DESC", language)}`}
                    className="form-control"
                    {...register(`plan_desc`)}
                  />
                </FormGroup>
              </Col>

              <Col col={4}>
                <LoaderButton
                  formLoadStatus={formloadingStatus}
                  btnName={Trans("UPDATE", language)}
                  className="btn btn-sm btn-bg btn-block"
                />
              </Col>
            </Row>
          </form>
        </>
      )}
    </>
  );
};

export default PlanEdit;
