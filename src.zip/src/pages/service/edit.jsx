import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import {
  servicePlanGroupUpdateUrl,
  servicePlanGroupEditUrl,
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  StatusSelect,
  Label,
  IsFeatured,
  IndexSelect,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import Select from "react-select";
import Loading from "component/Preloader";
import MyEditor from "component/MyEditor";
import { ErrorMessage } from "@hookform/error-message";

const Edit = (props) => {
  const { editData } = props;

  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
  } = useForm();

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(servicePlanGroupUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [moduleList, SetmoduleList] = useState([]);
  const [defaultSelectValue, SetDefaultSelectValue] = useState();
  const [selectedCurrencyList, SetselectedCurrencyList] = useState();
  const [currencyList, SetcurrencyList] = useState([]);

  // const setValueToField = () => {
  //   const editInfo = {
  //     api_token: apiToken,
  //     group_id: editData,
  //   };
  //   POST(servicePlanGroupEditUrl, editInfo)
  //     .then((response) => {
  //       SetloadingStatus(false);
  //       const { data } = response.data;

  //       SetcurrencyList(data.currencyList);
  //       SetselectedCurrencyList(data?.data_list.selected_currency);

  //         const fieldList = getValues();

  //       for (const key in fieldList) {
  //         setValue(key, data?.data_list[key]);
  //       }
  //       //setting edit info to show select value
  //     })
  //     .catch((error) => {
  //         SetloadingStatus(false);
  //       alert(error.message);
  //     });
  // };
  // useEffect(() => {
  //   let abortController = new AbortController();
  //   setValueToField();
  //   return () => abortController.abort();
  // }, []);

  const setValueToField = () => {
    const editInfo = {
      api_token: apiToken,
      group_id: editData,
    };
    POST(servicePlanGroupEditUrl, editInfo)
      .then((response) => {
        SetloadingStatus(false);
        const { data } = response.data;
        SetcurrencyList(data.currencyList);
        SetselectedCurrencyList(data?.data_list.selected_currency);

        const fieldList = getValues();

        for (const key in fieldList) {
          setValue(key, data?.data_list[key]);
        }
        //setting edit info to show select value
        setValue("currency", data?.data_list.selected_currency);
      })
      .catch((error) => {
        SetloadingStatus(false);
        alert(error.message);
      });
  };
  useEffect(() => {
    let abortController = new AbortController();
    setValueToField();
    return () => abortController.abort();
  }, []);

  const [MultiSelectItem, SetMultiSelectItem] = useState("");
  const handleMultiSelectChange = (newValue, actionMeta) => {
    console.log("newValue", newValue);
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    listArr = listArr.join(",");
    SetMultiSelectItem(listArr);
  };

  return (
    <>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <>
          {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible>
              {error.msg}
            </Alert>
          )}
          <form
            action="#"
            onSubmit={handleSubmit(onSubmit)}
            noValidate>
            <input
              type="hidden"
              {...register("group_id")}
            />
            <Row>
              <Col col={6}>
                <FormGroup mb="20px">
                  <Input
                    id={Trans("GROUP_NAME", language)}
                    label={Trans("GROUP_NAME", language)}
                    placeholder={Trans("GROUP_NAME", language)}
                    hint="Enter text" // for bottom hint
                    className="form-control"
                    {...register("group_name", {
                      required: Trans("GROUP_NAME_REQUIRED", language),
                    })}
                  />
                  <span className="required">
                    <ErrorMessage
                      errors={errors}
                      name="group_name"
                    />
                  </span>
                </FormGroup>
              </Col>
              <Col col={6}>
                <FormGroup mb="20px">
                  <Input
                    id={Trans("GROUP_KEY", language)}
                    label={Trans("GROUP_KEY", language)}
                    placeholder={Trans("GROUP_KEY", language)}
                    className="form-control"
                    {...register("group_key", {})}
                  />
                </FormGroup>
              </Col>
              <Col col={6}>
                <FormGroup mb="20px">
                  <IndexSelect
                    id={Trans("PLAN_TRIAL", language)}
                    label={Trans("PLAN_TRIAL", language)}
                    placeholder={Trans("PLAN_TRIAL", language)}
                    className="form-control"
                    {...register("plan_trial")}
                  />
                </FormGroup>
              </Col>

              <Col col={6}>
                <FormGroup mb="20px">
                  <Input
                    type="number"
                    id={Trans("TRIAL_DAYS", language)}
                    label={Trans("TRIAL_DAYS", language)}
                    placeholder={Trans("TRIAL_DAYS", language)}
                    className="form-control"
                    {...register("trial_day")}
                  />
                </FormGroup>
              </Col>
              {selectedCurrencyList === "" &&
              selectedCurrencyList === undefined ? (
                <Col col={12}>
                  <FormGroup mb="20px">
                    <Input
                      type="hidden"
                      id={Trans("CURRENCY", language)}
                      label={Trans("CURRENCY", language)}
                      placeholder={Trans("CURRENCY", language)}
                      className="form-control"
                      {...register("currency")}
                    />
                    <Select
                      name={Trans("CURRENCY", language)}
                      options={currencyList}
                      className="basic-multi-select"
                      classNamePrefix="select"
                      onChange={(newValue, actionMeta) => {
                        // console.log(newValue);
                        setValue("currency", newValue.value);
                      }}
                    />
                  </FormGroup>
                </Col>
              ) : (
                <Col col={12}>
                  <FormGroup mb="20px">
                    <Input
                      type="hidden"
                      id={Trans("CURRENCY", language)}
                      label={Trans("CURRENCY", language)}
                      placeholder={Trans("CURRENCY", language)}
                      className="form-control"
                      {...register("currency")}
                    />
                    {selectedCurrencyList && (
                      <Select
                        name={Trans("CURRENCY", language)}
                        options={currencyList}
                        defaultValue={selectedCurrencyList}
                        className="basic-multi-select"
                        classNamePrefix="select"
                        onChange={(newValue, actionMeta) => {
                          // console.log(newValue);
                          setValue("currency", newValue.value);
                        }}
                      />
                    )}
                  </FormGroup>
                </Col>
              )}

              {/* <Col col={12}>
            <FormGroup mb="20px">
              <Input
                type="hidden"
                id={Trans("CURRENCY", language)}
                label={Trans("CURRENCY", language)}
                placeholder={Trans("CURRENCY", language)}
                className="form-control"
                {...register("currency", 
                )}
              />
            {selectedCurrencyList && (
              <Select
                name={Trans("CURRENCY", language)}
                options={currencyList}
                defaultValue={selectedCurrencyList}
                className="basic-multi-select"
                classNamePrefix="select"
                onChange={(newValue, actionMeta) => {
                  // console.log(newValue);
                  setValue("currency", newValue.value);
                }}
              />
             )} 
            
            </FormGroup>
            </Col>  */}

              <Col col={4}>
                <LoaderButton
                  formLoadStatus={formloadingStatus}
                  btnName={Trans("UPDATE", language)}
                  className="btn btn-sm btn-bg btn-block"
                />
              </Col>
            </Row>
          </form>
        </>
      )}
    </>
  );
};

export default Edit;
