import React, { useState, useEffect } from "react";
import POST from "axios/post";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useForm, FormProvider } from "react-hook-form";
import {
    FormStoreUrl,
  tempUploadFileUrl,
  FormFieldUrl
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
  Anchor,
  StatusSelect,
  GalleryImagePreviewWithUpload,
} from "component/UIElement/UIElement";
// import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import Select from "react-select";
import WebsiteLink from "config/WebsiteLink";
import Field from "./component/Create/Field";
import Loading from "component/Preloader";
import { useFieldArray } from "react-hook-form";
import { Card, Button ,Alert} from "react-bootstrap";

import FeatherIcon from "feather-icons-react";
import { useNavigate } from "react-router-dom";

const Create = (props) => {
  const navigate = useNavigate();
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
 
  const methods = useForm({
    // defaultValues: {
    //     form_field: [{ field_label: "", field_name: "" ,field_type:"",field_width:"",placeholder:"", field_values:"",required:"" ,field_class:"",sort_order:"",validation_msg:""}],
     
    // },
  });



  
  const {
    register,
    handleSubmit,
    setValue,
    control,
    getValues,
    formState: { errors },
  } = methods;
  const [field, SetFeature] = useState([]);

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
     saveFormData.api_token = apiToken;
  
    // return "";

    POST(FormStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, data, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
          Notify(true, errObj.msg);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };

  const [onSelectLoad, SetonSelectLoad] = useState(false);
  const [fieldList, SetfieldList] = useState("");
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [editLoad, SeteditLoad] = useState(false);
  const [formType, SetformType] = useState("form_type");
  const [fieldTypeList,selectFieldType]=useState("");


  const Field_form = useFieldArray({
    control,
    name: "form_field",
  });

  const getFieldListBYFormType = (formType) => {
    SetonSelectLoad(true);
    const formData = {
      api_token: apiToken,
    
      form_type: formType,
    };
    POST(FormFieldUrl, formData)
      .then((response) => {
        const { status, data } = response.data;
      
        if (status) {
          SetloadingStatus(false);
          const { data } = response.data;

         // SeteditInfo(data);
          SetfieldList(data);
          selectFieldType(data[0]?.form_field)
        
          for (const key in fieldList) {
            setValue(key, data[key]);
          }

       let fieldlist=  (data[0]?.form_field);

          if (fieldlist !== undefined) {
            let field = [];
            for (let index = 0; index < fieldlist.length; index++) {
              const elem = fieldlist[index];
              field.push({
                field_label: elem.field_label,
                field_name: elem.field_name,
                field_type: elem.field_type,
                field_values: elem.field_values,
                field_class: elem.field_class,
                required: elem.required,
                field_width: elem.field_width,
                placeholder: elem.placeholder,
                validation_msg: elem.validation_msg,
                sort_order: elem.sort_order,
                editable:elem.editable
        
              });
            }

            Field_form.replace(field);
          }


          SetonSelectLoad(true);
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, error.message);
        console.error("There was an error!", error);
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    getFieldListBYFormType(formType);
    return () => abortController.abort();
  }, []);

  const [selectType, SetSelectType] = useState("");
  const [selectlabel, SetSelectLabel] = useState("field_name");

  // const form_field = useFieldArray({
  //   control,
  //   name: "form_field",
  // });




  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
       <FormProvider {...methods}>
                  <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
                    <Row>
                    <Col col={6}>
            <FormGroup>
              <Input
                id={Trans("FORM_NAME", language)}
                label={Trans("FORM_NAME", language)}
                placeholder={Trans("FORM_NAME", language)}
                className="form-control form-control-sm"
                {...register("form_name", {
                  required: Trans("FORM_NAME_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="form_name" />
              </span>
            </FormGroup>
          </Col>

          {/* <Col col={6}>
            <FormGroup>
              <Input
                id={Trans("FORM_SHORTCODE", language)}
                label={Trans("FORM_SHORTCODE", language)}
                placeholder={Trans("FORM_SHORTCODE", language)}
                className="form-control form-control-sm"
                {...register("form_shortcode", {
                  required: Trans("FORM_SHORTCODE_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="form_shortcode" />
              </span>
            </FormGroup>
          </Col>
        */}
          <Col col={6}>
          <FormGroup mb="20px">
          <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("FORM_TYPE", language)}
                >
                  {Trans("FORM_TYPE", language)}
                </Label>
              <select
                id="Status"
                label={Trans("STATUS", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register("form_type", {
                  required: Trans("FORM_TYPE_REQUIRED", language),
                })}
                onChange={(e) => getFieldListBYFormType(e.target.value)}
              >
               <option value=""> {Trans("SELECT_FORM_TYPE", language)}</option>
               
               <option value={1}>Enquiry</option>
               <option value={2}>Lead</option>
               <option value={3}>Ticket</option>
               <option value={4}>Custom</option>
        </select>
        <span className="required">
                <ErrorMessage errors={errors} name="form_type" />
              </span>
            </FormGroup>
          </Col>
         
          <br/>
        
          {/* <h6 className=" tx-semibold mg-b-0 text-center ml-4">
              NOTE:Please Use Categories Dropdown Key -CATEGORIES



                        </h6>{" "} */}
                  <b className=" ml-4">Note:-</b> Use below Keyword for dropdown list
                    Country - COUNTRY
                    Category - CATEGORY
                    Sevice - SERVICE
                    Menu - MENU       


            {/* {contentloadingStatus ?  <Loading /> :   <Field field={field}
               fieldList={fieldList[0]?.form_field}
               onSelectLoad={onSelectLoad}
                />} */}

              {contentloadingStatus ? "Loading..." : 
            
              <Col col={12}>
              <Card className="mb-3">
                <Card.Header as="h6">
                  {Trans("FORM_FIELD", language)}
                  <span style={{ float: "right" }}>
                    <button
                      type="button"
                      className="btn btn-sm btn-bg"
                      onClick={() => {
                        Field_form.append({});
                      }}
                    >
                      <FeatherIcon icon="plus" fill="white" />
                      {Trans("ADD_MORE_FIELD", language)}
                    </button>
                  </span>
                </Card.Header>
              
        
                <div className="table-responsive">
                  <table className="table">
                    <thead>
                      <tr>
                        <th> {Trans("LABEL", language)}</th>
                        <th>{Trans("FIELD_TYPE", language)}</th>
                         <th> {Trans("VALUES", language)}</th>
                        <th>{Trans("CLASS", language)}</th>
                        <th> {Trans("WIDTH", language)}</th>
                        <th>{Trans("PLACEHOLDER", language)}</th>
                        <th> {Trans("SORT_ORDER", language)}</th>
                        <th>{Trans("REQUIRED", language)}</th>
                        <th>{Trans("VALIDATION_MSG", language)}</th>
                      </tr>
                    </thead>
        
        
           
        
             {Field_form?.fields && (
                   
               <tbody>
              
            
                  {Field_form?.fields.map((item, index) => {

                    return (
                    <React.Fragment >
                      <tr>
                        <td>   
                      <input
                        {...register(`form_field.${index}.field_label`,
                        
                        {
                          required: Trans("FIELD_LABEL_REQUIRED", language),
                        }
                        
                        
                        )}
                        className="form-control  form-control-sm"
                        id={`slug-source`}
                        placeholder={Trans("FIELD_LABEL", language)}
                        // onKeyUp={() => {
                        //   myfun();
                        // }} 
                        defaultValue={item.field_label}
                      />
                      <span className="required">
                        <ErrorMessage
                          errors={errors}
                          name={`form_field.${index}.field_label`}
                        />
                      </span>
                 
                    </td>
                    
                  <td>  
               <select
              
                id={`form_field.${index}.field_type`}
                label={Trans("FIELD_TYPE", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm px-1"
                {...register(`form_field.${index}.field_type`,
        
                {
                  required: Trans("FIELD_TYPE_REQUIRED", language),
                }
        
                )}
                placeholder={Trans("FIELD_TYPE", language)}
              
                onChange={(event) => {
                  SetSelectType(event.target.value);
                }}
        
                // onChange={(e) => {
                //   selectFieldType(index, "fieldType", e.target.value);
                // }}
        
                defaultValue={item.field_type}
              >
               <option value="">{Trans("SELECT", language)}</option>
               <option value="text">Text</option>
               <option value="checkbox">Checkbox</option>
               <option value="dropdown">Dropdown</option>
               <option value="file">File</option>
               <option value="radio">Radio</option>
               <option value="email">Email</option>
               <option value="textarea">Textarea</option>
               <option value="submit">Submit</option>
               </select>
        
                <span className="required">
                        <ErrorMessage
                          errors={errors}
                          name={`form_field.${index}.field_type`}
                        />
                      </span></td>
                
                
                 <td>
                 <input
                      {...register(`form_field.${index}.field_values`)}
                      className="form-control form-control-sm px-1"
                      id={`form_field.${index}.field_values`}
                      placeholder="Multiple use comma seperate"
                      readOnly={selectType === "checkbox" || selectType === "dropdown" ? false : true}
                      defaultValue={item.field_values}
                    />
                 </td>
                
                 <td>
                 <input
                      {...register(`form_field.${index}.field_class`)}
                      className="form-control form-control-sm px-1"
                      id={`form_field.${index}.field_values`}
                      placeholder={Trans("FIELD_CLASS", language)}
                      defaultValue={item.field_class}
                    />
                 </td>
                 
                 <td>
                 <select
                id="FIELD_WIDTH"
                label={Trans("FIELD_WIDTH", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm px-1"
                {...register(`form_field.${index}.field_width`,
                
                {
                  required: Trans("field_width_REQUIRED", language),
                }
                
                )}
                placeholder={Trans("FIELD_WIDTH", language)}
                defaultValue={item.field_width}
              >
               <option value="">{Trans("SELECT", language)}</option>
               <option value="100">100</option>
               <option value="75">75</option>
               <option value="50">50</option>
               <option value="33">33</option>
               <option value="25">25</option>
               <option value="20">20</option>
            
        
             </select>
                 </td>
                 
                 <td>
                 <input
                        {...register(`form_field.${index}.placeholder`)}
                        className="form-control form-control-sm px-1"
                        id={`form_field.${index}.placeholder`}
                        placeholder={Trans("Placeholder", language)}
                        defaultValue={item.placeholder}
                      />
                     
                 </td>
                  <td><input
                       type="number"
                        {...register(`form_field.${index}.sort_order`)}
                        className="form-control  form-control-sm"
                        id={`form_field.${index}.sort_order`}
                        placeholder={Trans("SORT_ORDER", language)}
                        defaultValue={item.sort_order}
                      /></td>
               <td>        <select
                id="REQUIRED"
                label={Trans("REQUIRED", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register(`form_field.${index}.required`)}
                placeholder={Trans("REQUIRED", language)}
                defaultValue={item.required}
              >
               <option value="">{Trans("SELECT", language)}</option>
               <option value="1">Yes</option>
               <option value="0">No</option>
             </select></td>
             <td>
                 <input
                        {...register(`form_field.${index}.validation_msg`)}
                        className="form-control form-control-sm px-1"
                        id={`form_field.${index}.validation_msg`}
                        placeholder={Trans("VALIDATION_MSG", language)}
                        defaultValue={item.validation_msg}
                      />
                     
                 </td>
        


                            
                 {item.editable === 0 ?
           <td>
            
           </td>
           :
           <td>
           <Col col={1} className="px-1">
                 <span style={{ lineHeight: "42px" }}>
                  
                   <FeatherIcon
                     icon="x-square"
                     color="red"
                     onClick={() => Field_form.remove(index)}
                     size={20}
                   />
                 </span>
               </Col>
               </td>
           
           } 




{/* 
                                   
                  <td>  
              <Col col={1} className="px-1">
                    <span style={{ lineHeight: "42px" }}>
                      <FeatherIcon
                        icon="x-square"
                        color="red"
                        onClick={() => Field_form.remove(index)}
                        size={20}
                      />
                    </span>
                  </Col>
                  </td> */}



                      </tr>
                    </React.Fragment>
                   );
                  })}
            </tbody>
              )}
            
          </table>
                </div>
              </Card>
            </Col>
              
              
              
              } 
                  
                 {/* <Field field={field}
                        fieldTypeList={fieldList[0]?.form_field}
                        onSelectLoad={onSelectLoad}
                        
                   /> */}

          
                      <Col col={4} className="mt-2 text-center">
                        <LoaderButton
                          formLoadStatus={formloadingStatus}
                          btnName={Trans("SUBMIT", language)}
                          className="btn btn-sm btn-bg btn-block"
                        />
                      </Col>
                      <br />
                    </Row>
                  </form>
                </FormProvider>
    </>
  );
};

export default Create;
