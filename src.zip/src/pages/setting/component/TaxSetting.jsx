import React from "react";

function TaxSetting() {
  return <></>;
}

export default TaxSetting;
