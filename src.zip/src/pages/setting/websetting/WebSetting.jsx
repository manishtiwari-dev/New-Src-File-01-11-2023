import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { WebSettingUrl, WebSettingUpdateUrl,SuperGeneralSettingUrl } from "config";
import POST from "axios/post";
import { useSelector,useDispatch } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Create from "./Create";
import {
  updateLangState,
  updateSuperSettingState,
} from "redux/slice/loginSlice";

import {
  PageWebSetting,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Label,
  Input,
} from "component/UIElement/UIElement";
import { useForm, useFieldArray, FormProvider } from "react-hook-form";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { ErrorMessage } from "@hookform/error-message";
import EditComponent from "./EditComponent";

function WebSetting() {
  // const { langid, langKey } = useParams();
  const dispatch = useDispatch();
  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const [listData, SetlistData] = useState([]);
  const [HelperData, SetHelperData] = useState([]);

  const methods = useForm();

  const {
    register,
    control,
    formState: { errors },
    handleSubmit,
    reset,
  } = methods;

  async function getGeneralSetting(lang) {
    await POST(SuperGeneralSettingUrl, {
      language: lang,
      lang_key: "backend",
    })
      .then((response) => {
        const dataVal = response.data.data.language_data.lang_value;
        const setting_data = response.data.data.setting_data;
        const formData = {
          lang: language,
          langDetails: dataVal,
        };
        dispatch(updateLangState(formData));
        dispatch(updateSuperSettingState(setting_data));
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  }
  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    formData.api_token = apiToken;

    console.log("listData", listData);
    console.log("formData", formData);
    let settingdata = [];
    /*  combine all set to settingdata */
    for (let index = 0; index < listData.length; index++) {
      const grpId = listData[index].group_id;
      const NameId = "set_" + grpId;
      const set = formData[NameId];
      for (let setK = 0; setK < set.length; setK++) {
        settingdata.push(set[setK]);
      }
      delete formData[NameId];
    }

    formData.settingdata = settingdata;

    POST(WebSettingUpdateUrl, formData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message ,data} = response.data;
        if (status) {
          Notify(true, Trans(message, language));
          // if language updated
          let lang = language;
          if (data.hasOwnProperty("default_language"))
            lang = data["default_language"];

          getGeneralSetting(lang);
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          Notify(true, Trans(errObj.msg, language));
          // setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(true, Trans(error.message, language));
      });
  };


  const loadSettingData = () => {
    const filterData = {
      api_token: apiToken,
    };
    POST(WebSettingUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetlistData(data.data_list);
          SetHelperData(data.helperData);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  useEffect(() => {
    
    document.title = "Web Setting | WorkerMan";
    let abortController = new AbortController();
    loadSettingData();
    return () => abortController.abort();
  }, []);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  useEffect(() => {}, [listData]);

  
  return (
    <Content>
      <CheckPermission PageAccess={PageWebSetting} PageAction={PreView}>
        {contentloadingStatus ? (
          <Loading />
        ) : (
          <React.Fragment>
           

            <div className="row row-xs">
              <div className="col-sm-12 col-lg-12">
              <CheckPermission PageAccess={PageWebSetting} PageAction={PreView}>
                  <div className="card" id="custom-user-list">
                    <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                      <h6 className=" tx-semibold mg-b-0">
                        {Trans("SETTING_LIST", language)}
                      </h6>
                      <div className="d-none d-md-flex">
                        {userType !== "subscriber" && (
                          <Button variant="primary" onClick={handleModalShow}>
                            <FeatherIcon
                              icon="plus"
                              fill="white"
                              className="wd-10 mg-r-5"
                            />
                            {Trans("ADD_SETTING_KEY", language)}
                          </Button>
                        )}
                      </div>
                    </div>

                    <div className="card-body">
                      <FormProvider {...methods}>
                        <form
                          action="#"
                          onSubmit={handleSubmit(onSubmit)}
                          noValidate
                        >
                          <Row>
                            <Col col={12}>
                              <EditComponent
                                fieldKey={listData}
                                HelperData={HelperData}
                              />
                            </Col>
                          </Row>

                          <Row>
                            <Col col={3}>
                              <LoaderButton
                                formLoadStatus={formloadingStatus}
                                btnName={Trans("UPDATE", language)}
                                className="btn btn-sm btn-bg btn-block"
                              />
                            </Col>
                          </Row>
                        </form>
                      </FormProvider>
                    </div>
                  </div>
                </CheckPermission>
              </div>
            </div>
          </React.Fragment>
        )}
      </CheckPermission>

      {/* add modal */}
      <Modal show={show} onHide={handleModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("ADD_SETTING_KEY", language)}</Modal.Title>
          <Button variant="danger" onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Create
            loadSettingData={loadSettingData}
            handleModalClose={handleModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
    </Content>
  );
}

export default WebSetting;
