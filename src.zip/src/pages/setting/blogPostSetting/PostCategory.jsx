import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import {
  PostCategoryListUrl,
  BlogPostDestroyUrl,
  PostCategoryChangeStatusUrl,
  categoryIsFeaturedUrl,
  PostCategorySortOrderUrl,
} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import Pagination from "component/pagination/index";
import ExportButton from "component/ExportButton";
import SearchBox from "component/SearchBox";
import RecordPerPage from "component/RecordPerPage";
import Table from "./component/CategoryTable";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { BlogPostSetting } from "config/WebsiteUrl";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Create from "./CategoryCreate";
import Edit from "./CategoryEdit";
import ModalImage from "react-modal-image-responsive";

import {
  PostSetting,
  PreAdd,
  PreView,
  PreExport,
  SuperPostSetting,
} from "config/PermissionName";
import {
  Col,
  BadgeShow,
  IconButton,
  Anchor,
} from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";

function Index() {
  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [dataList, SetdataList] = useState([]);
  const [filterDataList, SetfilterDataList] = useState([]);
  const [Pagi, SetPagi] = useState(0);
  const [currPage, SetcurrPage] = useState(0);
  const [searchItem, SetSEarchItem] = useState("");
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");
  const [perPageItem, SetPerPageItem] = useState("");
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const showColumn = [
    { label: Trans("SL_NO", language), field: "category_id", sort: true },
    {
      label: Trans("CATEGORY_IMAGE", language),
      field: "categories_image",
      sort: true,
      field_type: "image",
    },
    {
      label: Trans("CATEGORY_NAME", language),
      field: "category_name",
      sort: false,
    },
    { label: Trans("STATUS", language), field: "status", sort: false },
    {
      label: Trans("ACTION", language),
      field: "action",
      action_list: ["edit_fun", "changeStatus"],
      sort: false,
    },
  ];

  const getData = (pagev, perPageItemv, searchData, sortBys, OrderBy) => {
    SetloadingStatus(true);
    const filterData = {
      api_token: apiToken,
      page: pagev,
      perPage: perPageItemv,
      search: searchData,
      sortBy: sortBys,
      orderBY: OrderBy,
      language: language,
    };
    POST(PostCategoryListUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetdataList(data.data);
          SetPagi(data.total_page);
          SetcurrPage(data.current_page);
          SetPerPageItem(data.per_page);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  const filterItem = (name, value, other) => {
    switch (name) {
      case "perpage":
        SetloadingStatus(true);
        const per = Number(value);
        SetPerPageItem(per);
        getData(1, per, searchItem, sortByS, orderByS);
        break;
      case "searchbox":
        SetSEarchItem(value);
        getData(1, perPageItem, value, sortByS, orderByS);
        break;
      case "sortby":
        SetOrderByS(other);
        SetsortByS(value);
        getData(1, perPageItem, searchItem, value, other);
        break;
      case "pagi":
        SetcurrPage(value);
        getData(value, perPageItem, searchItem, sortByS, orderByS);
        break;
      default:
        getData(currPage, perPageItem, searchItem, sortByS, orderByS);
        break;
    }
  };

  useEffect(() => {
    document.title = "Blog Setting | WorkerMan";
    let abortController = new AbortController();
    getData(1, perPageItem, searchItem, sortByS, orderByS);
    return () => abortController.abort();
  }, []);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  const [showSubCat, setShowSubCat] = useState(false);
  const handleSubcatModalClose = () => setShowSubCat(false);
  const handleSubcatModalShow = () => setShowSubCat(true);

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

  // const editFun = (editId) => {
  //   setEditModalShow(true);
  //   SetEditData(editId);

  // };

  const editFunction = (updateId) => {
    SetEditData(updateId);
    setEditModalShow(true);
  };
  const deleteItem = (deleteID) => {
    const infoData = {
      api_token: apiToken,
      post_id: deleteID,
    };
    POST(BlogPostDestroyUrl, infoData)
      .then((response) => {
        const { message } = response.data;
        filterItem("refresh", "", "");
        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };

  const ChangeFunction = (update_id) => {
    const editData = {
      api_token: apiToken,
      category_id: update_id,
    };
    POST(PostCategoryChangeStatusUrl, editData)
      .then((response) => {
        const { message } = response.data;
        filterItem("refresh", "", "");
        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };

  const ChangeIsFeatureFunction = (quoteId, statusId) => {
    const editData = {
      api_token: apiToken,

      categories_id: quoteId,
      is_featured: statusId,
    };
    POST(categoryIsFeaturedUrl, editData)
      .then((response) => {
        const { message } = response.data;
        filterItem("refresh", "", "");
        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };

  const UpdateOrderStatus = (update_id, sortOrder) => {
    const editData = {
      api_token: apiToken,
      category_id: update_id,
      sort_order: sortOrder,
    };
    POST(PostCategorySortOrderUrl, editData)
      .then((response) => {
        const { message } = response.data;
        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };

  const page_access = userType == "subscriber" ? PostSetting : SuperPostSetting;

  return (
    <Content>
      <CheckPermission
        PageAccess={page_access}
        PageAction={PreView}>
        <>
          <div
            className="card"
            id="custom-user-list">
            <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
              <h6 className=" tx-semibold mg-b-0">
                {Trans("POSTS_CATEGORY_LIST", language)}
              </h6>
              <div className=" d-md-flex">
                <CheckPermission
                  PageAccess={page_access}
                  PageAction={PreAdd}>
                  <Button
                    variant=""
                    className="btn-sm btn-bg"
                    onClick={handleModalShow}>
                    <FeatherIcon
                      icon="plus"
                      fill="white"
                      className="wd-10 mg-r-5"
                    />
                    {Trans("ADD_POST_CATEGORY", language)}
                  </Button>
                </CheckPermission>

                <Anchor
                  className="btn btn-sm btn-bg btn-xs btn-icon py-2"
                  path={WebsiteLink(BlogPostSetting)}>
                  <FeatherIcon
                    //   icon="corner-down-left"
                    className="wd-10 mg-r-5 "
                  />
                  {Trans("GO_BACK", language)}
                </Anchor>
              </div>
            </div>

            {/* END CARD HEADER */}

            <div className="card-body">
              <div className="table-responsive menu_list ">
                <table
                  className="table table-center  mb-0 "
                  
                  >
                  <thead>
                    <tr>
                      <th className="text-center">
                        {Trans("SL_NO", language)}
                      </th>
                      <th className="text-center">
                        {Trans("CATEGORY_NAME", language)}
                      </th>
                      <th className="text-center">
                        {Trans("IMAGE", language)}
                      </th>
                      <th className="text-center">
                        {Trans("STATUS", language)}
                      </th>
                      <th className="text-center">
                        {Trans("SORT_ORDER", language)}
                      </th>
                      <th className="text-center">
                        {Trans("ACTION", language)}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                  {dataList &&
                    dataList.map((cat, idx) => {
                      return (
                        <>
                  
                            <tr>
                              <td className="text-center">{idx + 1}</td>
                              <td className=" fw-bold ">
                                <FeatherIcon
                                  style={{
                                    cursor: "pointer",
                                  }}
                                  icon="arrow-down-circle"
                                  size={13}
                                />
                                {cat.category_name}
                              </td>
                              <td className=" text-center fw-bold">
                                <ModalImage
                                  small={cat.image}
                                  large={cat.image}
                                  height="10"
                                  width="10"
                                  className="img50"
                                />
                              </td>

                              <td className="text-center">
                                <div className="custom-control custom-switch">
                                  <input
                                    onClick={() =>
                                      ChangeFunction(cat.category_id)
                                    }
                                    type="checkbox"
                                    class="custom-control-input"
                                    id={`section${cat.category_id}`}
                                    checked={cat.status === 0 ? "" : "checked"}
                                  />
                                  <label
                                    className="custom-control-label"
                                    For={`section${cat.category_id}`}></label>
                                </div>
                              </td>

                              <td className="text-center fw-bold">
                                <input
                                  type="number"
                                  name=""
                                  id=""
                                  defaultValue={cat.sort_order}
                                  style={{ width: "60px", textAlign: "center" }}
                                  onBlur={(e) => {
                                    UpdateOrderStatus(
                                      cat.category_id,
                                      e.target.value
                                    );
                                  }}
                                />
                              </td>

                              <td className="text-center">
                                <IconButton
                                  color="primary"
                                  onClick={() =>
                                    editFunction(cat?.category_id)
                                  }>
                                  <FeatherIcon
                                    icon="edit-2"
                                    fill="white"
                                    onClick={() =>
                                      editFunction(cat?.category_id)
                                    }
                                  />
                                </IconButton>{" "}
                              </td>
                            </tr>

                            {cat?.sub_cat &&
                              cat?.sub_cat.map((parentdata, index) => {
                                return (
                                  <>
                                    <tr>
                                      <td className="text-center">
                                        {index + 1}
                                      </td>

                                      <td className="">
                                        <FeatherIcon
                                          style={{
                                            cursor: "pointer",
                                          }}
                                          icon="arrow-right"
                                          size={13}
                                        />

                                        {parentdata.category_name}
                                      </td>

                                      <td className="text-center">
                                        <ModalImage
                                          small={parentdata.image}
                                          large={parentdata.image}
                                          height="10"
                                          width="10"
                                          className="img50"
                                        />
                                      </td>

                                      <td className="text-center">
                                        <div className="custom-control custom-switch">
                                          <input
                                            onClick={() =>
                                              ChangeFunction(
                                                parentdata.category_id
                                              )
                                            }
                                            type="checkbox"
                                            class="custom-control-input"
                                            id={`section${parentdata.category_id}`}
                                            checked={
                                              parentdata.status === 0
                                                ? ""
                                                : "checked"
                                            }
                                          />
                                          <label
                                            className="custom-control-label"
                                            For={`section${parentdata.category_id}`}></label>
                                        </div>
                                      </td>

                                      <td className="text-center">
                                        <input
                                          type="number"
                                          name=""
                                          id=""
                                          defaultValue={parentdata.sort_order}
                                          style={{
                                            width: "60px",
                                            textAlign: "center",
                                          }}
                                          onBlur={(e) => {
                                            UpdateOrderStatus(
                                              parentdata.category_id,
                                              e.target.value
                                            );
                                          }}
                                        />
                                      </td>

                                      <td className="text-center">
                                        <IconButton
                                          color="primary"
                                          onClick={() =>
                                            editFunction(
                                              parentdata?.category_id
                                            )
                                          }>
                                          <FeatherIcon
                                            icon="edit-2"
                                            fill="white"
                                            onClick={() =>
                                              editFunction(
                                                parentdata?.category_id
                                              )
                                            }
                                          />
                                        </IconButton>{" "}
                                      </td>
                                    </tr>
                                  </>
                                );
                              })}
                        
                        </>
                      );
                    })}
                      </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      </CheckPermission>

      {/* add modal */}
      <Modal
        show={show}
        onHide={handleModalClose}
        size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("ADD_POST_CATEGORY", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Create
            filterItem={filterItem}
            handleModalClose={handleModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* edit modal */}
      <Modal
        show={editModalShow}
        onHide={handleEditModalClose}
        size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("UPDATE_POST_CATEGORY", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Edit
            editData={editData}
            filterItem={filterItem}
            handleModalClose={handleEditModalClose}
          />
        </Modal.Body>
      </Modal>
    </Content>
  );
}

export default Index;
