import React, { useState } from "react";
import POST from "axios/post";
import { useForm, FormProvider } from "react-hook-form";
import { useParams } from "react-router-dom";
import {
    PostTagUpdateUrl,
    PostTagEditUrl,
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import Select from "react-select";
import { useNavigate } from "react-router-dom";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  StatusSelect ,
  Anchor,
  Label,
  GalleryImagePreviewWithUploadWithItem,
} from "component/UIElement/UIElement"
import Loading from "component/Preloader";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { useEffect } from "react";
import { ErrorMessage } from "@hookform/error-message";

const Edit = (props) => {
  const { proId } = useParams();
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const navigate = useNavigate();

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const { editData } = props;

  const [editProAttribute, SetEditProAttribute] = useState();
  const [editLoad, SeteditLoad] = useState(false);

  const methods = useForm();

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    getValues,
  } = methods;

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
  

    const saveFormData = formData;
    saveFormData.api_token = apiToken;
  

    POST(PostTagUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message, data } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };
  
  const [sectionListing, SetSectionListing] = useState([]);

  const [editInfo, SeteditInfo] = useState("");
  useEffect(() => {
    let abortController = new AbortController();
    function setValueToField() {
      const editInfo = {
        api_token: apiToken,
        tags_id: editData,
      };
      POST(PostTagEditUrl, editInfo)
        .then((response) => {
          SetloadingStatus(false);
          const { data } = response.data;
          
          SeteditInfo(data.data_list);
          SetSectionListing(data.parent_type);

          const fieldList = getValues();
          for (const key in fieldList) {
        
            setValue(key, data.data_list[key]);
          }
          SeteditLoad(true);
        })
        
        .catch((error) => {
            SetloadingStatus(false);
          alert(error.message);
        });
    }
    setValueToField();
    return () => {
      // setValueToField();
      abortController.abort();
    };
  }, []);

 
  console.log(editInfo);
  return (
    <>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <>
          {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible
            >
              {error.msg}
            </Alert>
          )}
                        <FormProvider {...methods}>
                  <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
                    <input type="hidden" {...register("tags_id")} />
                    <Row>

                    <Col col={6}>
            <FormGroup>
              <Input
                id={Trans("TAG_NAME", language)}
                label={Trans("TAG_NAME", language)}
                placeholder={Trans("TAG_NAME", language)}
                className="form-control form-control-sm"
                {...register("tags_name", {
                  required: Trans("TAG_NAME_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="tags_name" />
              </span>
            </FormGroup>
                    </Col>


      
          <Col col={6}>
            <FormGroup mb="20px">
              <StatusSelect
                id="Status"
                label={Trans("STATUS", language)}
                defaultValue={1}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register("status", {
                  required: Trans("STATUS_REQUIRED", language),
                })}
              />
            
            </FormGroup>
          </Col>
      
          <br/>
                     
                    
                   
                      <Col col={4} className="mt-2">
                        <LoaderButton
                          formLoadStatus={formloadingStatus}
                          btnName={Trans("UPDATE", language)}
                          className="btn btn-sm btn-bg btn-block"
                        />
                      </Col>
                      <br />
                    </Row>
                  </form>
                  </FormProvider>
        </>
      )}
    </>
  );
};

export default Edit;
