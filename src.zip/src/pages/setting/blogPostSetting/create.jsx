import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import {
  PostSetting,
  PreAdd,
  PreView,
  PreExport,
  SuperPostSetting,
} from "config/PermissionName";

import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { useForm } from "react-hook-form";
import {
  BlogPostStoreUrl,
  BlogPostCreateUrl,
  tempUploadFileUrl,
} from "config/index";
import { BlogPostSetting } from "config/WebsiteUrl";
import { useNavigate } from "react-router-dom";
import Moment from "react-moment";
import Select from "react-select";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  StatusSelect,
  TextArea,
  Label,
} from "component/UIElement/UIElement";
import { Alert, Tab, Tabs } from "react-bootstrap";
import { ErrorMessage } from "@hookform/error-message";
import ContentEditor from "component/ContentEditor";


const Create = (props) => {
  const { apiToken, language, userType } = useSelector((state) => state.login);

  const navigate = useNavigate();

  const [key, setKey] = useState("default_language");
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(false);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(BlogPostStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });

          Notify(true, Trans(message, language));
          if (userType === "subscriber") {
            navigate(`/blog-setting`);
          }
          else {
            navigate("/superadmin/blog-setting");
          }
        } else {
          var errObj = {
            status: false,
            msg: "",
            type: "danger",
          };
          Notify(false, Trans(message, language));

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };

  const [langList, SetlangList] = useState([]);
  const [dates, SetDate] = useState([]);
  const [catList, SetCatList] = useState([]);
  const [tagList, SetTagList] = useState([]);
  const [authorList, SetauthorList] = useState([]);

  // useEffect(() => {
  //   let abortController = new AbortController();
  //   const formData = {
  //     api_token: apiToken,
  //     language: language,
  //   };
  //   POST(BlogPostCreateUrl, formData)
  //     .then((response) => {
  //       const { status, data } = response.data;
  //       if (status) {
  //         SetlangList(data.language);
  //         SetCatList(data.postCategory);
  //         SetTagList(data.postTag);
  //         SetauthorList(data);


  //       } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
  //     })
  //     .catch((error) => {
  //       Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
  //     });
  //   return () => abortController.abort();
  // }, []);



  const DataLoad = () => {
    const filterData = {
      api_token: apiToken,
      language: language,
    };
    POST(BlogPostCreateUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetlangList(data.language);
          SetCatList(data.postCategory);
          SetTagList(data.postTag);
          SetauthorList(data.postAuthor);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    DataLoad();
    return () => abortController.abort();
  }, []);




  const [updateformloadingStatus, SetupdateformloadingStatus] = useState(false);


  const HandleDocumentUpload = (event, previewUrlId, StoreID) => {
    SetupdateformloadingStatus(true);

    if (event.target.files[0] === "" || event.target.files[0] === undefined)
      return;

    var readers = new FileReader();
    readers.onload = function (e) {
      document.getElementById(
        previewUrlId
      ).innerHTML = `<img src=${e.target.result} height="100" />`;
    };
    readers.readAsDataURL(event.target.files[0]);

    // upload temp image and bind value to array
    const formdata = new FormData();
    // SetupdateformloadingStatus(false);

    formdata.append("api_token", apiToken);
    formdata.append("fileInfo", event.target.files[0]);
    formdata.append("images_type", 1);
    POST(tempUploadFileUrl, formdata)
      .then((response) => {
        SetupdateformloadingStatus(false);

        setValue(StoreID, response.data.data);
        //    SettempFile( response.data.data);
        // SetupdateformloadingStatus(false);


      })
      .catch((error) => {
        SetupdateformloadingStatus(false);

        Notify(false, error.message);
      });
  };
  const currntDate = new Date();

  const current = new Date();
  const date = `${current.getDate()}/${current.getMonth() + 1
    }/${current.getFullYear()}`;

  console.log(date);

  const slugfun = () => {
    var a = document.getElementById("slug-source").value;
    var b = a
      .toLowerCase()
      .replace(/ /g, "-")
      .replace(/[^\w-]+/g, "");
    document.getElementById("slug-target").value = b;
  };

  console.log(authorList);

  const page_access = userType == 'subscriber' ? PostSetting : SuperPostSetting;





  return (
    <Content>
      <div className="row row-xs">
        <div className="col-sm-12 col-lg-12">
          <CheckPermission
            PageAccess={page_access}
            PageAction={PreView}>
            <div
              className="card"
              id="custom-user-list">
              <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                <h6 className=" tx-semibold mg-b-0">
                  {Trans("ADD_POSTS", language)}
                </h6>
                <div className=" d-md-flex">

                  <Anchor
                    className="btn btn-sm btn-bg pd-3"
                    path={WebsiteLink(BlogPostSetting)}>
                    <FeatherIcon
                      //    icon="corner-down-left"
                      className="wd-10 mg-r-5"
                    />
                    {Trans("GO_BACK", language)}
                  </Anchor>

                </div>
              </div>
              <div className="card-body">
                <div className="row col-md-12">
                  {error.status && (
                    <Alert
                      variant={error.type}
                      onClose={() =>
                        setError({ status: false, msg: "", type: "" })
                      }
                      dismissible>
                      {error.msg}
                    </Alert>
                  )}
                  <form
                    action="#"
                    onSubmit={handleSubmit(onSubmit)}
                    noValidate>

                    <Col col={12}>
                      <fieldset className="form-fieldset">
                        <legend>
                          {Trans("BLOG_INFORMATION", language)}
                        </legend>
                        <Row>


                          <Col col={12}>
                            <Tabs
                              id="controlled-tab-example"
                              onSelect={(k) => setKey(k)}
                              className="mb-3">
                              {langList &&
                                langList.map((lang) => {
                                  const {
                                    languages_code,
                                    languages_id,
                                    languages_name,
                                  } = lang;

                                  return (
                                    <Tab
                                      eventKey={languages_code}
                                      key={languages_id}
                                      title={languages_name}>
                                      <Row>
                                        <Col col={12}>
                                          <FormGroup mb="20px">
                                            <Input
                                              id={`slug-source`}
                                              label={`${Trans(
                                                "POST_TITLE",
                                                language
                                              )} (${languages_code})`}
                                              placeholder={`${Trans(
                                                "POST_TITLE",
                                                language
                                              )} (${languages_code})`}
                                              hint="Enter text" // for bottom hint
                                              className="form-control"
                                              {...register(
                                                `post_title_${languages_id}`
                                              )}
                                              onKeyUp={() => {
                                                slugfun();
                                              }}
                                            />
                                          </FormGroup>
                                        </Col>
                                        {/* <Col col={6}>
                                      <FormGroup mb="20px">
                                        <Input
                                          id={`slug-target`}
                                          label={`${Trans(
                                            "POST_SLUG",
                                            language
                                          )}`}
                                          placeholder={`${Trans(
                                            "POST_SLUG",
                                            language
                                          )} (${languages_code})`}
                                          hint="Enter text" // for bottom hint
                                          className="form-control"
                                          {...register(`slug`, {})}
                                        />
                                      </FormGroup>
                                    </Col> */}

                                        <Col col={12}>
                                          <FormGroup>
                                            <Label>
                                              {`${Trans(
                                                "POST_CONTENT",
                                                language
                                              )} (${languages_code})`}
                                            </Label>

                                            <ContentEditor
                                              className="Editor"
                                              initialValue=""
                                              setKey={`post_content_${languages_id}`}
                                              updateFun={(Key, Value) => {
                                                setValue(Key, Value);
                                              }}
                                            />

                                            <textarea
                                              {...register(
                                                `post_content_${languages_id}`
                                              )}
                                              style={{ display: "none" }}
                                            ></textarea>
                                          </FormGroup>
                                        </Col>
                                        <Col col={12}>
                                          <FormGroup mb="20px">
                                            <Input
                                              id={`${Trans(
                                                "POST_EXCERPT",
                                                language
                                              )} (${languages_code})`}
                                              label={`${Trans(
                                                "POST_EXCERPT",
                                                language
                                              )} (${languages_code})`}
                                              placeholder={`${Trans(
                                                "POST_EXCERPT",
                                                language
                                              )} (${languages_code})`}
                                              className="form-control"
                                              {...register(
                                                `post_excerpt_${languages_id}`
                                              )}
                                            />

                                          </FormGroup>
                                        </Col>
                                        <Col col={12}>
                                          <FormGroup mb="20px">
                                            <Input
                                              id={`${Trans(
                                                "SEO_META_TITLE",
                                                language
                                              )} (${languages_code})`}
                                              label={`${Trans(
                                                "SEO_META_TITLE",
                                                language
                                              )} (${languages_code})`}
                                              placeholder={`${Trans(
                                                "SEO_META_TITLE",
                                                language
                                              )} (${languages_code})`}
                                              className="form-control"
                                              {...register(
                                                `seometa_title_${languages_id}`
                                              )}
                                            />
                                          </FormGroup>
                                        </Col>
                                        <Col col={12}>
                                          <FormGroup mb="20px">
                                            <TextArea
                                              id={`${Trans(
                                                "SEO_META_DESCRIPTION",
                                                language
                                              )} (${languages_code})`}
                                              label={`${Trans(
                                                "SEO_META_DESCRIPTION",
                                                language
                                              )} (${languages_code})`}
                                              placeholder={`${Trans(
                                                "SEO_META_DESCRIPTION",
                                                language
                                              )} (${languages_code})`}
                                              hint="Enter text" // for bottom hint
                                              className="form-control"
                                              {...register(
                                                `seometa_desc_${languages_id}`
                                              )}
                                            />
                                          </FormGroup>
                                        </Col>
                                      </Row>
                                    </Tab>
                                  );
                                })}
                            </Tabs>
                          </Col>
                        </Row>
                      </fieldset>
                    </Col>

                    <Col col={12}>
                      <fieldset className="form-fieldset">
                        <legend>
                          {Trans("OTHER_INFORMATION", language)}
                        </legend>
                        <Row>


{/* 
                          <Col col={12}>
                            <FormGroup mb="20px">
                              <TextArea
                                id={`${Trans(
                                  "BLOG_CODE",
                                  language
                                )} `}
                                label={`${Trans(
                                  "BLOG_CODE",
                                  language
                                )}`}
                                placeholder={`${Trans(
                                  "BLOG_CODE",
                                  language
                                )} `}
                                hint="Enter text" // for bottom hint
                                className="form-control"
                                {...register(
                                  `blog_code`
                                )}
                              />
                            </FormGroup>
                          </Col> */}
                          
                          <Col
                            col={6}
                            className="mb-10">
                            <label>
                              <b>
                                {Trans("BANNER_IMAGES")}{" "}
                                <span className="error">*</span>{" "}
                              </b>
                            </label>
                            <input
                              type="hidden"

                              {...register("banner_image", {
                                required: Trans("IMAGE_REQUIRED", language),
                              })}
                            />
                            <input
                              placeholder="Setting Value"
                              className="form-control"
                              type="file"
                              onChange={(event) =>
                                HandleDocumentUpload(
                                  event,
                                  `fileupload`,
                                  `banner_image`
                                )
                              }
                            />

                            <div id={`fileupload`}></div>
                            <span className="required">
                              <ErrorMessage
                                errors={errors}
                                name="banner_image"
                              />
                            </span>
                          </Col>{" "}
                          <br />
                          <Col
                            col={6}
                            className="mb-10">
                            <label>
                              <b>
                                {Trans("THUMBNAILS_IMAGES")}{" "}
                                <span className="error">*</span>{" "}
                              </b>
                            </label>
                            <input
                              type="hidden"

                              {...register("thumbnail_image", {
                                required: Trans("THUMBNAILS_IMAGES_REQUIRED", language),
                              })}


                            />
                            <input
                              placeholder="Setting Value"
                              className="form-control"
                              type="file"
                              onChange={(event) =>
                                HandleDocumentUpload(
                                  event,
                                  `thumbfileupload`,
                                  `thumbnail_image`
                                )
                              }
                            />

                            <div id={`thumbfileupload`}></div>
                            <span className="required">
                              <ErrorMessage
                                errors={errors}
                                name="thumbnail_image"
                              />
                            </span>
                          </Col>{" "}
                          <br />

                          <Col col={12}>
                            <FormGroup mb="20px">
                              <Input
                                type="hidden"
                                id={Trans("POST_CATEGORY", language)}
                                label={Trans("POST_CATEGORY", language)}
                                placeholder={Trans("POST_CATEGORY", language)}
                                className="form-control"
                                {...register("category_id")}
                              />

                              <Select
                                isMulti
                                name={Trans("POST_CATEGORY", language)}
                                options={catList}
                                //   defaultValue={quick}
                                className="basic-multi-select"
                                classNamePrefix="select"
                                onChange={(newValue, actionMeta) => {
                                  let listArr = [];
                                  for (
                                    let index = 0;
                                    index < newValue.length;
                                    index++
                                  )
                                    listArr[index] = newValue[index].value;

                                  listArr = listArr.join(",");
                                  //console.log("listArr", listArr);
                                  setValue("category_id", listArr);
                                }}
                              />
                            </FormGroup>
                          </Col>
                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                type="hidden"
                                id={Trans("POST_TAG", language)}
                                label={Trans("POST_TAG", language)}
                                placeholder={Trans("POST_TAG", language)}
                                className="form-control"
                                {...register("tags_id", {})}
                              />

                              <Select
                                isMulti
                                name={Trans("POST_TAG", language)}
                                options={tagList}
                                // defaultValue={quick}
                                className="basic-multi-select"
                                classNamePrefix="select"
                                onChange={(newValue, actionMeta) => {
                                  let listArr = [];
                                  for (
                                    let index = 0;
                                    index < newValue.length;
                                    index++
                                  )
                                    listArr[index] = newValue[index].value;

                                  listArr = listArr.join(",");
                                  //console.log("listArr", listArr);
                                  setValue("tags_id", listArr);
                                }}
                              />
                            </FormGroup>
                          </Col>
                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                id={`slug-target`}
                                label={Trans("POST_SLUG", language)}
                                placeholder={Trans("POST_SLUG", language)}
                                className="form-control"
                                {...register(
                                  "slug", {
                                  required: Trans(
                                    "PAGE_SLUG_REQUIRED",
                                    language
                                  ),
                                }
                                )}

                              />
                            </FormGroup>
                          </Col>

                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                type="hidden"
                                id={Trans("POST_AUTHOR", language)}
                                label={Trans("POST_AUTHOR", language)}
                                placeholder={Trans("POST_AUTHOR", language)}
                                className="form-control"
                                {...register("author_id")}
                              />

                              <Select
                                name={Trans("POST_AUTHOR", language)}
                                options={Trans(authorList, language)}
                                className="basic-multi-select"
                                classNamePrefix="select"
                                onChange={(newValue, actionMeta) => {
                                  // console.log(newValue);
                                  setValue("author_id", newValue.value);
                                }}
                              />
                            </FormGroup>
                          </Col>


                          <Col col={6}>
                            <FormGroup mb="20px">
                              <Input
                                id={Trans("POST_DATE", language)}
                                label={Trans("POST_DATE", language)}
                                placeholder={Trans("POST_DATE", language)}
                                className="form-control"
                                {...register("created_at")}
                                type="date"
                              //  value= {date}

                              // onChange={handleChangetypeactiveat}
                              />
                            </FormGroup>
                          </Col>



                          {
                            updateformloadingStatus ?
                              <>   <Col col={12}><b>Uploading...</b> </Col>
                              </>
                              :
                              <>
                                <Col
                                  col={4}
                                  style={{ marginTop: "10px" }}>
                                  <LoaderButton
                                    formLoadStatus={formloadingStatus}
                                    btnName={Trans("SUBMIT", language)}
                                    className="btn btn-sm btn-bg btn-block"
                                  />
                                </Col>
                              </>
                          }
                        </Row>
                      </fieldset>
                    </Col>
                  </form>
                </div>
              </div>
            </div>
          </CheckPermission>
        </div>
      </div>
    </Content>
  );
};

export default Create;
