import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { PageCategories, PreAdd, PreView } from "config/PermissionName";
import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { useForm } from "react-hook-form";
import { PagesStoreUrl, PagesCreateUrl } from "config/index";
import { PageSetting } from "config/WebsiteUrl";
import { useNavigate } from "react-router-dom";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  StatusSelect,
  TextArea,
  Label,
  IndexSelect,

} from "component/UIElement/UIElement";
import { Alert, Tab, Tabs } from "react-bootstrap";
import { ErrorMessage } from "@hookform/error-message";
import ContentEditor from "component/ContentEditor";


const Create = (props) => {
  const { apiToken, language,userType } = useSelector((state) => state.login);
  const navigate = useNavigate();

  const [value, setsValue] = useState("");
  const getValue = (value) => {
    setsValue(value);
  };

  const [key, setKey] = useState("default_language");
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

 


  const onSubmit = (formData) => {
    SetformloadingStatus(false);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    console.log("saveFormData", saveFormData);

    let data = {
     
      pages_content: value,
    };


    POST(PagesStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          Notify(true, Trans(message, language));
          if(userType === "subscriber" )
          {

             navigate(`/pages-setting`);

          }
          else{

            navigate("/superadmin/pages-setting");
          }
        //  navigate(`/pages-setting`);
        } else {
          var errObj = {
            status: false,
            msg: "",
            type: "danger",
          };
          Notify(false, Trans(message, language));

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };
  

  const [langList, SetlangList] = useState([]);

  useEffect(() => {
    let abortController = new AbortController();
    const formData = {
      api_token: apiToken,
      language: language,
    };
    POST(PagesCreateUrl, formData)
      .then((response) => {
        const { status, data } = response.data;
        if (status) {
          SetlangList(data.language);
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      });
    return () => abortController.abort();
  }, []);

  const [finallslug, setfinallslug] = useState("");

  const slugCreate =()=>  {
 
    var slug_generate = document.getElementById("slug-source").value;
    let slugcreate = slug_generate.toLowerCase().replace(/ /g, '-')
        .replace(/[^\w-]+/g, '');

   document.getElementById("slug-target").value = slugcreate;    
  //  let finalData= document.getElementById("slug-target").value = slugcreate;
  //  setfinallslug(slugcreate);
  //   console.log(slugcreate);

};




  return (
    <Content>
     
      <div className="row row-xs">
        <div className="col-sm-12 col-lg-12">
            <div className="card" id="custom-user-list">
              <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                <h6 className=" tx-semibold mg-b-0">
                  {Trans("ADD_PAGES", language)}
                </h6>
                <div className=" d-md-flex">
                 
                    <Anchor
                  className="btn btn-sm btn-bg pd-3"
                  path={WebsiteLink(PageSetting)}
                >
                  <FeatherIcon
                  //  icon="corner-down-left"
                    className="wd-10 mg-r-5"
                  />
                  {Trans("GO_BACK", language)}
                </Anchor>
                  
                  
                </div>
              </div>
              <div className="card-body">
                <div className="">
                  {error.status && (
                    <Alert
                      variant={error.type}
                      onClose={() =>
                        setError({ status: false, msg: "", type: "" })
                      }
                      dismissible
                    >
                      {error.msg}
                    </Alert>
                  )}
                  <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
                     <Col col={12}>
                  <fieldset className="form-fieldset">
                          <legend>
                            {Trans("PAGE_INFORMATION", language)}
                          </legend>
                    <Row>



                      <Col col={12}>
                        <Tabs
                          id="controlled-tab-example"
                        
                          onSelect={(k) => setKey(k)}
                          className="mb-3"
                        >
                          {langList &&
                            langList.map((lang) => {
                              const {
                                languages_code,
                                languages_id,
                                languages_name,
                              } = lang;

                              return (
                                <Tab
                                  eventKey={languages_code}
                                  key={languages_id}
                                  title={languages_name}
                                >
                                  <Row>
                                    <Col col={12}>
                                      <FormGroup mb="20px">
                                        <Input
                                         
                                         id={`slug-source`}
                                          label={`${Trans(
                                            "PAGE_TITLE",
                                            language
                                          )} (${languages_code})`}
                                          placeholder={`${Trans(
                                            "PAGE_TITLE",
                                            language
                                          )} (${languages_code})`}
                                          hint="Enter text" // for bottom hint
                                          className="form-control"
                                          {...register(
                                            `pages_title_${languages_id}`,
                                            {
                                              // required: Trans(
                                              //   "PAGE_TITLE_REQUIRED",
                                              //   language
                                              // ),
                                            }
                                          )}

                                          onKeyUp={() => {
                                            slugCreate();
                                          }} 
                                        />
                                        {/* <span className="required">
                                          <ErrorMessage
                                            errors={errors}
                                            name={`pages_title_${languages_id}`}
                                          />
                                        </span> */}
                                      </FormGroup>
                                    </Col>
{/* 
                                    <Col col={6}>
                                      <FormGroup mb="20px">
                                        <Input
                                         id={`slug-target`}
                                          label={`${Trans(
                                            "PAGE_SLUG",
                                            language
                                          )}`}
                                          placeholder={`${Trans(
                                            "PAGE_SLUG",
                                            language
                                          )} (${languages_code})`}
                                          hint="Enter text" // for bottom hint
                                          className="form-control"
                                          {...register(
                                            `pages_slug`,
                                            {
                                            
                                            }
                                          )}
                                        />
                                      
                                      </FormGroup>
                                    </Col> */}

                                    <Col col={12}>
                                      <FormGroup>
                                        <Label>
                                          {`${Trans(
                                            "PAGES_CONTENT",
                                            language
                                          )} (${languages_code})`}
                                        </Label>

                                        <ContentEditor
                                        className="Editor" 
                                        initialValue= ""
                                        setKey={`pages_content_${languages_id}`}
                                        updateFun={(Key, Value) => {
                                          setValue(Key, Value);
                                        }}
                                        />
                                        
                                        <textarea
                                          {...register(
                                            `pages_content_${languages_id}`
                                          )}
                                          style={{ display: "none" }}
                                        ></textarea>






                                      </FormGroup>
                                    </Col>
                                    <Col col={12}>
                                      <FormGroup mb="20px">
                                        <Input
                                          id={`${Trans(
                                            "SEO_META_TITLE",
                                            language
                                          )} (${languages_code})`}
                                          label={`${Trans(
                                            "SEO_META_TITLE",
                                            language
                                          )} (${languages_code})`}
                                          placeholder={`${Trans(
                                            "SEO_META_TITLE",
                                            language
                                          )} (${languages_code})`}
                                          className="form-control"
                                          {...register(
                                            `seometa_title_${languages_id}`
                                          )}
                                        />
                                      </FormGroup>
                                    </Col>
                                    <Col col={12}>
                                      <FormGroup mb="20px">
                                        <TextArea
                                          id={`${Trans(
                                            "SEO_META_DESCRIPTION",
                                            language
                                          )} (${languages_code})`}
                                          label={`${Trans(
                                            "SEO_META_DESCRIPTION",
                                            language
                                          )} (${languages_code})`}
                                          placeholder={`${Trans(
                                            "SEO_META_DESCRIPTION",
                                            language
                                          )} (${languages_code})`}
                                          hint="Enter text" // for bottom hint
                                          className="form-control"
                                          {...register(
                                            `seometa_desc_${languages_id}`
                                          )}
                                        />
                                      </FormGroup>
                                    </Col>
                                  </Row>
                                </Tab>
                              );
                            })}
                        </Tabs>
                      </Col>
                      </Row>
                        </fieldset>
                      </Col>

                      <Col col={12}>
                  <fieldset className="form-fieldset">
                          <legend>
                            {Trans("OTHER_INFORMATION", language)}
                          </legend>
                      <Row>
                            

                                   <Col col={6}>
                                      <FormGroup mb="20px">
                                        <Input
                                         label={Trans("PAGE_SLUG", language)}
                                         placeholder={Trans("PAGE_SLUG", language)}
                                         id={`slug-target`}
                                          hint="Enter text" // for bottom hint
                                          className="form-control"
                                          {...register(
                                            "pages_slug", {
                                              required: Trans(
                                                "PAGE_SLUG_REQUIRED",
                                                language
                                              ),
                                            }
                                          )}
                                          defaultValue={finallslug}
                                        />
                                       <span className="required">
                <ErrorMessage errors={errors} name="featured" />
              </span>
                                      </FormGroup>
                                    </Col>

                <Col col={6}>
            <FormGroup mb="20px">
              <IndexSelect
                id={Trans("NOINDEX", language)}
                label={Trans("NOINDEX", language)}
                className="form-control"
                {...register("noindex", {
                
                })}
                defaultValue={0}
              />
               <span className="required">
                <ErrorMessage errors={errors} name="featured" />
              </span>
            </FormGroup>
          </Col>
          <Col col={3} style={{ marginTop: "10px" }}>
                  <LoaderButton
                    formLoadStatus={formloadingStatus}
                    btnName={Trans("SUBMIT", language)}
                    className="btn btn-sm btn-bg btn-block"
                  />
                </Col>

          </Row>
   </fieldset>
                      </Col>

                
               
                      <br />
                    {/* </Row> */}
                  </form>
                </div>
              </div>
            </div>
        </div>
      </div>
    </Content>
  );
};

export default Create;
