import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { PageCategories, PreAdd, PreView } from "config/PermissionName";
import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { useForm } from "react-hook-form";
import {
  SectionUserUrl,
  SectionSelectUrl,
  AccountStoreUrl,
} from "config/index";
import { PageSetting } from "config/WebsiteUrl";
import { useNavigate } from "react-router-dom";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  Label,
} from "component/UIElement/UIElement";
import { Alert, Tab, Tabs } from "react-bootstrap";
import { ErrorMessage } from "@hookform/error-message";
import MyEditor from "component/MyEditor";
import Select from "react-select";

const Create = (props) => {
  const { apiToken, language, userType, quickSectionList, themeColor } =
    useSelector((state) => state.login);

  const navigate = useNavigate();

  const [key, setKey] = useState("en");
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
    getValues,
  } = useForm();

  const quick = [];
  const nesw = [];

  {
    quickSectionList &&
      JSON.parse(quickSectionList).map((menu, index) => {
        //quick.push();
        quick.push({
          label: Trans(menu.section_name, language),
          value: menu.section_id,
        });
      });
  }

  console.log(quick);

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    //saveFormData.quick_access = quick;

    //console.log(saveFormData.theme_color);

    // saveFormData.quickSectionList = JSON.stringify(quickSectionList);
    // console.log(formData.quickSectionList);
    // localStorage.setItem("quickSectionList", JSON.stringify(quick));

    localStorage.setItem("themeColor", saveFormData.theme_color);

    POST(AccountStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });

          // props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
        SetformloadingStatus(false);
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [webfunctionSelected, SetwebfunctionSelected] = useState();

  const [editInfo, SeteditInfo] = useState("");

  const setValueToField = () => {
    const editInfo = {
      api_token: apiToken,
    };
    POST(SectionSelectUrl, editInfo)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SeteditInfo(data);
          console.log(data);

          const fieldList = getValues();
          for (const key in fieldList) {
            setValue(key, data[key]);
          }
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        Notify(false, Trans(error.message, language));
      });
  };
  const [moduleList, SetmoduleList] = useState([]);
  const getModuleList = () => {
    const filterData2 = {
      api_token: apiToken,
      userType: userType,
      language: language,
    };
    POST(SectionUserUrl, filterData2)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetmoduleList(Trans(data.sectionlist, language));
          setValueToField();
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    getModuleList();
    return () => abortController.abort(); //getModuleList();
  }, []);

  console.log(moduleList);
  return (
    <Content>
      <div className="col-sm-12 col-lg-12">
        <CheckPermission
          PageAccess={PageCategories}
          PageAction={PreView}>
          <div
            className="card"
            id="custom-user-list">
            <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
              <h6 className="tx-uppercase tx-semibold mg-b-0">
                {Trans("ACCOUNT", language)}
              </h6>
              <div className="d-none d-md-flex">
                <CheckPermission
                  PageAccess={PageCategories}
                  PageAction={PreAdd}></CheckPermission>
              </div>
            </div>
            <div className="card-body">
              <div className="row col-md-12">
                {/* {error.status && (
                    <Alert
                      variant={error.type}
                      onClose={() =>
                        setError({ status: false, msg: "", type: "" })
                      }
                      dismissible
                    >
                      {error.msg}
                    </Alert>
                  )} */}
                <form
                  action="#"
                  onSubmit={handleSubmit(onSubmit)}
                  noValidate>
                  <Row>
                    <Col col={6}>
                      <FormGroup mb="20px">
                        <Input
                          type="hidden"
                          id={Trans("QUICK_ACCESS", language)}
                          label={Trans("QUICK_ACCESS", language)}
                          placeholder={Trans("QUICK_ACCESS", language)}
                          className="form-control"
                          {...register("quick_access", {
                            required: Trans(
                              "CHOOSE_QUICK_ACCESS_REQUIRED",
                              language
                            ),
                          })}
                        />

                        <Select
                          isMulti
                          name={Trans("QUICK_ACCESS", language)}
                          options={Trans(moduleList, language)}
                          defaultValue={Trans(quick, language)}
                          className="basic-multi-select"
                          classNamePrefix="select"
                          onChange={(newValue, actionMeta) => {
                            let listArr = [];
                            for (
                              let index = 0;
                              index < newValue.length;
                              index++
                            )
                              listArr[index] = newValue[index].value;

                            listArr = listArr.join(",");
                            console.log("listArr", listArr);
                            setValue("quick_access", listArr);
                          }}
                        />

                        {/* <select
                id={Trans("QUICK_ACCESS", language)}
                placeholder={Trans("QUICK_ACCESS", language)}
                className="form-control"
               
              >
           {moduleList &&
              moduleList.map((section, secindex) => {
                const { module_name} = section;
                console.log(section);
                <optgroup label={module_name}>

              {section.sections &&
                  <>
                {section.section_list.map(
                  (subsection, idxx) => {
                <option value="Classic"> {Trans("subsection.label", language)} </option>
              })}
          </>    } 
                </optgroup>

     })}
              </select> */}

                        {/* )} */}
                        <span className="required">
                          <ErrorMessage
                            errors={errors}
                            name="quick_access"
                          />
                        </span>
                      </FormGroup>
                    </Col>

                    <Col col={6}>
                      <FormGroup>
                        <Label
                          display="block"
                          mb="5px"
                          htmlFor="name">
                          {Trans("THEME_COLOR", language)}{" "}
                          <span className="required">*</span>
                        </Label>
                        <select
                          id={Trans("THEME_COLOR", language)}
                          placeholder={Trans("THEME_COLOR", language)}
                          className="form-control"
                          {...register("theme_color")}
                          defaultValue={themeColor}>
                          <option value=" ">{Trans("SELECT", language)}</option>
                          <option value="Classic">
                            {" "}
                            {Trans("Classic", language)}{" "}
                          </option>
                          <option value="Dark">
                            {Trans("Dark", language)}{" "}
                          </option>
                        </select>
                      </FormGroup>
                    </Col>
                    <Col col={6}>
                      <LoaderButton
                        formLoadStatus={formloadingStatus}
                        btnName={Trans("UPDATE", language)}
                        className="btn btn-primary btn-block"
                      />
                    </Col>
                  </Row>
                </form>
              </div>
            </div>
          </div>
        </CheckPermission>
      </div>
    </Content>
  );
};

export default Create;
