import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";

import { SliderUrl, SliderStatusUrl } from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import AddSlider from "./AddSlider";
import {
  Col,
  BadgeShow,
  Anchor,
  IconButton,
} from "component/UIElement/UIElement";
import { useForm } from "react-hook-form";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { SliderSetting } from "config/WebsiteUrl";
import ModalAlert from "component/ModalAlert";

import {
  WebSliderSetting,
  PreAdd,
  PreView,
  PreExport,
  PreUpdate,
} from "config/PermissionName";
import EditSlider from "./EditSlider";
import WebsiteLink from "config/WebsiteLink";

function Slider() {
  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const [listData, SetlistData] = useState([]);
  const [HelperData, SetHelperData] = useState([]);

  const methods = useForm({
    defaultValues: {
      settingdata: [
        {
          banner_setting_id: 1,
          template_id: 1,
          refrence_id: "asdsad",
          banner_position_id: "",
          images_id: "",
          comment: 1,
        },
      ],
    },
  });

  const {
    register,
    control,
    formState: { errors },
    getValue,
    handleSubmit,
  } = methods;

  const [sectionListing, SetSectionListing] = useState([]);

  const loadSettingData = () => {
    const filterData = {
      api_token: apiToken,
    };
    POST(SliderUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetSectionListing(data.data_list);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  useEffect(() => {
    document.title = "Slider Setting | WorkerMan";
    let abortController = new AbortController();
    loadSettingData();
    return () => abortController.abort();
  }, []);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  useEffect(() => {}, [listData]);

  // handle change group name

  const [SliderList, SetSliderList] = useState([]);

  const findListBanner = (id) => {
    const filterData = {
      api_token: apiToken,
      sliders_id: id,
    };
    POST(SliderUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        console.log("Banner list", data);
        if (status) {
          SetloadingStatus(false);
          SetSliderList(data.data_list);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const changeStatus = (id) => {
    const filterData = {
      api_token: apiToken,
      sliders_id: id,
    };
    POST(SliderStatusUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        loadSettingData();
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // change Status function
  const ChangeStatusfun = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: changeStatus,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  const editFunction = (updateId) => {
    SetEditData(updateId);
    setEditModalShow(true);
  };

  return (
    <Content>
      <CheckPermission
        PageAccess={WebSliderSetting}
        PageAction={PreView}>
        <>
          <div className="row row-xs">
            <div className="col-sm-12 col-lg-12">
              <CheckPermission
                PageAccess={WebSliderSetting}
                PageAction={PreView}>
                <div
                  className="card"
                  id="custom-user-list">
                  {/* CARD HEADER */}

                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {Trans("SLIDER", language)}
                    </h6>
                    <div className=" d-md-flex">
                      <CheckPermission
                        PageAccess={WebSliderSetting}
                        PageAction={PreAdd}>
                        <Button
                          // variant="primary"
                          className=" btn-sm btn-bg"
                          onClick={handleModalShow}>
                          <FeatherIcon
                            icon="plus"
                            fill="white"
                            className="wd-10 mg-r-5 "
                          />
                          {Trans("ADD_SLIDER", language)}
                        </Button>
                      </CheckPermission>
                    </div>
                  </div>

                  {/* END CARD HEADER */}
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">
                      <Col col={12}>
                        <div className="table-responsive">
                          <table className="table">
                            <thead>
                              <tr>
                                <th>{Trans("SL_NO", language)}</th>
                                <th>{Trans("SLIDER_TITLE", language)}</th>
                                <th>{Trans("TEMPLATE_CODE", language)}</th>
                                <th>{Trans("STATUS", language)}</th>
                                <th className="text-center">
                                  {Trans("ACTION", language)}
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              {sectionListing &&
                                sectionListing.map((slider, idx) => {
                                  return (
                                    <tr key={idx}>
                                      <td>{idx + 1}</td>
                                      <td>{slider.sliders_title}</td>
                                      <td>{`[SLIDERS ID=${slider?.sliders_id} THEME=01]`}</td>
                                      <td>
                                        <div className="custom-control custom-switch ">
                                          <input
                                            onClick={() => {
                                              changeStatus(slider.sliders_id);
                                            }}
                                            type="checkbox"
                                            class="custom-control-input"
                                            //  id="customSwitch1"
                                            id={`customSwitch${slider.sliders_id}`}
                                            checked={
                                              slider.status === 0
                                                ? ""
                                                : "checked"
                                            }
                                          />
                                          <label
                                            className="custom-control-label"
                                            For={`customSwitch${slider.sliders_id}`}></label>
                                        </div>
                                      </td>

                                      <td className="text-center">
                                        <Anchor
                                          color="primary"
                                          path={WebsiteLink(
                                            `${SliderSetting}/${slider?.sliders_id}`
                                          )}
                                          className="btn btn-primary btn-xs btn-icon">
                                          <FeatherIcon icon="eye" />
                                        </Anchor>
                                        {"  "}
                                        <CheckPermission
                                          PageAccess={WebSliderSetting}
                                          PageAction={PreUpdate}>
                                          <IconButton
                                            color="primary"
                                            onClick={() =>
                                              editFunction(slider?.sliders_id)
                                            }>
                                            <FeatherIcon
                                              icon="edit-2"
                                              fill="white"
                                              onClick={() =>
                                                editFunction(slider?.sliders_id)
                                              }
                                            />
                                          </IconButton>
                                        </CheckPermission>
                                      </td>
                                    </tr>
                                  );
                                })}

                              {sectionListing.length === 0 ? (
                                <tr>
                                  <td
                                    colSpan={6}
                                    className="text-center">
                                    {Trans("NOT_FOUND", language)}
                                  </td>
                                </tr>
                              ) : null}
                            </tbody>
                          </table>
                        </div>
                      </Col>
                    </div>
                  )}
                </div>
              </CheckPermission>
            </div>
          </div>
        </>
      </CheckPermission>

      {/* add modal */}
      <Modal
        show={show}
        onHide={handleModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("ADD_SLIDER", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <AddSlider
            loadSettingData={loadSettingData}
            handleModalClose={handleModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* edit modal */}
      <Modal
        show={editModalShow}
        onHide={handleEditModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("UPDATE_SLIDER", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <EditSlider
            editData={editData}
            loadSettingData={loadSettingData}
            handleModalClose={handleEditModalClose}
          />
        </Modal.Body>
      </Modal>

      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}

      {/* end end modal */}
    </Content>
  );
}

export default Slider;
