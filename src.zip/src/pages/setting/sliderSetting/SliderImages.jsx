import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import ModalImage from "react-modal-image-responsive";

import {
  SliderImagesUrl,
  BannerUpdateSettingUrl,
  BannerGroupUrl,
  SliderImagesStatusUrl,
  SliderImagesSortOrderUrl,
  SliderImagesDeleteUrl,
} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Create from "./Create";

import { Col, BadgeShow, IconButton } from "component/UIElement/UIElement";
import { useForm } from "react-hook-form";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { useParams } from "react-router-dom";
import ModalAlert from "component/ModalAlert";

import {
  WebSliderSetting,
  PreAdd,
  PreView,
  PreUpdate,
} from "config/PermissionName";

import Edit from "./Edit";
import WebsiteLink from "config/WebsiteLink";
import { SliderSetting } from "config/WebsiteUrl";

function SliderImages() {
  const { sliderId } = useParams();

  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");

  const methods = useForm({
    defaultValues: {
      settingdata: [
        {
          banner_setting_id: 1,
          template_id: 1,
          refrence_id: "asdsad",
          banner_position_id: "",
          images_id: "",
          comment: 1,
        },
      ],
    },
  });

  useEffect(() => {
    document.title = "Slider  | WorkerMan";
    let abortController = new AbortController();
    //   loadSettingData();
    findListBanner(sliderId);
    return () => abortController.abort();
  }, []);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  // handle change group name
  const [sectionListing, SetSectionListing] = useState([]);

  const [sliderList, SetSliderList] = useState([]);
  const [banGrpInfo, SetbanGrpInfo] = useState([]);

  const findListBanner = (id, sortBys, OrderBy) => {
    const filterData = {
      api_token: apiToken,
      sliders_id: id,
      sortBy: sortBys,
      orderBY: OrderBy,
    };
    POST(SliderImagesUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        console.log("Banner list", data);
        if (status) {
          SetloadingStatus(false);
          SetSliderList(data.data_list);
          SetbanGrpInfo(data.info);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const destroyItem = (id) => {
    const filterData = {
      api_token: apiToken,
      id: id,
    };
    POST(SliderImagesDeleteUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        findListBanner(sliderId);
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const changeStatus = (id) => {
    const filterData = {
      api_token: apiToken,
      id: id,
    };
    POST(SliderImagesStatusUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        findListBanner(sliderId);
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: destroyItem,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  // change Status function
  const ChangeStatusfun = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: changeStatus,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

  const [viewModalShow, setViewModalShow] = useState(false);
  const handleViewModalClose = () => setViewModalShow(false);

  const editFunction = (updateId) => {
    SetEditData(updateId);
    setEditModalShow(true);
  };

  const filterItem = () => {
    findListBanner(sliderId);
  };

  const viewFunction = (updateId) => {
    SetEditData(updateId);
    setViewModalShow(true);
  };

  const viewFun = (editId) => {
    viewFunction(editId);
  };

  const UpdateOrderStatus = (update_id, sortOrder) => {
    const editData = {
      api_token: apiToken,
      id: update_id,
      sort_order: sortOrder,
    };
    POST(SliderImagesSortOrderUrl, editData)
      .then((response) => {
        const { message } = response.data;
        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };

  return (
    <Content>
      <CheckPermission
        PageAccess={WebSliderSetting}
        PageAction={PreView}>
        <>
          {/* <PageHeader
            breadcumbs={[
              { title: Trans("DASHBOARD", language), link: "/", class: "" },
              {
                title: Trans("SLIDER", language),
                link: WebsiteLink(SliderSetting),
                class: "",
              },
              // {
              //   title: banGrpInfo?.group_name,
              //   link: "/",
              //   class: "active",
              // },
            ]}
          /> */}

          <div className="row row-xs">
            <div className="col-sm-12 col-lg-12">
              <CheckPermission
                PageAccess={WebSliderSetting}
                PageAction={PreView}>
                <div
                  className="card"
                  id="custom-user-list">
                  {/* CARD HEADER */}

                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {Trans(banGrpInfo?.sliders_title, language)}
                    </h6>
                    <div className=" d-md-flex">
                      <CheckPermission
                        PageAccess={WebSliderSetting}
                        PageAction={PreAdd}>
                        <Button
                          className="btn-sm btn-bg"
                          onClick={handleModalShow}>
                          <FeatherIcon
                            icon="plus"
                            fill="white"
                            className="wd-10 mg-r-5 "
                          />
                          {Trans("ADD_SLIDER_IMAGES", language)}
                        </Button>
                      </CheckPermission>
                    </div>
                  </div>

                  {/* END CARD HEADER */}
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">
                      <Col col={12}>
                        <div className="table-responsive">
                          <table className="table">
                            <thead>
                              <tr>
                                <th>{Trans("SL_NO", language)}</th>
                                <th>{Trans("SLIDER", language)}</th>
                                <th>{Trans("SORT_ORDER", language)}</th>
                                <th>{Trans("STATUS", language)}</th>
                                <th className="text-center">
                                  {Trans("ACTION", language)}
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              {sliderList &&
                                sliderList.map((slider, idx) => {
                                  return (
                                    <tr key={idx}>
                                      <td>{idx + 1}</td>

                                      <td>
                                        <ModalImage
                                          small={slider.image}
                                          large={slider.image}
                                          height="10"
                                          width="10"
                                          className="img50"
                                        />
                                      </td>
                                      <td>
                                        <input
                                          type="number"
                                          name=""
                                          id=""
                                          defaultValue={slider.sort_order}
                                          style={{
                                            width: "50px",
                                            "text-align": "center",
                                          }}
                                          onBlur={(e) => {
                                            UpdateOrderStatus(
                                              slider.id,
                                              e.target.value
                                            );
                                          }}
                                        />
                                      </td>
                                      <td>
                                        <div className="custom-control custom-switch ">
                                          <input
                                            onClick={() => {
                                              changeStatus(slider.id);
                                            }}
                                            type="checkbox"
                                            class="custom-control-input"
                                            //  id="customSwitch1"
                                            id={`customSwitch${slider.id}`}
                                            checked={
                                              slider.status === 0
                                                ? ""
                                                : "checked"
                                            }
                                          />
                                          <label
                                            className="custom-control-label"
                                            For={`customSwitch${slider.id}`}></label>
                                        </div>

                                        {/* <BadgeShow type={status} content={status} /> */}
                                      </td>

                                      <td className="text-center">
                                        <a
                                          variant="primary"
                                          href={slider?.sliders_url}
                                          target="_blank">
                                          <FeatherIcon
                                            icon="external-link"
                                            size="18"
                                          />
                                        </a>{" "}
                                        <CheckPermission
                                          PageAccess={WebSliderSetting}
                                          PageAction={PreUpdate}>
                                          <IconButton
                                            color="primary"
                                            onClick={() =>
                                              editFunction(slider?.id)
                                            }>
                                            <FeatherIcon
                                              icon="edit-2"
                                              fill="white"
                                              onClick={() =>
                                                editFunction(slider?.id)
                                              }
                                            />
                                          </IconButton>{" "}
                                          {"  "}
                                        </CheckPermission>
                                        <IconButton
                                          color="primary"
                                          onClick={() =>
                                            deleteItem(slider?.id)
                                          }>
                                          <FeatherIcon
                                            icon="x-square"
                                            color="white"
                                            onClick={() =>
                                              deleteItem(slider?.id)
                                            }
                                          />
                                        </IconButton>
                                        {"  "}
                                      </td>
                                    </tr>
                                  );
                                })}

                              {sliderList.length === 0 ? (
                                <tr>
                                  <td
                                    colSpan={5}
                                    className="text-center">
                                    {Trans("NOT_FOUND", language)}
                                  </td>
                                </tr>
                              ) : null}
                            </tbody>
                          </table>
                        </div>
                      </Col>
                    </div>
                  )}
                </div>
              </CheckPermission>
            </div>
          </div>
        </>
      </CheckPermission>

      {/* add modal */}
      <Modal
        show={show}
        onHide={handleModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("ADD_SLIDER_IMAGES", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Create
            loadSettingData={findListBanner}
            handleModalClose={handleModalClose}
            filterItem={filterItem}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* edit modal */}
      <Modal
        show={editModalShow}
        onHide={handleEditModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("UPDATE_SLIDER_IMAGES", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Edit
            editData={editData}
            //  loadSettingData={findListBanner(sliderId)}
            filterItem={filterItem}
            handleModalClose={handleEditModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
      {/* img modal */}
      <Modal
        show={viewModalShow}
        onHide={handleViewModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("IMAGE_URL", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleViewModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <img
            src={editData}
            height="200"
            width="400"
          />
        </Modal.Body>
      </Modal>
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}

      {/*  modal */}
    </Content>
  );
}

export default SliderImages;
