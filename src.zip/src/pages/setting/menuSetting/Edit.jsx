import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { MenuUpdateUrl, MenuCreateUrl, MenuEditUrl, tempUploadFileUrl ,tempLandingUploadFileUrl} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  StatusSelect,

  Row,
  Col,
  Label,
  Input,
} from "component/UIElement/UIElement";
import { ErrorMessage } from "@hookform/error-message";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import Loading from "component/Preloader";
import Select from "react-select";


const Edit = (props) => {
  const { editData } = props;
  const grpId = props.menuGroupId;

  const { apiToken, language, industry ,userType} = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    formState: { errors },
    setValue,
    getValues,
    handleSubmit,
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    formData.api_token = apiToken;
    console.log(formData);
    POST(MenuUpdateUrl, formData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });
          props.filterItem();
          props.handleModalClose();
          props.loadSettingData();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };


          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              console.log(message[key][0]);
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = Trans(message, language);
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [sectionListing, SetSectionListing] = useState([]);
  const [MenuType, SetMenuType] = useState("");
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [editInfo, SeteditInfo] = useState("");
  const [langList, SetlangList] = useState([]);

  const [pageListing, SetpageListing] = useState([]);
  const [categoryListing, SetcategoryListing] = useState([]);

  const [selectedPage, SetselectedPageList] = useState([]);
  const [selectedCategory, SetselectedCategoryList] = useState([]);

  const [editLavel, Seteditlabel] = useState("");

  // function setValueToField() {
  //   const editInfo = {
  //     api_token: apiToken,
  //     menu_id: editData,
  //     group_id:grpId,

  //   };


  //   POST(MenuEditUrl, editInfo)
  //     .then((response) => {
  //       SetloadingStatus(false);
  //       const { data } = response.data;
  //       SeteditInfo(data.data_list[0]);
  //       SetType(data.menu_type);
  //       SetMenuType(parseInt(data.data_list[0].menu_type));
  //       SetSectionListing(data);
  //       SetlangList(data.language);
  //       Seteditlabel(data.label);
  //       const fieldList = getValues();
  //       for (const key in fieldList) {
  //         setValue(key, data.data_list[0][key]);
  //       }

  //   let menu_label ='';
  // // convert all array to object
  // const { menu_details } = data?.data_list[0];
  // if (menu_details.length > 0) {
  //   for (let index = 0; index < menu_details.length; index++) {

  //     for (const key in menu_details[index]) {
  //       const keyName =
  //         key + "_" + menu_details[index]["languages_id"];
  //        const KeyValue = menu_details[index][key];      
  //        setValue(keyName, KeyValue);
  //     }

  //     setValue(
  //       "menu_name_" + menu_details[index]["languages_id"],
  //       menu_details[index].menu_name
  //     );


  //     setValue(
  //       "menu_label_" + menu_details[index]["languages_id"],
  //       menu_details[index].menu_label
  //     );


  //     }
  // }
  //     })
  //     .catch((error) => {
  //       SetloadingStatus(false);
  //       Notify(false, error.message);
  //     });
  // }

  // useEffect(() => {
  //   let abortController = new AbortController();
  //   setValueToField();
  //   return () => abortController.abort();
  // }, []);


  const [editLoad, SeteditLoad] = useState(false);


  useEffect(() => {
    let abortController = new AbortController();
    function setValueToField() {
      const editInfo = {
        api_token: apiToken,
        menu_id: editData,
        group_id: grpId,
      };
      POST(MenuEditUrl, editInfo)
        .then((response) => {
          SetloadingStatus(false);
          const { data } = response.data;
          SeteditInfo(data.data_list[0]);
          SetMenuType(parseInt(data.data_list[0].menu_type));
          SetSectionListing(data);
          SetlangList(data.language);
          Seteditlabel(data.label);
          SetpageListing(data.page_data);
          SetcategoryListing(data);

          SetselectedPageList(data.data_list[0].selected_pages);
          SetselectedCategoryList(data.data_list[0].selected_category);




          const fieldList = getValues();
          for (const key in fieldList) {

            setValue(key, data.data_list[0][key]);
          }

          const { menu_details } = data?.data_list[0];
          if (menu_details.length > 0) {
            for (let index = 0; index < menu_details.length; index++) {

              for (const key in menu_details[index]) {

                const KeyValue = menu_details[index][key];
                //   console.log(KeyValue);   
                //   setValue(key, KeyValue);

              }

              setValue(
                "menu_name_" + menu_details[index]["languages_id"],
                menu_details[index].menu_name
              );


              setValue(
                "menu_label_" + menu_details[index]["languages_id"],
                menu_details[index].menu_label
              );


            }
          }

          SeteditLoad(true);
        })

        .catch((error) => {
          SetloadingStatus(false);
          alert(error.message);
        });
    }
    setValueToField();
    return () => {
      // setValueToField();
      abortController.abort();
    };
  }, []);


  const [tempFile, SettempFile] = useState("");

  const [updateformloadingStatus, SetupdateformloadingStatus] = useState(false);


  const HandleDocumentUpload = (event, previewUrlId, StoreID) => {
    SetupdateformloadingStatus(true);

    if (event.target.files[0] === "" || event.target.files[0] === undefined)
      return (<>{Trans("PLEASE_WAIT_IMAGE_UPLOAD_FEW_MINUTES", language)} </>);

    var readers = new FileReader();
    readers.onload = function (e) {

      document.getElementById(
        previewUrlId
      ).innerHTML = `<img src=${e.target.result} height="100"  />`;
      // {Trans("PLEASE_WAIT_IMAGE_UPLOAD_FEW_MINUTES", language)}
      //  document.getElementById("imageLoadedMessage").innerHTML = "Page loaded!";
    };


    readers.readAsDataURL(event.target.files[0]);

    // upload temp image and bind value to array
    const formdata = new FormData();
    formdata.append("api_token", apiToken);
    formdata.append("fileInfo", event.target.files[0]);
    formdata.append("images_type", 1);

    if(userType==="subscriber"){

    POST(tempUploadFileUrl, formdata)
      .then((response) => {
        SetupdateformloadingStatus(false);

        setValue(StoreID, response.data.data);
        SettempFile(response.data.data ?? '0');
        //  const  message  = response.data.message;

        // const status = true;
        // console.log( message);
        // if (status) {
        //   setError({
        //     status: true,
        //     msg: Trans(message, language),
        //     type: "success",
        //   });
        //   Notify(true, Trans(message, language));

        // }
        // else {
        //   var errObj = {
        //     status: true,
        //     msg: "",
        //     type: "danger",
        //   };

        //   if (typeof message === "object") {
        //     let errMsg = "";
        //     Object.keys(message).map((key) => {
        //       errMsg += Trans(message[key][0], language);
        //       return errMsg;
        //     });
        //     errObj.msg = errMsg;
        //   } else {
        //     errObj.msg = message;
        //   }
        //   setError(errObj);
        // }


      })
      .catch((error) => {
        SetupdateformloadingStatus(false);

        Notify(false, error.message);
      });
    }

    else{

      POST(tempLandingUploadFileUrl, formdata)
      .then((response) => {
        SetupdateformloadingStatus(false);

        setValue(StoreID, response.data.data);
        SettempFile(response.data.data ?? '0');
        //  const  message  = response.data.message;

      })
      .catch((error) => {
        SetupdateformloadingStatus(false);

        Notify(false, error.message);
      });

    }
  };
  console.log(updateformloadingStatus);


  return (
    <React.Fragment>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
      <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        <input type="hidden" {...register("menu_id")} />
        <input
          type="hidden"
          {...register("group_id")}
          defaultValue={grpId}
        />
        <Row>

          <Col col={6}>
            <FormGroup mb="20px">
              <Label
                display="block"
                mb="5px"
                htmlFor={Trans("PARENT_MENU", language)}
              >
                {Trans("PARENT_MENU", language)}
              </Label>
              <select
                id={Trans("PARENT_MENU", language)}
                placeholder={Trans("PARENT_MENU", language)}
                className="form-control"
                {...register("parent_id",

                )}
                defaultValue={editInfo?.parent_id}

              >
                <option value="">{Trans("SELECT_PARENT_MENU", language)}</option>
                <option value="0">{Trans("----")}</option>

                {sectionListing?.parent_type &&
                  sectionListing?.parent_type.map((curr, idx) => (
                    <>
                      {curr?.menu_details &&
                        curr?.menu_details.map((cur, Idx) => (
                          <option value={cur.menu_id} key={idx}>
                            {cur.menu_name}
                          </option>
                        ))}

                    </>
                  ))}

              </select>

            </FormGroup>
          </Col>


          {langList &&
            langList.map((lang) => {
              const {
                languages_code,
                languages_id,
                languages_name,
              } = lang;
              return (
                <>
                  <Col col={6}>
                    <FormGroup mb="20px">
                      <Input
                        id={Trans("MENU_NAME", language)}
                        label={`${Trans(
                          "MENU_NAME",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "MENU_NAME",
                          language
                        )} (${languages_code})`}
                        hint="Enter text" // for bottom hint
                        className="form-control"
                        {...register(
                          `menu_name_${languages_id}`,
                        )}

                      />

                    </FormGroup>
                  </Col>



                  <Col col={6}>
                    <FormGroup mb="20px">
                      <Input

                        id={Trans("MENU_LABEL", language)}
                        label={`${Trans(
                          "MENU_LABEL",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "MENU_LABEL",
                          language
                        )} (${languages_code})`}
                        hint="Enter text" // for bottom hint
                        className="form-control"
                        {...register(
                          `menu_label_${languages_id}`,
                        )}

                      />

                    </FormGroup>
                  </Col>
                </>

              );
            })}



          <Col col={6}>
            <FormGroup mb="20px">
              <Label
                display="block"
                mb="5px"
                htmlFor={Trans("MENU_TYPE", language)}
              >
                {Trans("MENU_TYPE", language)}
              </Label>
              <select
                id={Trans("MENU_TYPE", language)}
                placeholder={Trans("MENU_TYPE", language)}
                className="form-control"
                {...register("menu_type", {
                  required: Trans("SELECT_MENU_TYPE_REQUIRED", language),
                })}
                onChange={(e) => {
                  e.preventDefault();
                  SetMenuType(parseInt(e.target.value));
                  setValue("menu_link", "#");
                }}

              // defaultValue={editInfo?.menu_type}

              >
                <option value="">{Trans("SELECT_MENU_TYPE", language)}</option>
                {(industry === '1' || industry === 1) &&
                  <option value="1">{Trans("CATEGORY", language)}</option>}
                <option value="2">{Trans("PAGE", language)}</option>
                <option value="3">{Trans("CUSTOM_LINK", language)}</option>
                {(industry === '2' || industry === 2) &&
                  <option value="4">{Trans("SERVICES", language)}</option>
                }
              </select>
              <span className="required">
                <ErrorMessage errors={errors} name="menu_type" />
              </span>
            </FormGroup>
          </Col>



          {MenuType === 2 && (

            <Col col={6}>
              <FormGroup mb="20px">
                <Input
                  type="hidden"
                  id={Trans("PAGE", language)}
                  label={Trans("PAGE", language)}
                  placeholder={Trans("PAGE", language)}
                  className="form-control"
                  {...register("menu_ref_id")}
                />

                {editInfo?.selected_pages && (
                  <Select
                    name={Trans("PAGE", language)}
                    options={pageListing}
                    defaultValue={editInfo?.selected_pages}
                    className="basic-multi-select"
                    classNamePrefix="select"
                    onChange={(newValue, actionMeta) => {
                      console.log(newValue);
                      setValue("menu_ref_id", newValue.value);
                    }}
                  />
                )}

                {/* <select
                  id={Trans("PAGE", language)}
                  placeholder={Trans("PAGE", language)}
                  className="form-control"
                  {...register("menu_ref_id", {
                    
                  })}
                
                  defaultValue={editInfo?.menu_ref_id}
                >
                  <option value="">{Trans("SELECT_PAGE", language)}</option>
                  {sectionListing?.page_data &&
                    sectionListing?.page_data.map((curr, idx) => (
                      <option value={curr.pages_id} key={idx}>
                        {curr.pages_slug}
                      </option>
                    ))}
                </select>
               */}
              </FormGroup>
            </Col>

          )}

          {MenuType === 1 && (
            <Col col={6}>
              <FormGroup mb="20px">
                {/* <Input
                      type="hidden"
                      id={Trans("CATEGORY", language)}
                      label={Trans("CATEGORY", language)}
                      placeholder={Trans("CATEGORY", language)}
                      className="form-control"
                      {...register("menu_ref_id")}
                    />


          
                    <Select
                      name={Trans("PAGE", language)}
                      options={categoryListing}
                      className="basic-multi-select"
                      defaultValue={editInfo?.selected_category}
                      classNamePrefix="select"
                      onChange={(newValue, actionMeta) => {
                         console.log(newValue);
                        setValue("menu_ref_id", newValue.value);
                      }}
                    />
                    */}

                <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("CATEGORY", language)}
                >
                  {Trans("CATEGORY", language)}
                </Label>

                <select
                  id={Trans("CATEGORY", language)}
                  placeholder={Trans("CATEGORY", language)}
                  className="form-control"
                  {...register("menu_ref_id", {
                  })}

                  defaultValue={editInfo?.menu_ref_id}
                >
                  <option value="0">{Trans("ALL", language)}</option>
                  {sectionListing?.category_data &&
                    sectionListing?.category_data.map((curr, idx) => (
                      <option value={curr.categories_id} key={idx}>
                        {curr.categories_slug}
                      </option>
                    ))}
                </select>
                <span className="required">
                  <ErrorMessage errors={errors} name="CATEGORY" />
                </span>
              </FormGroup>
            </Col>
          )}

          {MenuType === 3 && (
            <Col col={6}>
              <FormGroup mb="20px">
                <Input
                  id={Trans("MENU_LINK", language)}
                  label={Trans("MENU_LINK", language)}
                  placeholder={Trans("MENU_LINK", language)}
                  className="form-control"
                  {...register("menu_link",

                  )}
                />

              </FormGroup>
            </Col>
          )}

          {MenuType === 4 && (
            <Col col={6}>
              <FormGroup mb="20px">
                <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("BIZSERVICE", language)}
                >
                  {Trans("BIZSERVICE", language)}
                </Label>
                <select
                  id={Trans("BIZSERVICE", language)}
                  placeholder={Trans("BIZSERVICE", language)}
                  className="form-control"
                  {...register("menu_ref_id", {
                  })}
                  defaultValue={editInfo?.menu_ref_id}
                >
                  <option value="0">{Trans("All", language)}</option>
                  {sectionListing?.services_data &&
                    sectionListing?.services_data.map((curr, idx) => (
                      <option value={curr.categories_id} key={idx}>
                        {curr.categories_slug}
                      </option>
                    ))}
                </select>
                <span className="required">
                  <ErrorMessage errors={errors} name="BUSINESS_CATEGORY" />
                </span>
              </FormGroup>
            </Col>
          )}


          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("SORT_ORDER", language)}
                type="number"
                label={Trans("SORT_ORDER", language)}
                placeholder={Trans("SORT_ORDER", language)}
                className="form-control"
                {...register("sort_order", {
                  required: Trans("SORT_ORDER_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="sort_order" />
              </span>
            </FormGroup>
          </Col>


          <Col col={6} className="mb-10">
            <label>
              <b>
                {Trans("MENU_ICON")}
              </b>
            </label>
            <input type="hidden"
              {...register("menu_icon")} />
            <input
              placeholder="Setting Value"
              className="form-control"
              type="file"
              onChange={(event) =>
                HandleDocumentUpload(event, `fileupload`, `menu_icon`)
              }
            />

            <div id={`fileupload`} className="imageLoadedMessage">
              <img src={editInfo?.menu_icon_url} height="80" />
              {/* <p id="imageLoadedMessage"></p> */}
            </div>
          </Col> <br />




          {
            updateformloadingStatus ?
              <>   <Col col={12}><b>Uploading...</b> </Col>
              </>
              :
              <>
                <Col col={12}>
                  <LoaderButton
                    formLoadStatus={formloadingStatus}
                    btnName={Trans("UPDATE", language)}
                    className="btn btn-sm btn-bg btn-block"
                  />
                </Col>

              </>
          }




        </Row>
      </form>
    </React.Fragment>
  );
};


export default Edit;
