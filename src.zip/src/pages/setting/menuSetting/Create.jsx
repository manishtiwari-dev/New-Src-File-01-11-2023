import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { MenuStoreUrl, MenuCreateUrl, tempUploadFileUrl ,tempLandingUploadFileUrl} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  StatusSelect,
  Label,
  Input,
} from "component/UIElement/UIElement";
import { ErrorMessage } from "@hookform/error-message";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import Select from "react-select";


const Create = (props) => {

  const grpId = props.menuGroupId;
  const menuType = props.typeName;
  console.log(menuType);
  const { apiToken, language, industry ,userType} = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    formState: { errors },
    setValue,
    handleSubmit,
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    formData.api_token = apiToken;
    POST(MenuStoreUrl, formData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });
          props.handleModalClose();
          props.loadSettingData();
          props.filterItem();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              console.log(message[key][0]);
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = Trans(message, language);
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [sectionListing, SetSectionListing] = useState([]);
  const [pageListing, SetpageListing] = useState([]);
  const [categoryListing, SetcategoryListing] = useState([]);

  const [MenuType, SetMenuType] = useState([]);

  const [pageset, SetPageSet] = useState();
  const [langList, SetlangList] = useState([]);


  const ModuleLoad = () => {
    const filterData = {
      api_token: apiToken,
      group_id: grpId
    };

    POST(MenuCreateUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetSectionListing(data);
          SetMenuType(parseInt(data.menu_type));
          console.log(data.menu_type);
          SetlangList(data.language);
          SetpageListing(data.page_data);
          SetcategoryListing(data);

        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });

  };

  useEffect(() => {
    let abortController = new AbortController();
    ModuleLoad();
    return () => abortController.abort();
  }, []);

 

  const [updateformloadingStatus, SetupdateformloadingStatus] = useState(false);


  const HandleDocumentUpload = (event, previewUrlId, StoreID) => {
    SetupdateformloadingStatus(true);

    if (event.target.files[0] === "" || event.target.files[0] === undefined)
      return;

    var readers = new FileReader();
    readers.onload = function (e) {
      document.getElementById(
        previewUrlId
      ).innerHTML = `<img src=${e.target.result} height="100" />`;
    };
    readers.readAsDataURL(event.target.files[0]);

    // upload temp image and bind value to array
    const formdata = new FormData();
    // SetupdateformloadingStatus(false);

    formdata.append("api_token", apiToken);
    formdata.append("fileInfo", event.target.files[0]);
    formdata.append("images_type", 1);
    if(userType==="subscriber"){
    POST(tempUploadFileUrl, formdata)
      .then((response) => {
        SetupdateformloadingStatus(false);

        setValue(StoreID, response.data.data);
        //    SettempFile( response.data.data);
        // SetupdateformloadingStatus(false);


      })
      .catch((error) => {
        SetupdateformloadingStatus(false);

        Notify(false, error.message);
      });

    }

    else{

      POST(tempLandingUploadFileUrl, formdata)
      .then((response) => {
        SetupdateformloadingStatus(false);

        setValue(StoreID, response.data.data);
        //    SettempFile( response.data.data);
        // SetupdateformloadingStatus(false);


      })
      .catch((error) => {
        SetupdateformloadingStatus(false);

        Notify(false, error.message);
      });

    }
  };

  console.log(pageListing);

  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
      <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        <input
          type="hidden"
          {...register("group_id")}
          defaultValue={grpId}
        />
        <Row>

          {props.menuGroupId &&
            <Col col={6}>
              <FormGroup mb="20px">
                <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("PARENT_MENU", language)}
                >
                  {Trans("PARENT_MENU", language)}
                </Label>
                <select
                  id={Trans("PARENT_TYPE", language)}
                  placeholder={Trans("PARENT_MENU", language)}
                  className="form-control"
                  {...register("parent_id",

                  )}
                  defaultValue={0}

                >
                  <option value="">{Trans("SELECT_PARENT_MENU", language)}</option>
                  <option value="0">{Trans("----")}</option>
                  {sectionListing?.parent_type &&
                    sectionListing?.parent_type.map((curr, idx) => (
                      <>
                        {curr?.menu_details &&
                          curr?.menu_details.map((cur, Idx) => (
                            <option value={cur.menu_id} key={idx}>
                              {cur.menu_name}
                            </option>

                          ))}
                      </>
                    ))}
                </select>

              </FormGroup>
            </Col>
          }

          {langList &&
            langList.map((lang) => {
              const {
                languages_code,
                languages_id,
                languages_name,
              } = lang;
              return (
                <>
                  <Col col={6}>
                    <FormGroup mb="20px">
                      <Input
                        id={Trans("MENU_NAME", language)}
                        label={`${Trans(
                          "MENU_NAME",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "MENU_NAME",
                          language
                        )} (${languages_code})`}
                        hint="Enter text" // for bottom hint
                        className="form-control"
                        {...register(
                          `menu_name_${languages_id}`,
                          {
                            required: Trans("MENU_NAME_REQUIRED", language),
                          })}

                      />
                      {/* <span className="required">
                <ErrorMessage errors={errors} name="menu_name_${languages_id}" />
              </span> */}
                    </FormGroup>
                  </Col>



                  <Col col={6}>
                    <FormGroup mb="20px">
                      <Input

                        id={Trans("MENU_LABEL", language)}
                        label={`${Trans(
                          "MENU_LABEL",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "MENU_LABEL",
                          language
                        )} (${languages_code})`}
                        hint="Enter text" // for bottom hint
                        className="form-control"
                        {...register(
                          `menu_label_${languages_id}`
                        )}

                      />

                    </FormGroup>
                  </Col>
                </>
              );
            })}



          <Col col={6}>
            <FormGroup mb="20px">
              <Label
                display="block"
                mb="5px"
                htmlFor={Trans("MENU_TYPE", language)}
              >
                {Trans("MENU_TYPE", language)}
              </Label>
              <select
                id={Trans("MENU_TYPE", language)}
                placeholder={Trans("MENU_TYPE", language)}
                className="form-control"
                {...register("menu_type", {
                  required: Trans("SELECT_MENU_TYPE_REQUIRED", language),
                })}
                onChange={(e) => {
                  e.preventDefault();
                  SetMenuType((e.target.value));
                  // setValue("menu_link", "#");
                }}

              >
                <option value="">{Trans("SELECT_MENU_TYPE", language)}</option>
                {(industry === '1' || industry === 1) &&
                  <option value="1">{Trans("CATEGORY", language)}</option>}
                <option value="2">{Trans("PAGE", language)}</option>
                <option value="3">{Trans("CUSTOM_LINK", language)}</option>
                {(industry === '2' || industry === 2) &&
                  <option value="4">{Trans("SERVICES", language)}</option>
                }

              </select>
              <span className="required">
                <ErrorMessage errors={errors} name="menu_type" />
              </span>
            </FormGroup>
          </Col>

          {MenuType === '3' && (
            <Col col={6}>
              <FormGroup mb="20px">
                <Input
                  id={Trans("MENU_LINK", language)}
                  label={Trans("MENU_LINK", language)}
                  placeholder={Trans("MENU_LINK", language)}
                  className="form-control"
                  {...register("menu_link",

                  )}
                />

              </FormGroup>
            </Col>
          )}

          {MenuType === '2' && (

            <Col col={6}>
              <FormGroup mb="20px">
                {/* <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("PAGE", language)}
                >
                  {Trans("PAGE", language)}
                </Label> */}


                <Input
                  type="hidden"
                  id={Trans("PAGE", language)}
                  label={Trans("PAGE", language)}
                  placeholder={Trans("PAGE", language)}
                  className="form-control"
                  {...register("menu_ref_id")}
                />

                <Select
                  name={Trans("PAGE", language)}
                  options={pageListing}
                  className="basic-multi-select"
                  classNamePrefix="select"
                  onChange={(newValue, actionMeta) => {
                    console.log(newValue);
                    setValue("menu_ref_id", newValue.value);
                  }}
                />
                {/* <select
                  id={Trans("PAGE", language)}
                  placeholder={Trans("PAGE", language)}
                  className="form-control"
                  {...register("menu_ref_id", 
                   
                  )}
                
                 
                >
                  <option value="">{Trans("SELECT", language)}</option>
                  {sectionListing?.page_data &&
                    sectionListing?.page_data.map((curr, idx) => (
                      <option value={curr.pages_id} key={idx}>
                        {curr.pages_slug}
                      </option>
                    ))}
                </select> */}
              </FormGroup>
            </Col>

          )}


          {MenuType === '1' && (
            <Col col={6}>
              <FormGroup mb="20px">

                {/* <Input
                      type="hidden"
                      id={Trans("CATEGORY", language)}
                      label={Trans("CATEGORY", language)}
                      placeholder={Trans("CATEGORY", language)}
                      className="form-control"
                      {...register("menu_ref_id")}
                    /> */}

                {/* <Select
                      name={Trans("PAGE", language)}
                      options={categoryListing}
                      className="basic-multi-select"
                      classNamePrefix="select"
                      onChange={(newValue, actionMeta) => {
                         console.log(newValue);
                        setValue("menu_ref_id", newValue.value);
                      }}
                    /> */}

                <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("CATEGORY", language)}
                >
                  {Trans("CATEGORY", language)}
                </Label>



                <select
                  id={Trans("CATEGORY", language)}
                  placeholder={Trans("CATEGORY", language)}
                  className="form-control"
                  {...register("menu_ref_id",

                  )}



                >
                  <option value="0">{Trans("ALL", language)}</option>
                  {sectionListing?.category_data &&
                    sectionListing?.category_data.map((curr, idx) => (
                      <option value={curr.categories_id} key={idx}>
                        {curr.categories_slug}
                      </option>
                    ))}
                </select>

              </FormGroup>
            </Col>
          )}

          {MenuType === '4' && (
            <Col col={6}>
              <FormGroup mb="20px">
                <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("BIZSERVICE", language)}
                >
                  {Trans("BIZSERVICE", language)}
                </Label>
                <select
                  id={Trans("BIZSERVICE", language)}
                  placeholder={Trans("BIZSERVICE", language)}
                  className="form-control"
                  {...register("menu_ref_id", {
                  })}

                >
                  <option value="0">{Trans("All", language)}</option>
                  {sectionListing?.services_data &&
                    sectionListing?.services_data.map((curr, idx) => (
                      <option value={curr.categories_id} key={idx}>
                        {curr.categories_slug}
                      </option>
                    ))}
                </select>
                <span className="required">
                  <ErrorMessage errors={errors} name="BUSINESS_CATEGORY" />
                </span>
              </FormGroup>
            </Col>
          )}

          <Col col={6} className="mb-10">
            <label>
              <b>
                {Trans("MENU_ICON")}
              </b>
            </label>
            <input type="hidden"
              {...register("menu_icon",

              )} />
            <input
              placeholder="Setting Value"
              className="form-control"
              type="file"
              onChange={(event) =>
                HandleDocumentUpload(event, `fileupload`, `menu_icon`)
              }
            />

            <div id={`fileupload`}></div>
          </Col> <br />



          {
            updateformloadingStatus ?
              <>   <Col col={12}><b>Uploading...</b> </Col>
              </>
              :
              <>
                <Col col={12} className="mt-2">
                  <LoaderButton
                    formLoadStatus={formloadingStatus}
                    btnName={Trans("SUBMIT", language)}
                    className="btn btn-sm btn-bg btn-block"
                  />
                </Col>

              </>
          }



        </Row>
      </form>
    </>
  );
};

export default Create;
