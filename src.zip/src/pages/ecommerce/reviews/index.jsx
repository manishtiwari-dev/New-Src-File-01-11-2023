import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { ReviewsUrl, ReviewsChangeStatusUrl } from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import Pagination from "component/pagination/index";
import ExportButton from "component/ExportButton";
import SearchBox from "component/SearchBox";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Create from "./create";
import RecordPerPage from "component/RecordPerPage";
import Table from "./component/Table";
import Notify from "component/Notify";
import { PageReview, PreView, PreExport } from "config/PermissionName";
import FeatherIcon from "feather-icons-react";

function Index() {
  const { apiToken, language } = useSelector((state) => state.login);
  const [dataList, SetdataList] = useState([]);
  const [filterDataList, SetfilterDataList] = useState([]);
  const [Pagi, SetPagi] = useState(0);
  const [currPage, SetcurrPage] = useState(0);
  const [searchItem, SetSEarchItem] = useState("");
  const [sortByS, SetsortByS] = useState("quotation_id");
  const [orderByS, SetOrderByS] = useState("DESC");
  const [perPageItem, SetPerPageItem] = useState("");
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const showColumn = [];

  const getData = (pagev, perPageItemv, searchData, sortBys, OrderBy) => {
    SetloadingStatus(true);
    const filterData = {
      api_token: apiToken,
      page: pagev,
      perPage: perPageItemv,
      search: searchData,
      sortBy: sortBys,
      orderBY: OrderBy,
      language: language,
    };
    POST(ReviewsUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetdataList(data.data);
          SetPagi(data.total_page);
          SetcurrPage(data.current_page);
          SetPerPageItem(data.per_page);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  const filterItem = (name, value, other) => {
    switch (name) {
      case "perpage":
        SetloadingStatus(true);
        const per = Number(value);
        SetPerPageItem(per);
        getData(1, per, searchItem, sortByS, orderByS);
        break;
      case "searchbox":
        SetSEarchItem(value);
        getData(1, perPageItem, value, sortByS, orderByS);
        break;
      case "sortby":
        SetOrderByS(other);
        SetsortByS(value);
        getData(1, perPageItem, searchItem, value, other);
        break;
      case "pagi":
        SetcurrPage(value);
        getData(value, perPageItem, searchItem, sortByS, orderByS);
        break;
      default:
        getData(currPage, perPageItem, searchItem, sortByS, orderByS);
        break;
    }
  };

  useEffect(() => {
    document.title = "Reviews | WorkerMan";
    let abortController = new AbortController();
    filterItem("refresh", "", "");
    return () => abortController.abort();
  }, []);

  const ChangeFunction = (quoteId, statusId) => {
    const editData = {
      api_token: apiToken,
      reviews_id: quoteId,
      status: statusId,
    };
    POST(ReviewsChangeStatusUrl, editData)
      .then((response) => {
        const { message } = response.data;
        filterItem("refresh", "", "");
        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };
  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  return (
    <Content>
      <div className="row row-xs">
        <div className="col-sm-12 col-lg-12">
          <CheckPermission
            PageAccess={PageReview}
            PageAction={PreView}>
            <div
              className="card"
              id="custom-user-list">
              <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                <h6 className=" tx-semibold mg-b-0">
                  {Trans("REVIEWS", language)}
                </h6>
                <div className="d-none d-md-flex">
                  <Button
                    variant="primary"
                    className=" btn-sm btn-bg"
                    onClick={handleModalShow}>
                    <FeatherIcon
                      icon="plus"
                      fill="white"
                      className="wd-10 mg-r-5"
                    />
                    {Trans("ADD_REVIEWS", language)}
                  </Button>{" "}
                </div>
              </div>
              <div className="card-body">
                <div className="d-flex">
                  <div className="">
                    <RecordPerPage
                      filterItem={filterItem}
                      perPageItem={perPageItem}
                    />
                  </div>
                  <div className="mx-3">
                    <SearchBox filterItem={filterItem} />
                  </div>
                </div>
                {contentloadingStatus ? (
                  <Loading />
                ) : (
                  <div className="row">
                    <Table
                      showColumn={showColumn}
                      dataList={dataList}
                      pageName={PageReview} // for checkpermission
                      sortBy={sortByS}
                      orderBy={orderByS}
                      filterItem={filterItem}
                      updateStatusFunction={ChangeFunction}
                      mainKey="reviews_id"
                      perPage={perPageItem}
                      curPage={currPage}
                    />
                    <Pagination
                      totalPage={Pagi}
                      // currPage={currPage}
                      filterItem={filterItem}
                    />
                  </div>
                )}
              </div>
            </div>
          </CheckPermission>
        </div>
      </div>
      {/* add modal */}
      <Modal
        show={show}
        onHide={handleModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("ADD_REVIEWS", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Create
            filterItem={filterItem}
            handleModalClose={handleModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
    </Content>
  );
}

export default Index;
