import React from "react";
import Currency from "hooks/currency";
import { Trans } from "lang";
import { BadgeShow } from "component/UIElement/UIElement";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { useState } from "react";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  IconButton,
  Label,
} from "component/UIElement/UIElement";
import {
  Productsizedelete,
  Productoptionstatuschange,
  Productsortorder,
  productOptionsvalueUrl,
} from "config/index";
import Moment from "react-moment";
import Notify from "component/Notify";
import Loading from "component/Preloader";
import { ErrorMessage } from "@hookform/error-message";
import FeatherIcon from "feather-icons-react";
import POST from "axios/post";
import Chart from "react-apexcharts";
// import ReactFlot from 'react-flot';

import Content from "layouts/content";

import PageHeader from "component/PageHeader";

import { DashboardUrl } from "config/index";

import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { Modal, Button } from "react-bootstrap";

function SalesDashboardModel({ dashboardcontent, filterItem, editId }) {
  // console.log("transactionLog", JSON.parse(dashboardcontent));
  const [transaction, setTransaction] = useState([]);
  const { apiToken, language } = useSelector((state) => state.login);

  // delete item
  const deleteFeatuerdProduct = (deleteId) => {
    const editInfo = {
      api_token: apiToken,

      products_options_values_id: deleteId,
    };
    POST(Productsizedelete, editInfo)
      .then((response) => {
        const { status, message } = response.data;
        getData();
        Notify(true, Trans(message, language));
        // getTemplateComponentList();
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const StatusChnageFun = (edit_id) => {
    const editData = {
      api_token: apiToken,
      products_options_values_id: edit_id,
      // status: type,
    };
    POST(Productoptionstatuschange, editData)
      .then((response) => {
        const { message, data } = response.data;
        // RefreshList();
        getData();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  const getData = () => {
    SetloadingStatus(true);
    const filterData = {
      api_token: apiToken,
      products_options_id: editId,
    };
    POST(productOptionsvalueUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          setTransaction(data);
          data.map((e) => {
            if (e.products_options_id === transaction.products_options_id)
              setTransaction(e);
          });
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };
  useEffect(() => {
    let abortController = new AbortController();
    // deleteFeatuerdProduct();
    getData();
    // setTransaction([JSON.parse(dashboardcontent)]);
    return () => abortController.abort();
  }, []);

  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const SortOrderUpdate = (e, main_id, edit_id, endit_name) => {
    const editData = {
      api_token: apiToken,

      products_options_id: main_id,
      products_options_values_id: edit_id,
      products_options_values_name: endit_name,
      sort_order: e.target.value,
    };
    POST(Productsortorder, editData)
      .then((response) => {
        const { message, data } = response.data;

        // update side module and section
        // dispatch(updateModuleListState(data));
        // RefreshList();
        getData();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  return (
    <React.Fragment>
      <React.Fragment>
        <Row>
          <Col col={12}>
            <div className="card" id="custom-user-list">
              <div className="card-body">
                <Row>
                  <Col col={12}>
                    <div className="table-responsive">
                      <table
                        className="module_details mb-4"
                        cellSpacing="0"
                        rules="all"
                        border="1"
                        id=""
                        style={{ borderCollapse: "collapse", width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th className="text-center">Section</th>

                            <th className="text-center">Status</th>

                            <th className="text-center">Sort Order</th>
                            <th className="text-center">Action </th>
                          </tr>
                        </thead>

                        {transaction &&
                          transaction.map((nesteddata, IDX) => {
                            return (
                              <tbody>
                                <tr>
                                  <td
                                    style={{
                                      paddingLeft: "1.4rem",
                                    }}
                                  >
                                    {nesteddata.products_options_values_name}
                                  </td>
                                  <td
                                    style={{
                                      paddingLeft: "1.4rem",
                                    }}
                                  >
                                    <label className="custom-control custom-switch">
                                      <input
                                        type="checkbox"
                                        class="custom-control-input"
                                        id={`${nesteddata.products_options_values_id}`}
                                        checked={
                                          nesteddata.status === 0
                                            ? ""
                                            : "checked"
                                        }
                                        onClick={(e) => {
                                          StatusChnageFun(
                                            nesteddata.products_options_values_id
                                          );
                                          // e.preventDefault();
                                          // filterItem("refresh", "", "");
                                          getData();
                                        }}
                                      />
                                      <label
                                        className="custom-control-label"
                                        For={`${nesteddata.products_options_values_id}`}
                                      ></label>
                                    </label>
                                  </td>
                                  <td
                                    style={{
                                      paddingLeft: "1.4rem",
                                    }}
                                  >
                                    <input
                                      type="number"
                                      style={{ width: 50 }}
                                      defaultValue={nesteddata.sort_order}
                                      onBlur={(e) => {
                                        SortOrderUpdate(
                                          e,
                                          nesteddata.products_options_id,
                                          nesteddata.products_options_values_id,
                                          nesteddata.products_options_values_name
                                        );
                                        // filterItem("refresh", "", "");
                                      }}
                                    />
                                  </td>
                                  <td className="text-center">
                                    <button type="button" className="btn btn">
                                      <FeatherIcon
                                        icon="trash-2"
                                        size={20}
                                        onClick={() => {
                                          deleteFeatuerdProduct(
                                            nesteddata.products_options_values_id
                                          );
                                        }}
                                      />
                                    </button>
                                  </td>
                                </tr>
                              </tbody>
                            );
                          })}
                      </table>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </Col>
          <Col col={12}></Col>
        </Row>
      </React.Fragment>
      {/* )} */}
    </React.Fragment>
  );
}

export default SalesDashboardModel;
