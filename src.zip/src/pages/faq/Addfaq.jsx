import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { ErrorMessage } from "@hookform/error-message";
import Accordion from "react-bootstrap/Accordion";
import AddOptions from "./Addgroup";
import Editoption from "./Editgroup";
import Editfaq from "./Editfaq";
import MyEditor from "component/MyEditor";
import {
  couponUrlAll,
  couponChangeStatusUrl,
  languageDeleteUrl,
  coupondeleteUrl,
  Faqliststore,
} from "config";
import {
  moduleChangeStatusUrl,
  moduleUpdateSortOrderUrl,
  Faqlist,
} from "config/index";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
} from "component/UIElement/UIElement";
import POST from "axios/post";
import { useSelector, useDispatch } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import Pagination from "component/pagination/index";
import ExportButton from "component/ExportButton";
import SearchBox from "component/SearchBox";
import RecordPerPage from "component/RecordPerPage";
import TreeComponent from "pages/module/component/index/TreeComponent";
import { Badge, IconButton, Anchor } from "component/UIElement/UIElement";

import { Modal, Button } from "react-bootstrap";

import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { PageModule, PreAdd, PreView, PreExport } from "config/PermissionName";
// import SubModuleEdit from "./component/index/SubModuleEdit";

import { updateModuleListState } from "redux/slice/loginSlice";

function Index(props) {
  const { apiToken, language } = useSelector((state) => state.login);
  const [dataList, SetdataList] = useState([]);

  const [Pagi, SetPagi] = useState(0);
  const [currPage, SetcurrPage] = useState(0);
  const [searchItem, SetSEarchItem] = useState("");
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");
  const [perPageItem, SetPerPageItem] = useState(10);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const filterItem = (name, value, other) => {
    switch (name) {
      case "perpage":
        SetloadingStatus(true);
        const per = Number(value);
        SetPerPageItem(per);
        getData(1, per, searchItem, sortByS, orderByS);
        break;
      case "searchbox":
        SetSEarchItem(value);
        getData(1, perPageItem, value, sortByS, orderByS);
        break;
      case "sortby":
        SetOrderByS(other);
        SetsortByS(value);
        getData(1, perPageItem, searchItem, value, other);
        break;
      case "pagi":
        SetcurrPage(value);
        getData(value, perPageItem, searchItem, sortByS, orderByS);
        break;
      default:
        getData(currPage, perPageItem, searchItem, sortByS, orderByS);
        break;
    }
  };
  const getData = (pagev, perPageItemv, searchData, sortBys, OrderBy) => {
    SetloadingStatus(true);
    const filterData = {
      api_token: apiToken,
      page: pagev,
      perPage: perPageItemv,
      search: searchData,
      sortBy: sortBys,
      orderBY: OrderBy,
    };
    POST(Faqlist, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetdataList(data.data_list);
          SetPagi(data.total_page);
          SetcurrPage(data.current_page);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();

    getData(1, perPageItem, searchItem, sortByS, orderByS);
    return () => abortController.abort();
  }, []);

  const [addModuleShow, setAddModuleShow] = useState(false);
  const handleModalClose = () => setAddModuleShow(false);
  const handleModalShow = () => setAddModuleShow(true);

  const [addSubModuleShow, SetSubAddModuleShow] = useState(false);
  const handleSubModuleModalClose = () => SetSubAddModuleShow(false);
  const handleSubModuleModalShow = () => SetSubAddModuleShow(true);

  const deleteItem = (deleteID) => {
    const infoData = {
      api_token: apiToken,
      coupon_id: deleteID,
    };
    POST(coupondeleteUrl, infoData)
      .then((response) => {
        const { message } = response.data;
        filterItem("refresh", "", "");
        getData(1, perPageItem, searchItem, sortByS, orderByS);
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };
  const [subeditdata, SetsubEditData] = useState();
  const [editSubmodule, SeteditSubmodule] = useState(false);
  const handleeditSubModuleModalClose = () => SetsubEditData(false);
  const handleeditSubModuleModalShow = () => SetsubEditData(true);
  const [editoption, seteditoption] = useState("");
  const [editoptionid, seteditoptionid] = useState("");

  const [editfaqoption, seteditfaqoption] = useState("");
  const [editfaqoptionid, seteditfaqoptionid] = useState("");
  const StatusChnageFun = (edit_id, status) => {
    const editData = {
      api_token: apiToken,
      coupon_id: edit_id,
      status: status,
    };
    POST(couponChangeStatusUrl, editData)
      .then((response) => {
        const { message, data } = response.data;
        // update side module and section
        RefreshList();
        getData(1, perPageItem, searchItem, sortByS, orderByS);

        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  const RefreshList = () => {
    filterItem("refresh", "", "");
  };

  const [Displaceholder, Setdisplaceholder] = useState("");
  const discountshow = (e) => {
    // Sdiscountamtbox(true);
    Setdisplaceholder(e);
  };
  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
  } = useForm();

  const [editid, Seteditid] = useState();

  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    POST(Faqliststore, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.handleModalClose();
          Notify(true, Trans(message, language));
          props.filterItem("refresh", "", "");
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  return (
    <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
      <Row>
        <Col col={6}>
          <FormGroup mb="20px">
            <Label display="block" mb="5px" htmlFor={Trans("GROUP", language)}>
              {Trans("GROUP", language)}
            </Label>
            <select
              id={Trans("GROUP", language)}
              placeholder={Trans("GROUP", language)}
              className="form-control"
              {...register("group_id", {
                required: Trans("GROUP_IS_REQUIRED", language),
              })}
            >
              <option value="" selected disabled>
                {Trans("CHOOSE_GROUP", language)}
              </option>

              {dataList.map((data) => {
                const { group_id, group_key, group_name, sort_order, status } =
                  data;
             
                return (
                  <option value={group_id} key={group_key}>
                    {group_name}
                  </option>
                );
              })}
            </select>

            <span className="required">
              <ErrorMessage errors={errors} name="group_id" />
            </span>
          </FormGroup>
        </Col>
        <Col col={6}>
          <FormGroup mb="20px">
            <Input
              id={Trans("QUESTION", language)}
              label={Trans("QUESTION", language)}
              placeholder={Trans("QUESTION", language)}
              className="form-control"
              {...register("question", {
                required: Trans("QUESTION_REQUIRED", language),
              })}
            />
            <span className="required">
              <ErrorMessage errors={errors} name="question" />
            </span>
          </FormGroup>
          </Col>
          <Col col={12}>
            <FormGroup>
              <Label>{Trans("ANSWER", language)}</Label>
              <MyEditor
                setKey={`answer`}
                updateFun={(Key, Value) => {
                  setValue(Key, Value);
                }}
              />
              <textarea
                {...register("answer", {
                  required: Trans("ANSWER_REQUIRED", language),
                })}
                style={{ display: "none" }}
              ></textarea>
                <span className="required">
              <ErrorMessage errors={errors} name="answer" />
            </span>
            </FormGroup>
          
       
        </Col>
        <Col col={2}>
          <LoaderButton
            formLoadStatus={formloadingStatus}
            btnName={Trans("SUBMIT", language)}
            className="btn btn-sm btn-bg btn-block"
          />
        </Col>
      </Row>
    </form>
  );
}

export default Index;
