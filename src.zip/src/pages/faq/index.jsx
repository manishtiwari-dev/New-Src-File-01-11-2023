import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { ErrorMessage } from "@hookform/error-message";
import AddOptions from "./Addgroup";
import Editgroup from "./Editgroup";
import Editfaq from "./Editfaq";
import DOMPurify from "dompurify";

import Addfaq from "./Addfaq";
import {
  couponUrlAll,
  couponChangeStatusUrl,
  FaqsortOrder,
  coupondeleteUrl,
  Faqliststore,
  FaqChangestatus,
} from "config";
import {
  moduleChangeStatusUrl,
  moduleUpdateSortOrderUrl,
  Faqlist,
} from "config/index";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
  Accordion,
} from "component/UIElement/UIElement";
import POST from "axios/post";
import { useSelector, useDispatch } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import Pagination from "component/pagination/index";
import ExportButton from "component/ExportButton";
import SearchBox from "component/SearchBox";
import RecordPerPage from "component/RecordPerPage";
import TreeComponent from "pages/module/component/index/TreeComponent";
import { Badge, IconButton, Anchor } from "component/UIElement/UIElement";
import { Modal, Button } from "react-bootstrap";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import {
  PageWebFaq,
  PreAdd,
  PreView,
  PreExport,
  SuperPageWebFaq,
  PreUpdate,
} from "config/PermissionName";

function Index() {
  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [dataList, SetdataList] = useState([]);
  const [Pagi, SetPagi] = useState(0);
  const [currPage, SetcurrPage] = useState(0);
  const [searchItem, SetSEarchItem] = useState("");
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");
  const [perPageItem, SetPerPageItem] = useState(10);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const filterItem = (name, value, other) => {
    switch (name) {
      case "perpage":
        SetloadingStatus(true);
        const per = Number(value);
        SetPerPageItem(per);
        getData(1, per, searchItem, sortByS, orderByS);
        break;
      case "searchbox":
        SetSEarchItem(value);
        getData(1, perPageItem, value, sortByS, orderByS);
        break;
      case "sortby":
        SetOrderByS(other);
        SetsortByS(value);
        getData(1, perPageItem, searchItem, value, other);
        break;
      case "pagi":
        SetcurrPage(value);
        getData(value, perPageItem, searchItem, sortByS, orderByS);
        break;
      default:
        getData(currPage, perPageItem, searchItem, sortByS, orderByS);
        break;
    }
  };
  const getData = (pagev, perPageItemv, searchData, sortBys, OrderBy) => {
    SetloadingStatus(true);
    const filterData = {
      api_token: apiToken,
      page: pagev,
      perPage: perPageItemv,
      search: searchData,
      sortBy: sortBys,
      orderBY: OrderBy,
    };
    POST(Faqlist, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetdataList(data.data_list);
          SetPagi(data.total_page);
          SetcurrPage(data.current_page);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    getData(1, perPageItem, searchItem, sortByS, orderByS);
    return () => abortController.abort();
  }, []);

  const [addModuleShow, setAddModuleShow] = useState(false);
  const handleModalClose = () => setAddModuleShow(false);
  const handleModalShow = () => setAddModuleShow(true);
  const [addSubModuleShow, SetSubAddModuleShow] = useState(false);
  const handleSubModuleModalClose = () => SetSubAddModuleShow(false);
  const handleSubModuleModalShow = () => SetSubAddModuleShow(true);

  const deleteItem = (deleteID) => {
    const infoData = {
      api_token: apiToken,
      coupon_id: deleteID,
    };
    POST(coupondeleteUrl, infoData)
      .then((response) => {
        const { message } = response.data;
        filterItem("refresh", "", "");
        getData(1, perPageItem, searchItem, sortByS, orderByS);
        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };
  const [subeditdata, SetsubEditData] = useState();
  const [editSubmodule, SeteditSubmodule] = useState(false);
  const handleeditSubModuleModalClose = () => SetsubEditData(false);
  const handleeditSubModuleModalShow = () => SetsubEditData(true);
  const [editoption, seteditoption] = useState("");
  const [editoptionid, seteditoptionid] = useState("");

  const [editfaqoption, seteditfaqoption] = useState("");
  const [editfaqoptionid, seteditfaqoptionid] = useState("");
  const StatusChnageFun = (edit_id, type) => {
    const editData = {
      api_token: apiToken,
      update_id: edit_id,
      // status: status,
      type: type,
    };
    POST(FaqChangestatus, editData)
      .then((response) => {
        const { message, data } = response.data;
        // update side module and section
        RefreshList();
        getData(1, perPageItem, searchItem, sortByS, orderByS);

        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };
  const SortOrderUpdate = (e, edit_id, type) => {
    const editData = {
      api_token: apiToken,
      update_id: edit_id,
      sort_order: e.target.value,
      type: type,
    };
    POST(FaqsortOrder, editData)
      .then((response) => {
        const { message, data } = response.data;

        // update side module and section
        // dispatch(updateModuleListState(data));
        getData();
        RefreshList();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {});
  };
  const RefreshList = () => {
    filterItem("refresh", "", "");
  };

  const [Displaceholder, Setdisplaceholder] = useState("");
  const discountshow = (e) => {
    // Sdiscountamtbox(true);
    Setdisplaceholder(e);
  };
  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
  } = useForm();

  const [editid, Seteditid] = useState();

  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    POST(Faqliststore, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          // props.handleModalClose();
          Notify(true, Trans(message, language));
          // props.filterItem("refresh", "", "");
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const page_access = userType == "subscriber" ? PageWebFaq : SuperPageWebFaq;

  function removeHtmlTags(html) {
    const sanitizedHtml = DOMPurify.sanitize(html, {
      ADD_ATTR: ["style"],
      ADD_TAGS: ["span"],
    });
    return sanitizedHtml;
  }

  return (
    <Content>
      <div className="row row-xs">
        <div className="col-sm-12 col-lg-12">
          <CheckPermission
            PageAccess={page_access}
            PageAction={PreView}>
            <div
              className="card"
              id="custom-user-list">
              <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                <h6 className=" tx-semibold mg-b-0">
                  {Trans("FAQ", language)}
                </h6>
                <div className=" d-md-flex">
                  <CheckPermission
                    PageAccess={page_access}
                    PageAction={PreAdd}>
                    <Button
                      // variant="primary"
                      onClick={handleSubModuleModalShow}
                      className="btn-sm btn-bg">
                      <FeatherIcon
                        fill="white"
                        icon="plus"
                        className="wd-10 mg-r-6"
                      />
                      {Trans("ADD_GROUP", language)}
                    </Button>
                    &nbsp;&nbsp;
                    <Button
                      variant="primary"
                      onClick={handleeditSubModuleModalShow}
                      className="btn-sm btn-bg">
                      <FeatherIcon
                        icon="plus"
                        fill="white"
                        className="wd-10 mg-r-6"
                      />
                      {Trans("ADD_FAQ", language)}
                    </Button>
                  </CheckPermission>
                </div>
              </div>

              {/* <div className="card-body"> */}
              {dataList &&
                dataList.map((data, indx) => {
                  const { sort_order } = data;
                  return (
                    <div
                      className="card my-3"
                      id="custom-user-list">
                      <div className="card-body">
                        <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                          <h6 className=" tx-semibold mg-b-0">
                            {Trans(`${data.group_name}`, language)} (GroupID
                            {data.group_id})
                          </h6>
                          <div
                            className=" d-md-flex"
                            style={{ alignItems: "center" }}>
                            {/* PageAccess={PageWebFaq} PageAction={PreAdd} */}
                            <input
                              type="number"
                              style={{ width: 50 }}
                              defaultValue={sort_order}
                              onBlur={(e) => {
                                SortOrderUpdate(e, data.group_id, "");
                              }}
                            />
                            &nbsp;&nbsp;
                            <CheckPermission
                              PageAccess={page_access}
                              PageAction={PreUpdate}>
                              <IconButton
                                color="primary"
                                onClick={() => {
                                  seteditoption(true);
                                  seteditoptionid(data.group_id);
                                }}>
                                <FeatherIcon
                                  icon="edit-2"
                                  fill="white"
                                  className="wd-10 mg-r-6"
                                  onClick={() => {
                                    seteditoption(true);
                                    seteditoptionid(data.group_id);
                                  }}
                                />
                              </IconButton>
                            </CheckPermission>
                            &nbsp;&nbsp; &nbsp;&nbsp;
                            <div className="custom-control custom-switch">
                              <input
                                onClick={() => {
                                  StatusChnageFun(data.group_id, "");
                                  // filterItem("refresh", "", "");
                                }}
                                type="checkbox"
                                class="custom-control-input"
                                id={`customSwitch${data.group_id}module`}
                                checked={data.status === 0 ? "" : "checked"}
                              />
                              <label
                                className="custom-control-label"
                                For={`customSwitch${data.group_id}module`}></label>
                            </div>
                          </div>
                        </div>
                        {data?.faq_list.map((list, index) => {
                          const { id, sort_order } = list;
                          const sanitizedHtml = removeHtmlTags(list.answer);

                          return (
                            <>
                              <Accordion
                                title={list.question}
                                content={
                                  <div
                                    dangerouslySetInnerHTML={{
                                      __html: sanitizedHtml,
                                    }}></div>
                                }
                                extra={
                                  <div className=" d-md-flex btns">
                                    <input
                                      type="number"
                                      style={{ width: 50 }}
                                      defaultValue={sort_order}
                                      onBlur={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                        SortOrderUpdate(e, list.id, "faq");
                                      }}
                                      onClick={(e) => {
                                        e.preventDefault();
                                        e.stopPropagation();
                                      }}
                                    />
                                    &nbsp;&nbsp;
                                    <CheckPermission
                                      PageAccess={page_access}
                                      PageAction={PreUpdate}>
                                      <IconButton
                                        color="primary"
                                        onClick={(e) => {
                                          e.preventDefault();
                                          e.stopPropagation();
                                          seteditfaqoption(true);
                                          seteditfaqoptionid(id);
                                        }}>
                                        <FeatherIcon
                                          icon="edit-2"
                                          fill="white"
                                          className="wd-10 mg-r-6"
                                          onClick={(e) => {
                                            e.preventDefault();
                                            e.stopPropagation();
                                            seteditfaqoption(true);
                                            seteditfaqoptionid(id);
                                          }}
                                        />

                                        {/* </Button> */}
                                      </IconButton>
                                    </CheckPermission>
                                    &nbsp;&nbsp; &nbsp;&nbsp;
                                    <div className="custom-control custom-switch">
                                      <input
                                        onClick={() => {
                                          StatusChnageFun(list.id, "faq");
                                          // filterItem("refresh", "", "");
                                        }}
                                        type="checkbox"
                                        class="custom-control-input"
                                        id={`customSwitch${list.question}module`}
                                        checked={
                                          list.status === 0 ? "" : "checked"
                                        }
                                      />
                                      <label
                                        className="custom-control-label"
                                        For={`customSwitch${list.question}module`}></label>
                                    </div>
                                  </div>
                                }
                              />
                            </>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              {/* </div> */}
            </div>
          </CheckPermission>
        </div>
      </div>

      <Modal
        show={subeditdata}
        onHide={() => {
          handleeditSubModuleModalClose();
        }}
        size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("ADD_FAQ", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              handleeditSubModuleModalClose();
            }}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Addfaq
            // editData={editid}
            filterItem={filterItem}
            handleModalClose={handleeditSubModuleModalClose}
          />
        </Modal.Body>
      </Modal>

      <Modal
        show={addSubModuleShow}
        onHide={handleSubModuleModalClose}
        size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("ADD_GROUP", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={handleSubModuleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <AddOptions
            filterItem={filterItem}
            handleModalClose={handleSubModuleModalClose}
          />
        </Modal.Body>
      </Modal>

      <Modal
        show={editoption}
        onHide={() => {
          seteditoption(false);
        }}
        size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("EDIT_GROUP_NAME", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              seteditoption(false);
            }}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Editgroup
            editId={editoptionid}
            RefreshList={RefreshList}
            // optionList={dataList}
            handleModalClose={() => {
              seteditoption(false);
            }}
          />
        </Modal.Body>
      </Modal>

      <Modal
        show={editfaqoption}
        onHide={() => {
          seteditfaqoption(false);
        }}
        size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("EDIT_FAQ", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              seteditfaqoption(false);
            }}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Editfaq
            editId={editfaqoptionid}
            RefreshList={RefreshList}
            // optionList={dataList}
            handleModalClose={() => {
              seteditfaqoption(false);
            }}
          />
        </Modal.Body>
      </Modal>
    </Content>
  );
}

export default Index;
