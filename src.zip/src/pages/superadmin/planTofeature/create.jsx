import React, { useState } from "react";
import { LoaderButton, FormGroup, Label ,Col} from "component/UIElement/UIElement";
import PermissionUI from "./PermissionUI";
import { Trans } from "lang";
import { useSelector } from "react-redux";
import { useForm, FormProvider } from "react-hook-form";
import POST from "axios/post";
import { planToFeatureStoreUrl,planToFeatureCreateUrl,planToFeatureUrl } from "config";
import Alert from "component/UIElement/Alert";
import Notify from "component/Notify";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useEffect } from "react";
import Loading from "component/Loading";
import CheckPermission from "helper";
import {
  PagePlanToFeature,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";



function Create(props) {
  const { language, apiToken ,userType} = useSelector((state) => state.login);
  const [formloadingStatus, SetformloadingStatus] = useState(false);


   const methods = useForm();


  
   const {
     register,
     handleSubmit,
     setValue,
     formState: { errors },
   } = methods;

  const [msgType, setMsgType] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  

  const onSubmit = (formData) => {
    SetformloadingStatus(true);

    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(planToFeatureStoreUrl, saveFormData)
      .then((response) => {
        const { status, message } = response.data;
        if (status) {
          // props.filterItem("refresh", "", "");
          // props.handleModalClose();
          setMsgType("success");
          setErrorMsg(Trans(message, language));
          Notify(true, Trans(message, language));
        } else {
          setMsgType("danger");
          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            setErrorMsg(errMsg);
          } else {
            setErrorMsg(Trans(message, language));
            Notify(false, Trans(message, language));
          }
        }
        SetformloadingStatus(false);
      })
      .catch((error) => {
        Notify(false, error.message);
        SetformloadingStatus(false);
      });
  };

  const [selectType, SetSelectType] = useState(1);
  
  const [permissionList, setPermissionList] = useState([]);
  const [sectionList, SetSectionList] = useState([]);
  const [moduleList, SetModuleList] = useState([]);
  const [contentloadingStatus, SetloadingStatus] = useState(false);
  const [statuslist,SetStatuslist] =useState("");

   const [planList, SetplanList] = useState([]);

  // const [onSelectLoad, SetonSelectLoad] = useState(false);
   const [industryList, SetindustryList] = useState([]);

  const getPlanListBYIndustryId = (industry_id) => {
    SetloadingStatus(true);
    const filterData2 = {
      api_token: apiToken,
            userType: userType,
             language: language,
            industry_id: industry_id
    };

    POST(planToFeatureUrl, filterData2)
      .then((response) => {
        const { status, data, message } = response.data;
        console.log("subscriptionIndustryPlanUrl", data);
        if (status) {
       
          SetplanList(data.plan_data);
             console.log("data.permission_list", data.permission_list);
            SetSectionList(data.feature_list);
             SetModuleList(data.feature_list);
        } else Notify(false, Trans(message, language));
        SetloadingStatus(false);
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };

 

  const getAllData = () => {
    SetloadingStatus(true);
    const filterData2 = {
      api_token: apiToken,
    };
    
    POST(planToFeatureCreateUrl, filterData2)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetindustryList(data.industry_list);

        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };
  useEffect(() => {
    document.title = "Plan To Feature | WorkerMan";
    let abortController = new AbortController();
    getAllData();
    return () => abortController.abort(); //getAllData();
  }, []);

  const {editId} =17;
  
  const [editPermission, SetEditPermission] = useState();






 console.log(sectionList);
 
  var set2 = new Set();
  {
    sectionList &&
    sectionList.map((template, idx) => {
        set2.add(template.featureGroup);
      });
  }
  console.log(set2);
  let arrayhead = [...set2];

  let ar1;
  let bigar = new Set();
  {
    for (let i = 0; i < arrayhead.length; i++) {
      ar1 = [];

      for (let j = 0; j < sectionList.length; j++) {
        if (sectionList[j].featureGroup == arrayhead[i]) {
          ar1.push(sectionList[j]);
        }
      }
      bigar.add(ar1);
    }
    console.log(bigar);
  }
  let arraylist = [...bigar];
  console.log(arraylist, "arraylist");


  

  
  return (

    <Content>
   
  <CheckPermission PageAccess={PagePlanToFeature} PageAction={PreView}>

    <React.Fragment>
      {msgType.length > 2 &&
        (msgType === "success" ? (
          <Alert type="success">{errorMsg}</Alert>
        ) : (
          <Alert type="danger">{errorMsg}</Alert>
        ))}
      <FormProvider {...methods}>
        <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        
      

                            <FormGroup mb="20px">
                              <Label
                                display="block"
                                mb="5px"
                                htmlFor={Trans("INDUSTRY", language)}
                              >
                                {Trans("INDUSTRY", language)}
                              </Label>
                              <select
                                {...register("industry_id", {
                                 
                                })}
                                className="form-control"
                                 onChange={(e) => getPlanListBYIndustryId(e.target.value)}

                                // onChange={(event) => {
                                //   SetSelectType(event.target.value);
                                // }}
                              
                              >
                               <option value="" >
                               {Trans("PLEASE_SELECT", language)}
                                      </option>

                                {industryList &&
                                  industryList.map((industry, idx) => {
                                    return (
                                      <option value={industry.industry_id} key={idx}>
                                        {industry.industry_name}
                                      </option>
                                    );
                                  })}
                              </select>
                            </FormGroup>

                            
                        
         {contentloadingStatus ? "" :

          <FormGroup mb="20px">
            <Label display="block" mb="5px" htmlFor="permissionList">
              <b>{Trans("PLAN", language)}:</b>
            </Label>
            <React.Fragment>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <React.Fragment>
          
              
          <div className="row">
         
           
           <div className="col-md-3 plan_select">  <b>{Trans("PLAN_FEATURE", language)}</b></div>
           <div className="col-md-9 plan_select">
           <div className="row ">
                {planList &&
                  planList.map((plan, chid) => {
                    return (
                      <React.Fragment key={chid}>
                        <div className="col-md-4 border_right text-uppercase">
                          <b> {Trans(plan.subscription_plan_details?.plan_name,language)}</b>
                        </div>
                      </React.Fragment>
                    );
                  })}
            </div>
            </div>
          </div>


         <div className="row">
            
             <div className="col-md-12">

             {arrayhead &&
               arrayhead.map((head, index) => { 
              return(
                <div className="col-md-12">
                        <fieldset className="form-fieldset">
               <legend>
                          {Trans(head, language)}
                          </legend> 
                <>
                  {arraylist &&
                            arraylist.map((e, idx) => {
                              return e.map((Feature) => {
                                const {
                                feature_id,
                  
                                feature_title,
                                feature_details,
                                featureGroup,
                                featureStatus,
                                status,
                                sort_order,
                                } = Feature;
                                console.log(Feature);
                                return  featureGroup == head ? (
                                  <div className="row plan_select">
                                    
                                  <div className="col-md-3 plan_select">
                                
                                  <label className="">
                                    <h6>{Feature.feature_title}</h6>
                                                       
                                  </label>
                         
                                    </div>  
                                      
                                <div className="col-md-9">
                                  <div className="row">                      
                                  {planList &&
                                    planList.map((ch, chid) => {     
                                     const {
                      
                                         features,
                                         limits,
                                         status,
                                         } = ch
                                         ;
                                         
                                        return (
                                       <>
                                          
                                          
                                    
                        <div key={chid} className="col-md-4 plan_select d-flex justify-content-between align-items-center">
            
            
                                            <select
                                              {...register(
            
                                                `status_${ch.plan_id}_${feature_id}`
                                              )}
                                              className=""
                                              defaultValue={
                                                features[feature_id] === undefined
                                                  ? 'no'
                                                  : features[feature_id]
                                              }
                                            >

                                              <option >
                                                {Trans("SELECT", language)}
                                              </option>
                                              
                                      <option className="text-success" value="yes"> {Trans("yes", language)} </option>
                                      <option  className="text-danger"  value="no"> {Trans("no", language)} </option>
                                          
                                            </select>
            
                                            <FormGroup  className="mb-0">
                                                <input
                                                  id="name"
                                                  type="text"
                                                  className="form-controls"
                                                  placeholder="FEATURE_LIMIT"
                                                  defaultValue={
                                                    limits[feature_id] === undefined
                                                      ? 'no'
                                                      : limits[feature_id]
                                                  }
                                                

                                                  {...register(
                    
                                                    `feature_limit_${ch.plan_id}_${feature_id}`
                                                  
                                                  )}
                                                
                                                />
                                              
                                              </FormGroup>
                                          </div>
                                         
                                         
                                       </>
                                       
            
                                        );
                                      })}
                   
                                  </div>
                                </div>
                                </div> 
                                ) : (
                                  ""
                                );
                              });
                            })}


             </>
             </fieldset> </div>);
                          })}
                  
                  
                    </div>
                 
             
           
          </div>
        </React.Fragment>
      )}
           </React.Fragment>
         
         {/* //   <PermissionUI Compname="permissionList"   indstry={ selectType }  /> */}
          </FormGroup>
}

<Col col={4}>
<LoaderButton
            formLoadStatus={formloadingStatus}
            btnName={Trans("UPDATE", language)}
            className="btn btn-primary btn-block"
          />
          </Col>
         
        </form>
      </FormProvider>
    </React.Fragment>
       </CheckPermission>
    </Content>
  );
}

export default Create;


