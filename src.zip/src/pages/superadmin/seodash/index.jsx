import React from "react";
import { useSelector } from "react-redux";
import Content from "layouts/content";
import { useState } from "react";
import { DashboardUrl } from "config/index";
import POST from "axios/post";
import Notify from "component/Notify";
import { Trans } from "lang";


function Index() {
  const { role, apiToken, userType, language, industry,userInfo } = useSelector(
    (state) => state.login
  );


  const userDetails = JSON.parse(userInfo);

  const [dashboardData, SetdashboardData] = useState([]);

 React.useEffect(() => {
  const formData = {
    api_token: apiToken,
    // language: language,
    // userType: userType,
    // industry_id: industry,
  };
  POST(DashboardUrl, formData)
    .then((response) => {
      const { status, data } = response.data;
      if (status) {
        SetdashboardData(data);
      } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
    })
    .catch((error) => {
      Notify(false, error.message);
      console.error("There was an error!", error);
    });
}, []);


  return (
    <React.Fragment>
      <Content>
      <div>

            <h4 className="mg-b-0 tx-spacing--1">Welcome to {userDetails.first_name}</h4>

          </div>
          <div className="row row-xs">
          <div className="col-sm-6 col-lg-2">
            <div className="card card-body bg-green">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("ACTIVE_WEBSITE", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                {dashboardData?.active_website}
                </h3>
              </div>
            </div>
          </div>

          <div className="col-sm-6 col-lg-2">
            <div className="card card-body  bg-gray">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("TOTAL_SUBMISSION", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                {dashboardData?.total_submission}

                </h3>
              </div>
            </div>
          </div>

          <div className="col-sm-6 col-lg-2">
            <div className="card card-body  bg-purple">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("TODAY_WORK", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                {dashboardData?.today_works}

                </h3>
              </div>
            </div>
          </div>

         
       
        
       
        </div>
      </Content>
    </React.Fragment>
  );
}

export default Index;




