import React from "react";
import CheckPermission from "helper";
import FeatherIcon from "feather-icons-react";
import {
  BadgeShow,
  Col,
  IconButton,
  Anchor,
} from "component/UIElement/UIElement";
import { Trans } from "lang/index";
import { useSelector } from "react-redux";
import ModalAlert from "component/ModalAlert";
import { useState } from "react";
import { PreUpdate, PreRemove, PreView } from "config/PermissionName";
import WebsiteLink from "config/WebsiteLink";
import { SettingGroup } from "config/WebsiteUrl";
import { useForm } from "react-hook-form";

function Table({
  dataList,
  deleteFun,
  pageName,
  filterItem,
  editFun,
  viewFunction,
  updateStatusFunction,
  updateAnnualPriceFunction,
  updatePlanTrialFunction,
  perPage,
  curPage,
  updateAnnualFunction,
  updateRecurringFunction,
}) {
  const { apiToken, language } = useSelector((state) => state.login);
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: deleteFun,
      param: deleteId,
      closeModal: closeModal,
    });
  };
  // change Status function
  const ChangeStatus = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: updateStatusFunction,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  const editFunction = (editId) => {
    editFun(editId);
  };

  const viewFun = (editId) => {
    viewFunction(editId);
  };

  let rowId = curPage > 1 ? (curPage - 1) * perPage : 0;

  return (
    <>
      <Col col={12}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>{Trans("SL_NO", language)}</th>
                <th>{Trans("GROUP_NAME", language)}</th>
                <th>{Trans("CURRENCY_CODE", language)}</th>
                <th>{Trans("SHOW_PRICE", language)}</th>
                <th>{Trans("ANNUAL_PRICE", language)}</th>
                <th>{Trans("RECURRING", language)}</th>
                <th>{Trans("PLAN_TRIAL", language)}</th>
                <th>{Trans("TRIAL_DAYS", language)}</th>
                <th>{Trans("STATUS", language)}</th>
                <th className="text-center">{Trans("ACTION", language)}</th>
              </tr>
            </thead>

            <tbody>
              {dataList.length > 0 &&
                dataList.map((cat, IDX) => {
                  const {
                    group_id,
                    group_name,
                    status,
                    show_price,
                    currency,
                    plan_trial,
                    trial_day,
                    show_annual_price,
                    recurring,
                  } = cat;
                  rowId++;
                  return (
                    <React.Fragment key={IDX}>
                      <tr>
                        <td>{rowId}</td>
                        <td>{group_name}</td>
                        <td>{currency}</td>

                        <td className="text-center">
                          <div className="custom-control custom-switch ">
                            <input
                              onClick={() => {
                                updateAnnualFunction(group_id);
                              }}
                              type="checkbox"
                              className="custom-control-input"
                              id={`customSwitches${group_id}`}
                              checked={show_price === 0 ? "" : "checked"}
                            />
                            <label
                              className="custom-control-label"
                              For={`customSwitches${group_id}`}></label>
                          </div>
                        </td>

                        <td className="text-center">
                          <div className="custom-control custom-switch ">
                            <input
                              onClick={() => {
                                updateAnnualPriceFunction(group_id);
                              }}
                              type="checkbox"
                              className="custom-control-input"
                              id={`customSwitch1${group_id}`}
                              checked={show_annual_price === 0 ? "" : "checked"}
                            />
                            <label
                              className="custom-control-label"
                              For={`customSwitch1${group_id}`}></label>
                          </div>
                        </td>

                        <td className="text-center">
                          <div className="custom-control custom-switch ">
                            <input
                              onClick={() => {
                                updateRecurringFunction(group_id);
                              }}
                              type="checkbox"
                              className="custom-control-input"
                              id={`customS${group_id}`}
                              checked={recurring === 0 ? "" : "checked"}
                            />
                            <label
                              className="custom-control-label"
                              For={`customS${group_id}`}></label>
                          </div>
                        </td>

                        <td className="text-center">
                          <div className="custom-control custom-switch ">
                            <input
                              onClick={() => {
                                updatePlanTrialFunction(group_id);
                              }}
                              type="checkbox"
                              className="custom-control-input"
                              id={`customsSwitch${group_id}`}
                              checked={plan_trial === 0 ? "" : "checked"}
                            />
                            <label
                              className="custom-control-label"
                              For={`customsSwitch${group_id}`}></label>
                          </div>
                        </td>
                        <td className="">{trial_day}</td>

                        <td className="text-center">
                          <div className="custom-control custom-switch ">
                            <input
                              onClick={() => {
                                updateStatusFunction(group_id);
                              }}
                              type="checkbox"
                              className="custom-control-input"
                              id={`customSwitch${group_id}`}
                              checked={status === 0 ? "" : "checked"}
                            />
                            <label
                              className="custom-control-label"
                              For={`customSwitch${group_id}`}></label>
                          </div>
                        </td>

                        <td className="text-center">
                          <Anchor
                            color="primary"
                            path={WebsiteLink(
                              `/service-plan-group/${group_id}`
                            )}>
                            <button className="btn btn-primary btn-xs btn-icon">
                              <FeatherIcon
                                icon="eye"
                                color="white"
                              />
                            </button>
                          </Anchor>{" "}
                          <CheckPermission
                            PageAccess={pageName}
                            PageAction={PreUpdate}>
                            <button className="btn btn-primary btn-xs btn-icon">
                              <FeatherIcon
                                icon="edit-2"
                                fill="white"
                                size={20}
                                onClick={() => editFunction(group_id)}
                              />
                            </button>
                          </CheckPermission>
                          {"  "}
                        </td>
                      </tr>
                    </React.Fragment>
                  );
                })}
            </tbody>
          </table>
        </div>
      </Col>
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </>
  );
}

export default Table;
