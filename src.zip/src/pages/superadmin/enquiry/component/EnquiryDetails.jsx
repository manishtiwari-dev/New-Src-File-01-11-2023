import { Trans } from "lang/index";
import { useSelector } from "react-redux";
import React, { useState, useEffect } from "react";
import Notify from "component/Notify";
import Loading from "component/Preloader";
import { ErrorMessage } from "@hookform/error-message";
import MyEditor from "component/MyEditor";




import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
} from "component/UIElement/UIElement";
import { Alert, Card, Button } from "react-bootstrap";
import { SupEnquiryStoreUrl,  } from "config/index";
import { useForm, FormProvider } from "react-hook-form";
import POST from "axios/post";




const EnquiryDetails = ({ enquiryDetails }) => {
  const { language,apiToken } = useSelector((state) => state.login);

  console.log("enquiryDetails", enquiryDetails);
  const {
    customer_name,
    customer_email,
    enquiry_no,
    subject,
    message,
    company_name,
    Country,
    phone,
    created_at,
    enquiry_id,
  } = enquiryDetails;


  console.log(enquiryDetails);

  const [productInfo, setproductInfo] = React.useState();

  React.useEffect(() => {
    let abortController = new AbortController();

    setproductInfo(enquiryDetails);

    return () => abortController.abort();
  }, []);

  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const methods = useForm();

  console.log("methods", methods);

  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = methods;

  const [contentloadingStatus, SetloadingStatus] = useState(true);


  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    saveFormData.enquiry_id=enquiry_id;
    POST(SupEnquiryStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          //   props.filterItem("refresh", "", "");
          //   props.handleModalClose();
       //   setValueToField();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };
  return (

    <React.Fragment>
      <Row>
        {/* if product enquiry */}
        {productInfo && (
          <React.Fragment>
    <div className="content tx-13">
    <div className=" ">
       <div className="row">
         <div className="col-sm-6">
         <label className="tx-sans  tx-10 tx-medium tx-spacing-1 tx-color-03">
       <h6 className="tx-15 mg-b-10">  {Trans("ENQUIRY_DETAILS", language)} </h6>
           </label>
         {" "}
          <>

          

             <div className="mg-b-0 d-flex">
               {Trans("ENQUIRY_NO", language)}
               <span>{enquiry_no}  </span>
               </div>


               <div className="mg-b-0 d-flex">
               {Trans("ENQUIRY_DATE", language)}{" "}
                <span>{created_at}</span>  
               </div>
              
             
               
               
              

             </>
       
         </div>

       <div className="col-sm-6 tx-right d-none d-md-block">
 
         <label className="tx-sans  tx-10 tx-medium tx-spacing-1 tx-color-03">
         <h6 className="tx-15 mg-b-10">  {Trans("CUSTOMER_DETAILS", language)}</h6>  
           </label>

           <div className="mg-b-0 ">
               {Trans("CUSTOMER_NAME", language)}{" "}
               <span>{customer_name}</span> 
              
              </div>

              
            
               <div className="mg-b-0 ">
               {Trans("EMAIL_ADDRESS", language)} {" "}
               <span>{customer_email}</span> 
              
            
              </div>
            
               <div className="mg-b-0 ">
               {Trans("PHONE", language)}{" "}
               <span>{phone}</span> 
              
           
               </div>

               <div className="mg-b-0 ">
               {Trans("COUNTRY", language)}{" "}
               <span>{Country}</span> 
              
           
               </div>

               <div className="mg-b-0 ">
               {Trans("MESSAGE", language)}{" "}
               <span>{message}</span> 
              
             
               </div>
           {/* <label className="col-md-4">
                  <b>{Trans("PRODUCT_NAME", language)} : </b>
                </label>
                <span className="col-md-8">
                  {
                    productInfo?.products?.productdescription?.[0][
                      "products_name"
                    ]
                  }
                </span> */}

        
         </div>

         <Col col={12} className="mt-2 mb-2">
                <Card>
                  {/* <Card.Header as="h5">
                    {Trans("ADD_FOLLOW_UP")}
                    <Button
                      variant="danger"
                      style={{ float: "right" }}
                      onClick={() => {
                        SetnewHistory(false);
                      }}
                    >
                      x
                    </Button>
                  </Card.Header> */}
                  <Card.Body>
                  {/* <Card.Header><h6>{Trans("EMAIL_TEMPLATES")}</h6></Card.Header> */}
                    <form
                      action="#"
                      onSubmit={handleSubmit(onSubmit)}
                      noValidate
                    >
                      {/* <input
                        type="hidden"
                        {...register("followup_id")}
                      
                      /> */}
                      <Row>
                       
                        <Col col={12}>
                          <FormGroup mb="20px">
                            <Input
                              id="SUBJECT"
                              label={Trans("SUBJECT", language)}
                              placeholder={Trans("SUBJECT", language)}
                              className="form-control"
                              {...register("subject")}
                              type="text"
                            />
                           
                          </FormGroup>
                        </Col>
                      

                        <Col col={12}>
                        <FormGroup>
                          <Label>{Trans("CONTENT", language)}</Label>
                          <MyEditor
                            setKey={`message`}
                            updateFun={(Key, Value) => {
                              setValue(Key, Value);
                            }}
                          />
                          <textarea
                            {...register(`message`)}
                            style={{ display: "none" }}
                          ></textarea>
                        </FormGroup>
                    </Col>

                        <Col col={12}>
                          <LoaderButton
                            formLoadStatus={formloadingStatus}
                            btnName={Trans("SUBMIT", language)}
                            className="btn btn-primary"
                          />
                        </Col>
                      </Row>
                    </form>
                  </Card.Body>
                </Card>
              </Col>
     
    
        {/* end billing */}
       </div>

    
     </div>
   </div>

      
          </React.Fragment>
        )}

        
      


     

      

        {/* <Col col={12}>
          <label className="">
            <b>{Trans("MESSAGE", language)} </b>
          </label>
          <p>{message}</p>
        </Col> */}
         

      </Row>
    </React.Fragment>
  );
};

export default EnquiryDetails;
