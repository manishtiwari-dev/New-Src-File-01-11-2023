import React, { useState } from "react";
import POST from "axios/post";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import EditProductType from "./editProductType";
import CheckPermission from "helper";
import EditFields from "./editFields";
import EditFieldGroup from "./editFieldGroup";
import { useSelector, useDispatch } from "react-redux";
import { updateModuleListState } from "redux/slice/loginSlice";
import { Trans } from "lang/index";
import { Modal, Button } from "react-bootstrap";
import { PageProductType, PreAdd, PreView, PreUpdate } from "config/PermissionName";
import {
  paymentTypeChangeStatusUrl,
  paymentTypeUrl,
  fieldsgroupChangeStatusUrl,
  paymentTypeSortorder,
} from "config/index";
import { useEffect } from "react";
function TreeComponent({ dataList, filterItem }) {
  const dispatch = useDispatch();
  const { apiToken, language } = useSelector((state) => state.login);
  const AccessColor = ["#ff8d00", "#001737", "#7a00ff"];

  const [editId, SetEditId] = useState();
  const [editModuleShow, seteditModuleShow] = useState(false);
  const [editSubModuleShow, seteditSubModuleShow] = useState(false);
  const [addFieldGroupModuleShow, setFieldGroupModuleShow] = useState(false);

  const ModuleEditData = (edit_id, type) => {
    SetEditId(edit_id);
    if (type === "module") seteditModuleShow(true);
    else if (type === "") seteditSubModuleShow(true);
    // else setSubAddModuleShow(true);
  };

  const RefreshList = () => {
    filterItem("refresh", "", "");
  };
  const [datta, setdatta] = useState("");
  const getData = () => {
    const filterData = {
      api_token: apiToken,
    };
    POST(paymentTypeUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          setdatta(data);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  const StatusChnageFun = (edit_id) => {
    const editData = { api_token: apiToken, fieldsgroup_id: edit_id };

    POST(paymentTypeChangeStatusUrl, editData)
      .then((response) => {
        const { message, data } = response.data;
        // RefreshList();
        getData();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  const SortOrderUpdate = (e, edit_id, type) => {
    const editData = {
      api_token: apiToken,
      update_id: edit_id,
      sort_order: e.target.value,
      type: type,
    };
    POST(paymentTypeSortorder, editData)
      .then((response) => {
        const { message, data } = response.data;
        getData();
        // RefreshList();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };
  useEffect(() => {
    let abortController = new AbortController();
    setdatta(dataList);
    return () => abortController.abort();
  }, [dataList]);

  return (
    <>
      <div className="col-lg-12 mx-auto">
        <div className="media-body">


          {datta &&
            datta.map((productType, index) => {
              const {
                created_at,
                fields_group,
                product_type_id,
                product_type_key,
                product_type_name,
                sort_order,
                status,
              } = productType;
              return (
                <>

                  <div className=" table-responsive">
                    <table className=" table  mb-4">
                      <thead>
                        <h6 className="m-3">{product_type_name}</h6>
                      </thead>
                      <tbody>



                        <tr className="type">
                          <td style={{ width: "285px", border: "none" }}>{Trans("SECTION", language)}</td>

                          <td style={{ width: "", border: "none" }} className="">
                            {Trans("SORT_ORDER", language)}
                          </td>
                          <CheckPermission PageAccess={PageProductType} PageAction={PreUpdate}>
                            <td style={{ width: "", border: "none" }} className="">
                              {Trans("Action", language)}{" "}
                            </td>
                          </CheckPermission>
                        </tr>


                        {productType.fields_group &&
                          productType?.fields_group.map(
                            (fieldGroup, secIdx) => {
                              const {
                                fieldsgroup_name,
                                fieldsgroup_id,
                                status,
                                sort_order,
                              } = fieldGroup;
                              return (
                                <>

                                  <tr>
                                    <td className="d-flex fw-bold" style={{ border: "none" }}>
                                      <FeatherIcon
                                        style={{
                                          cursor: "pointer",
                                        }}
                                        icon="arrow-down-circle"
                                        size={13}
                                      />
                                      {fieldsgroup_name}

                                      <div
                                        className="custom-control custom-switch ml-4"

                                      >
                                        <input
                                          onClick={() => {
                                            StatusChnageFun(
                                              fieldsgroup_id
                                            );
                                          }}
                                          type="checkbox"
                                          class="custom-control-input"
                                          id="customSwitch1"
                                          checked={
                                            status === 0
                                              ? ""
                                              : "checked"
                                          }
                                        />
                                        <label
                                          className="custom-control-label"
                                          For="customSwitch1"
                                        ></label>
                                      </div>
                                    </td>

                                    <td style={{ border: "none" }}>
                                      <input
                                        type="number"
                                        className="text-center"
                                        style={{ width: 50 }}
                                        defaultValue={sort_order}
                                        onBlur={(e) => {
                                          SortOrderUpdate(
                                            e,
                                            fieldsgroup_id,
                                            "fieldsGroup"
                                          );

                                        }}
                                      />
                                    </td>
                                    <td style={{ border: "none" }}>
                                      <CheckPermission PageAccess={PageProductType} PageAction={PreUpdate}>
                                        <button
                                          type="button"
                                          class="btn btn-primary btn-xs btn-icon"
                                          onClick={() => {
                                            ModuleEditData(
                                              fieldsgroup_id,
                                              "module"
                                            );
                                          }}
                                        >
                                          <svg
                                            width="20"
                                            height="20"
                                            viewBox="0 0 24 24"
                                            fill="white"
                                            stroke="currentColor"
                                            stroke-width="2"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            class="feather feather-edit-2 "
                                          >
                                            <g>
                                              <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                                            </g>
                                          </svg>
                                        </button>
                                      </CheckPermission>
                                    </td>
                                  </tr>



                                  {fieldGroup?.fields &&
                                    fieldGroup.fields.map(
                                      (others) => {
                                        const {
                                          fields_id,
                                          field_name,
                                          sort_order,
                                        } = others;
                                        return (
                                          <tr>
                                            <td style={{ width: "300px", border: "none" }}>
                                              {others.field_name}
                                            </td>
                                            <td style={{ width: "", border: "none" }}>
                                              <input
                                                type="number"
                                                className="text-center"

                                                style={{ width: 50 }}
                                                defaultValue={
                                                  sort_order
                                                }
                                                onBlur={(e) => {
                                                  SortOrderUpdate(
                                                    e,
                                                    fields_id,
                                                    ""
                                                  );
                                                }}
                                              />
                                            </td>
                                            <td style={{ width: "", border: "none" }}>
                                              <CheckPermission PageAccess={PageProductType} PageAction={PreUpdate}>
                                                <button
                                                  type="button"
                                                  class="btn btn-primary btn-xs btn-icon"
                                                  onClick={() => {
                                                    ModuleEditData(
                                                      fields_id,
                                                      ""
                                                    );
                                                  }}
                                                >
                                                  <svg
                                                    width="20"
                                                    height="20"
                                                    viewBox="0 0 24 24"
                                                    fill="white"
                                                    stroke="currentColor"
                                                    stroke-width="2"
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    class="feather feather-edit-2 "
                                                  >
                                                    <g>
                                                      <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                                                    </g>
                                                  </svg>
                                                </button>
                                              </CheckPermission>

                                            </td>
                                          </tr>
                                        );
                                      }
                                    )}

                                </>
                              );
                            }
                          )}
                      </tbody>
                    </table>
                  </div>
                </>
              );
            })}


        </div>
      </div>

      <Modal
        show={editModuleShow}
        onHide={() => {
          seteditModuleShow(false);
        }}
      >
        <Modal.Header>
          <Modal.Title>{Trans("EDIT_FIELD_GROUP", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              seteditModuleShow(false);
            }}
          >
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <EditFieldGroup
            editId={editId}
            RefreshList={RefreshList}
            handleModalClose={() => {
              seteditModuleShow(false);
            }}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* Sub Module Edit modal */}
      <Modal
        show={editSubModuleShow}
        onHide={() => {
          seteditSubModuleShow(false);
        }}
      >
        <Modal.Header>
          <Modal.Title>{Trans("EDIT_FIELD", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              seteditSubModuleShow(false);
            }}
          >
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <EditFields
            editId={editId}
            RefreshList={RefreshList}
            handleModalClose={() => {
              seteditSubModuleShow(false);
            }}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
    </>
  );
}

export default TreeComponent;
