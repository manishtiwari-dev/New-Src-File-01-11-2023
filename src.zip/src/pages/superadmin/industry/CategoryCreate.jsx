import React, { useState } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import {
  industryCategoryStoreUrl,
  industryCategoryList,
  tempUploadFileUrl,
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  StatusSelect,
  Label,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import Select from "react-select";
import { useEffect } from "react";

const Create = (props) => {
  const industry = props.indname;
  console.log(industry);

  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);

    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(industryCategoryStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });
          console.log(props.indname);
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          props.indname();

          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
        SetformloadingStatus(false);
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [industryList, SetindustryList] = useState([]);
  const [indName, SetindustryName] = useState([]);

  const getModuleList = () => {
    const filterData2 = {
      api_token: apiToken,
      industry_id: industry,
    };
    POST(industryCategoryList, filterData2)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetindustryList(data.industry_list);

          SetindustryName(data.indname);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    getModuleList();
    return () => abortController.abort(); //getModuleList();
  }, []);

  const [updateformloadingStatus, SetupdateformloadingStatus] = useState(false);

  const HandleDocumentUpload = (event, previewUrlId, StoreID) => {
    SetupdateformloadingStatus(true);

    if (event.target.files[0] === "" || event.target.files[0] === undefined)
      return;

    var readers = new FileReader();
    readers.onload = function (e) {
      document.getElementById(
        previewUrlId
      ).innerHTML = `<img src=${e.target.result} height="100" />`;
    };
    readers.readAsDataURL(event.target.files[0]);

    // upload temp image and bind value to array
    const formdata = new FormData();
    // SetupdateformloadingStatus(false);

    formdata.append("api_token", apiToken);
    formdata.append("fileInfo", event.target.files[0]);
    formdata.append("images_type", 1);
    POST(tempUploadFileUrl, formdata)
      .then((response) => {
        SetupdateformloadingStatus(false);
        setValue(StoreID, response.data.data);
      })
      .catch((error) => {
        SetupdateformloadingStatus(false);

        Notify(false, error.message);
      });
  };

  console.log(indName.industry_name);

  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible>
          {error.msg}
        </Alert>
      )}
      <form
        action="#"
        onSubmit={handleSubmit(onSubmit)}
        noValidate>
        <Row>
          {/* INDUSTRY INFO */}
          <Col
            col={12}
            className="mt-3">
            <fieldset className="form-fieldset">
              <legend>{Trans("INDUSTRY_INFO", language)}</legend>
              <Row>
                <Col
                  col={6}
                  className="mb-1">
                  <FormGroup mb="20px">
                    <Label
                      display="block"
                      mb="5px"
                      htmlFor={Trans("INDUSTRY", language)}>
                      {Trans("INDUSTRY", language)}
                    </Label>

                    <select
                      {...register("industry_id", {
                        required: Trans("INDUSTRY_REQUIRED", language),
                      })}
                      className="form-control"
                      //value={indName.industry_name}
                    >
                      <option>{Trans("SELECT_INDUSTRY")}</option>
                      {industryList &&
                        industryList.map((industry, idx) => {
                          return (
                            <option
                              value={industry.industry_id}
                              key={idx}>
                              {industry.industry_name}
                            </option>
                          );
                        })}
                    </select>
                  </FormGroup>
                </Col>
                {/* // industry category name */}
                <Col
                  col={6}
                  className="mb-1">
                  <FormGroup mb="20px">
                    <Input
                      type="text"
                      id={Trans("INDUSTRY_CATEGORY_NAME", language)}
                      label={Trans("INDUSTRY_CATEGORY_NAME", language)}
                      placeholder={Trans("INDUSTRY_CATEGORY_NAME", language)}
                      className="form-control"
                      {...register("category_name", {
                        required: Trans(
                          "INDUSTRY_CATEGORY_NAME_REQUIRED",
                          language
                        ),
                      })}
                    />
                    <span className="required">
                      <ErrorMessage
                        errors={errors}
                        name="category_name"
                      />
                    </span>
                  </FormGroup>
                </Col>
                <Col
                  col={6}
                  className="mb-1">
                  <FormGroup mb="20px">
                    <Input
                      type="text"
                      id={Trans("INDUSTRY_CATEGORY_TITLE", language)}
                      label={Trans("INDUSTRY_CATEGORY_TITLE", language)}
                      placeholder={Trans("INDUSTRY_CATEGORY_TITLE", language)}
                      className="form-control"
                      {...register("category_title")}
                    />
                  </FormGroup>
                </Col>{" "}
                <Col
                  col={6}
                  className="mb-1">
                  <FormGroup mb="20px">
                    <Input
                      type="text"
                      id={Trans("SEO_META_TITLE", language)}
                      label={Trans("SEO_META_TITLE", language)}
                      placeholder={Trans("SEO_META_TITLE", language)}
                      className="form-control"
                      {...register("meta_title")}
                    />
                  </FormGroup>
                </Col>{" "}
                <Col
                  col={6}
                  className="mb-1">
                  <FormGroup mb="20px">
                    <TextArea
                      id={`${Trans("INDUSTRY_CATEGORY_DESC", language)} `}
                      label={`${Trans("INDUSTRY_CATEGORY_DESC", language)} `}
                      placeholder={`${Trans(
                        "INDUSTRY_CATEGORY_DESC",
                        language
                      )} `}
                      hint="Enter text" // for bottom hint
                      className="form-control"
                      {...register(`category_description`)}
                    />
                  </FormGroup>
                </Col>{" "}
                <Col
                  col={6}
                  className="mb-1">
                  <FormGroup mb="20px">
                    <TextArea
                      id={`${Trans("SEO_META_DESC", language)} `}
                      label={`${Trans("SEO_META_DESC", language)} `}
                      placeholder={`${Trans("SEO_META_DESC", language)} `}
                      hint="Enter text" // for bottom hint
                      className="form-control"
                      {...register(`meta_description`)}
                    />
                  </FormGroup>
                </Col>{" "}
              </Row>
            </fieldset>
          </Col>
          {/* INDUSTRY INFO */} {/* IMAGES INFO */}
          <Col
            col={12}
            className="mt-3">
            <fieldset className="form-fieldset">
              <legend>{Trans("IMAGES_INFO", language)}</legend>
              <Row>
                {/* <Col col={6}>
          <Label
              display="block"
              mb="5px"
              htmlFor={Trans("BANNER", language)}
            >
            {Trans("BANNER", language)}
          </Label>
         
              <input
                type="hidden"
                {...register("banner_img", {
                 
                })}
              />
              <input
                type="file"
                className="custom-file-input"
                id="customFile"
                onChange={(event) =>
                  HandleDocumentUpload(event, `fileupload`, `banner_img`)
                }
              />
              <label className="custom-file-label" htmlFor="customFile">
                {Trans("BANNER_IMAGES", language)}
                {"  "}
              </label>


          </Col>  */}
                <Col col={6}>
                  <FormGroup>
                    <Label
                      display="block"
                      mb="5px"
                      htmlFor={"fileupload"}>
                      {Trans("BANNER", language)}
                    </Label>
                    <div className="custom-file">
                      <input
                        type="hidden"
                        {...register("banner_img")}
                      />
                      <input
                        type="file"
                        className="custom-file-input"
                        id="customFile"
                        onChange={(event) =>
                          HandleDocumentUpload(
                            event,
                            "fileupload",
                            "banner_img"
                          )
                        }
                      />
                      <label
                        className="custom-file-label"
                        htmlFor="customFile">
                        {Trans("BANNER_IMAGES", language)}
                      </label>
                      <div id={"fileupload"}></div>
                    </div>
                  </FormGroup>
                </Col>{" "}
                <Col col={6}>
                  <FormGroup>
                    <Label
                      display="block"
                      mb="5px"
                      htmlFor={"fileupload"}>
                      {Trans("WEB_FEATURE_IMAGE", language)}
                    </Label>
                    <div className="custom-file">
                      <input
                        type="hidden"
                        {...register("web_feature_img")}
                      />
                      <input
                        type="file"
                        className="custom-file-input"
                        id="customFile"
                        onChange={(event) =>
                          HandleDocumentUpload(
                            event,
                            "featureupload",
                            "web_feature_img"
                          )
                        }
                      />
                      <label
                        className="custom-file-label"
                        htmlFor="customFile">
                        {Trans("WEB_FEATURE_IMAGE", language)}
                      </label>
                      <div id={"featureupload"}></div>
                    </div>
                  </FormGroup>
                </Col>{" "}
                {/* // industry category name */}
                <Col
                  col={6}
                  className="mb-1">
                  <FormGroup mb="20px">
                    <Input
                      id={Trans("VIDEO_URL", language)}
                      label={Trans("VIDEO_URL", language)}
                      placeholder={Trans("VIDEO_URL", language)}
                      className="form-control"
                      {...register("video_url", {})}
                      defaultValue="#"
                    />
                  </FormGroup>
                </Col>
              </Row>
            </fieldset>
          </Col>{" "}
          {/* OTHER INFO */}
          {/* OTHER INFO */}
          <Col
            col={12}
            className="mt-3">
            <fieldset className="form-fieldset">
              <legend>{Trans("OTHER_INFO", language)}</legend>
              <Row>
                {/* <Col col={6}  className="mb-1">
            <FormGroup mb="20px">
              <Input
                type="text"
                id={Trans("DEMO_DB", language)}
                label={Trans("DEMO_DB", language)}
                placeholder={Trans("DEMO_DB", language)}
                className="form-control"
                {...register("demo_db")}
              />
            </FormGroup>
          </Col> */}
                <Col
                  col={6}
                  className="mb-1">
                  <FormGroup mb="20px">
                    <Input
                      id={Trans("DEMO_URL", language)}
                      label={Trans("DEMO_URL", language)}
                      placeholder={Trans("DEMO_URL", language)}
                      className="form-control"
                      {...register("demo_url")}
                      defaultValue="#"
                    />
                  </FormGroup>
                </Col>

                <Col
                  col={6}
                  className="mb-1">
                  <FormGroup mb="20px">
                    <Input
                      type="number"
                      id={Trans("SORT_ORDER", language)}
                      label={Trans("SORT_ORDER", language)}
                      placeholder={Trans("SORT_ORDER", language)}
                      className="form-control"
                      {...register("sort_order", {
                        required: Trans("SORT_ORDER_REQUIRED", language),
                      })}
                    />
                    <span className="required">
                      <ErrorMessage
                        errors={errors}
                        name="sort_order"
                      />
                    </span>
                  </FormGroup>
                </Col>
                <Col
                  col={6}
                  className="mb-1">
                  <FormGroup mb="20px">
                    <StatusSelect
                      id="Status"
                      label={Trans("STATUS", language)}
                      hint="Enter text" // for bottom hint
                      defaultValue={1}
                      className="form-control"
                      {...register("status", {
                        required: Trans("STATUS_REQUIRED", language),
                      })}
                    />
                    <span className="required">
                      <ErrorMessage
                        errors={errors}
                        name="status"
                      />
                    </span>
                  </FormGroup>
                </Col>
              </Row>
            </fieldset>
          </Col>{" "}
          {/* OTHER INFO */}
          {updateformloadingStatus ? (
            <>
              {" "}
              <Col col={12}>
                <b>Uploading...</b>{" "}
              </Col>
            </>
          ) : (
            <>
              <Col
                col={4}
                className="mt-2">
                <LoaderButton
                  formLoadStatus={formloadingStatus}
                  btnName={Trans("SUBMIT", language)}
                  className="btn btn-sm btn-bg btn-block"
                />
              </Col>
            </>
          )}
        </Row>
      </form>
    </>
  );
};

export default Create;
