import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { Dbupdate, PreAdd, PreView } from "config/PermissionName";
import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { useForm } from "react-hook-form";
import {
  PagesUrl,
  SectionSelectUrl,
  DbSuffixStoreUrl,
  DbSuffixUrlList,
} from "config/index";
import { PageSetting } from "config/WebsiteUrl";
import { useNavigate } from "react-router-dom";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  Checkbox,
  Label,
} from "component/UIElement/UIElement";
import { Alert, Tab, Tabs } from "react-bootstrap";
import { ErrorMessage } from "@hookform/error-message";
import MyEditor from "component/MyEditor";
import Select from "react-select";
import Loading from "component/Preloader";

const Index = (props) => {
  const { apiToken, language, userType, quickSectionList, themeColor } =
    useSelector((state) => state.login);

    const [dataList, SetdataList] = useState([]);
    const [filterDataList, SetfilterDataList] = useState([]);
    const [Pagi, SetPagi] = useState(0);
    const [currPage, SetcurrPage] = useState(0);
    const [searchItem, SetSEarchItem] = useState("");
    const [sortByS, SetsortByS] = useState("sort_order");
    const [orderByS, SetOrderByS] = useState("ASC");
    const [perPageItem, SetPerPageItem] = useState("");
    const [contentloadingStatus, SetloadingStatus] = useState(true);
  

  const navigate = useNavigate();

  const [key, setKey] = useState("en");
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
    getValues,
  } = useForm();

  const quick = [];
  const nesw = [];

  {
    quickSectionList &&
      JSON.parse(quickSectionList).map((menu, index) => {
        //quick.push();
        quick.push({
          label: Trans(menu.section_name, language),
          value: menu.section_id,
        });
      });
  }

  console.log(quick);

  const getData = (pagev, perPageItemv, searchData, sortBys, OrderBy) => {

    SetloadingStatus(true);
    const filterData = {
      api_token: apiToken,
      page: pagev,
      perPage: perPageItemv,
      search: searchData,
      sortBy: sortBys,
      orderBY: OrderBy,
      language: language,
    };

    POST(PagesUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetdataList(data.data);
          SetPagi(data.total_page);
          SetcurrPage(data.current_page);
          SetPerPageItem(data.per_page
            );
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });

   
      
  };



  const filterItem = (name, value, other) => {
    switch (name) {
      case "perpage":
        SetloadingStatus(true);
        const per = Number(value);
        SetPerPageItem(per);
        getData(1, per, searchItem, sortByS, orderByS);
        break;
      case "searchbox":
        SetSEarchItem(value);
        getData(1, perPageItem, value, sortByS, orderByS);
        break;
      case "sortby":
        SetOrderByS(other);
        SetsortByS(value);
        getData(1, perPageItem, searchItem, value, other);
        break;
      case "pagi":
        SetcurrPage(value);
        getData(value, perPageItem, searchItem, sortByS, orderByS);
        break;
      default:
        getData(currPage, perPageItem, searchItem, sortByS, orderByS);
        break;
    }
  };


  useEffect(() => {
    document.title = "Db History | WorkerMan";
    let abortController = new AbortController();

    getData(1, perPageItem, searchItem, sortByS, orderByS);

    return () => abortController.abort();
  }, []);



  const [webfunctionSelected, SetwebfunctionSelected] = useState();

  const [editInfo, SeteditInfo] = useState("");

  const setValueToField = () => {
    const editInfo = {
      api_token: apiToken,
    };
    POST(SectionSelectUrl, editInfo)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SeteditInfo(data);
          console.log(data);

          const fieldList = getValues();
          for (const key in fieldList) {
            setValue(key, data[key]);
          }
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        Notify(false, Trans(error.message, language));
      });
  };

  const [dbSuffixList, SetdbSuffixList] = useState([]);
  const [dbInactiveSuffixList, SetdbInactiveSuffixList] = useState([]);

  const getModuleList = () => {
    const filterData2 = {
      api_token: apiToken,
      userType: userType,
      language: language,
    };
    POST(DbSuffixUrlList, filterData2)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetdbSuffixList(Trans(data.active_data_list, language));
          SetdbInactiveSuffixList(Trans(data.inactive_data_list, language));

          setValueToField();
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    getModuleList();
    return () => abortController.abort(); //getModuleList();
  }, []);

  console.log(dbSuffixList);

  // return (
  //   <Content>
  //     <div className="col-sm-12 col-lg-12">
  //       <CheckPermission
  //         PageAccess={Dbupdate}
  //         PageAction={PreView}>
  //         <div
  //           className="card"
  //           id="custom-user-list">
  //           <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
  //             <h6 className="tx-uppercase tx-semibold mg-b-0">
  //               {Trans("DB_HISTORY", language)}
  //             </h6>
  //             <div className=" d-md-flex">
                   
  //                     <Anchor
  //                       path={WebsiteLink(
  //                         `/db-update/create`
  //                       )}
  //                       className="btn  btn-sm btn-bg btn-xs btn-icon">
  //                       {Trans("ADD_DB", language)}
  //                     </Anchor>
  //                   </div>
  //           </div>
  //           <div className="card-body">
  //             {/* {error.status && (
  //                   <Alert
  //                     variant={error.type}
  //                     onClose={() =>
  //                       setError({ status: false, msg: "", type: "" })
  //                     }
  //                     dismissible
  //                   >
  //                     {error.msg}
  //                   </Alert>
  //                 )} */}
  //             <form
  //               action="#"
  //               onSubmit={handleSubmit(onSubmit)}
  //               noValidate>
  //               <Row>
  //                 <Col col={6}>
  //                   <FormGroup mb="20px">
  //                     <Input
  //                       id={Trans("DB_PREFIX", language)}
  //                       label={Trans("DB_PREFIX", language)}
  //                       placeholder={Trans("DB_PREFIX", language)}
  //                       className="form-control"
  //                       {...register("db_prefix")}
  //                     />
  //                   </FormGroup>
  //                 </Col>
  //                 <Col col={12}>
  //                   <fieldset className="form-fieldset">
  //                     <legend>{Trans("ACTIVE", language)}</legend>
  //                     <Row>
  //                       {dbSuffixList.length > 0 &&
  //                         dbSuffixList.map((cat, idx) => {
  //                           const { db_suffix, subscription_id } = cat;
  //                           return (
  //                             <Col
  //                               col={1}
  //                               className="mb-1">
  //                               <Checkbox
  //                                 id={subscription_id}
  //                                 label={db_suffix}
  //                                 className="custom-control-input"
  //                                 {...register("db_name", {
  //                                   // required: Trans("DB_NAME_REQUIRED", language),
  //                                 })}
  //                                 defaultValue={db_suffix}
  //                               />
  //                               <span className="required">
  //                                 <ErrorMessage
  //                                   errors={errors}
  //                                   name="db_name"
  //                                 />
  //                               </span>
  //                             </Col>
  //                           );
  //                         })}
  //                     </Row>
  //                   </fieldset>
  //                 </Col>

  //                 <Col col={12}>
  //                   <fieldset className="form-fieldset">
  //                     <legend>{Trans("INACTIVE", language)}</legend>
  //                     <Row>
  //                       {dbInactiveSuffixList.length > 0 &&
  //                         dbInactiveSuffixList.map((cat, idx) => {
  //                           const { db_suffix, subscription_id } = cat;
  //                           return (
  //                             <Col
  //                               col={1}
  //                               className="mb-1">
  //                               <Checkbox
  //                                 id={subscription_id}
  //                                 label={db_suffix}
  //                                 className="custom-control-input"
  //                                 {...register("db_name", {
  //                                   // required: Trans("DB_NAME_REQUIRED", language),
  //                                 })}
  //                                 defaultValue={db_suffix}
  //                               />
  //                               <span className="required">
  //                                 <ErrorMessage
  //                                   errors={errors}
  //                                   name="db_name"
  //                                 />
  //                               </span>
  //                             </Col>
  //                           );
  //                         })}
  //                     </Row>
  //                   </fieldset>
  //                 </Col>

  //                 {/* {dbSuffixList.length > 0 &&
  //                                       dbSuffixList.map((cat, idx) => {
  //                                           const {
  //                                               db_suffix,
  //                                               subscription_id
  //                                           } = cat;
  //                                           return (<Col col={1} className="mb-1">


  //                                               <Checkbox
  //                                                   id={subscription_id}
  //                                                   label={db_suffix}
  //                                                   className="custom-control-input"
  //                                                   {...register("db_name", {
  //                                                       // required: Trans("DB_NAME_REQUIRED", language),
  //                                                   })}
  //                                                   defaultValue={db_suffix}
  //                                               />
  //                                               <span className="required">
  //                                                   <ErrorMessage errors={errors} name="db_name" />
  //                                               </span>


  //                                           </Col>
  //                                           );

  //                                       })} */}

  //                 <Col
  //                   col={12}
  //                   className="mt-1">
  //                   <FormGroup mb="20px">
  //                     <TextArea
  //                       id={Trans("QUERY", language)}
  //                       label={Trans("QUERY", language)}
  //                       placeholder={Trans("QUERY", language)}
  //                       className="form-control"
  //                       {...register(`query`)}
  //                     />
  //                   </FormGroup>
  //                 </Col>

  //                 <Col col={4}>
  //                   <LoaderButton
  //                     formLoadStatus={formloadingStatus}
  //                     btnName={Trans("SUBMIT", language)}
  //                     className="btn btn-sm btn-bg btn-block"
  //                   />
  //                 </Col>
  //               </Row>
  //             </form>
  //           </div>


  //         </div>
  //       </CheckPermission>
  //     </div>
  //   </Content>
  // );




  return (
    <Content>
      {/* <CheckPermission PageAccess={BannerSetting} PageAction={PreView}> */}
        <>


          <div className="row row-xs">
            <div className="col-sm-12 col-lg-12">
                <div className="card" id="custom-user-list">
                  {/* CARD HEADER */}

                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
              <h6 className="tx-uppercase tx-semibold mg-b-0">
                {Trans("DB_HISTORY", language)}
              </h6>
              <div className=" d-md-flex">
                   
                      <Anchor
                        path={WebsiteLink(
                          `/db-update/create`
                        )}
                        className="btn  btn-sm btn-bg btn-xs btn-icon">
                        {Trans("ADD_DB", language)}
                      </Anchor>
                    </div>
            </div>

                  {/* END CARD HEADER */}
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">
                      <Col col={12}>
                        <div className="table-responsive">
                          <table className="table">
                            <thead>
                              <tr>
                                <th>{Trans("SL_NO", language)}</th>
                                <th>{Trans("NAME", language)}</th>
                                <th>{Trans("STATUS", language)}</th>
                                <th className="text-center">
                                  {Trans("ACTION", language)}
                                </th>
                              </tr>
                            </thead>
                            {/* <tbody>
                              {sectionListing &&
                                sectionListing.map((banner, idx) => {
                                  return (
                                    <tr key={idx}>
                                      <td>{idx + 1}</td>
                                      <td>{banner.group_name}</td>
                                      <td>
                                        <BadgeShow
                                          type={
                                            banner.status
                                              ? "active"
                                              : "deactive"
                                          }
                                          content={
                                            banner.status
                                              ? "active"
                                              : "deactive"
                                          }
                                        />{" "}
                                      </td>
                                      <td className="text-center">
                                        {userType !== "subscriber" && (

                                          <CheckPermission PageAccess={BannerSetting} PageAction={PreUpdate}>

                                            <IconButton
                                              color="primary"
                                              onClick={() =>
                                                editFunction(
                                                  banner?.banners_group_id
                                                )
                                              }
                                            >
                                              <FeatherIcon
                                                icon="edit-2"

                                                fill="white"
                                                onClick={() =>
                                                  editFunction(
                                                    banner?.banners_group_id
                                                  )
                                                }
                                              />
                                            </IconButton>
                                          </CheckPermission>

                                        )}
                                        <Anchor
                                          color="primary"
                                          path={WebsiteLink(
                                            `${bannerSetting}/${banner?.banners_group_id}`
                                          )}
                                          className="btn btn-primary btn-xs btn-icon"
                                        >
                                          <FeatherIcon icon="eye"
                                          />
                                        </Anchor>
                                        {"  "}


                                        <IconButton
                                          color="primary"
                                          onClick={() =>
                                            changeStatus(
                                              banner?.banners_group_id
                                            )
                                          }
                                        >
                                          <FeatherIcon
                                            icon="repeat"
                                            fill="white"
                                            onClick={() =>
                                              changeStatus(
                                                banner?.banners_group_id
                                              )
                                            }
                                          />
                                        </IconButton>
                                        {"  "}


                                      </td>
                                    </tr>
                                  );
                                })}

                              {sectionListing.length === 0 ? (
                                <tr>
                                  <td
                                    colSpan={4}
                                  >
                                    <h6 className="text-center mb-0 py-1"> {Trans(
                                      "NOT_FOUND_CHOOSE_BANNER_GROUP",
                                      language
                                    )}</h6>            </td>
                                </tr>
                              ) : null}
                            </tbody> */}
                          </table>
                        </div>
                      </Col>
                    </div>
                  )}
                </div>
            </div>
          </div>
        </>
      {/* </CheckPermission> */}

   
      {/* end end modal */}
    </Content>
  );






};

export default Index;
