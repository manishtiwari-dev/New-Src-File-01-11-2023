import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { Dbupdate, PreAdd, PreView } from "config/PermissionName";
import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { useForm } from "react-hook-form";
import {
  SectionUserUrl,
  SectionSelectUrl,
  DbSuffixStoreUrl,
  DbSuffixUrlList,
} from "config/index";
import { DbHistory } from "config/WebsiteUrl";
import { useNavigate } from "react-router-dom";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  Checkbox,
  Label,
} from "component/UIElement/UIElement";
import { Alert, Tab, Tabs } from "react-bootstrap";
import { ErrorMessage } from "@hookform/error-message";
import MyEditor from "component/MyEditor";
import Select from "react-select";

const Create = (props) => {
  const { apiToken, language, userType, quickSectionList, themeColor } =
    useSelector((state) => state.login);

  const navigate = useNavigate();

  const [key, setKey] = useState("en");
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
    getValues,
  } = useForm();

  const quick = [];
  const nesw = [];

  {
    quickSectionList &&
      JSON.parse(quickSectionList).map((menu, index) => {
        //quick.push();
        quick.push({
          label: Trans(menu.section_name, language),
          value: menu.section_id,
        });
      });
  }

  console.log(quick);

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    //saveFormData.quick_access = quick;

    //console.log(saveFormData.theme_color);

    // saveFormData.quickSectionList = JSON.stringify(quickSectionList);
    // console.log(formData.quickSectionList);
    // localStorage.setItem("quickSectionList", JSON.stringify(quick));

    //  localStorage.setItem("themeColor", saveFormData.theme_color);

    POST(DbSuffixStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });

          // props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
        SetformloadingStatus(false);
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [webfunctionSelected, SetwebfunctionSelected] = useState();

  const [editInfo, SeteditInfo] = useState("");

  const setValueToField = () => {
    const editInfo = {
      api_token: apiToken,
    };
    POST(SectionSelectUrl, editInfo)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SeteditInfo(data);
          console.log(data);

          const fieldList = getValues();
          for (const key in fieldList) {
            setValue(key, data[key]);
          }
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        Notify(false, Trans(error.message, language));
      });
  };

  const [dbSuffixList, SetdbSuffixList] = useState([]);
  const [dbInactiveSuffixList, SetdbInactiveSuffixList] = useState([]);

  const getModuleList = () => {
    const filterData2 = {
      api_token: apiToken,
      userType: userType,
      language: language,
    };
    POST(DbSuffixUrlList, filterData2)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetdbSuffixList(Trans(data.active_data_list, language));
          SetdbInactiveSuffixList(Trans(data.inactive_data_list, language));

          setValueToField();
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    getModuleList();
    return () => abortController.abort(); //getModuleList();
  }, []);

  console.log(dbSuffixList);

  return (
    <Content>
      <div className="col-sm-12 col-lg-12">
        <CheckPermission
          PageAccess={Dbupdate}
          PageAction={PreView}>
          <div
            className="card"
            id="custom-user-list">
            <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
              <h6 className="tx-uppercase tx-semibold mg-b-0">
                {Trans("DB_UPDATE", language)}
              </h6>
              <div className=" d-md-flex">
                   
              <Anchor
                  className="btn btn-sm btn-bg pd-3"
                  path={WebsiteLink(DbHistory)}
                >
                  <FeatherIcon
                  //  icon="corner-down-left"
                    className="wd-10 mg-r-5"
                  />
                  {Trans("GO_BACK", language)}
                </Anchor>
                  
                    </div>
            </div>
            <div className="card-body">
              {/* {error.status && (
                    <Alert
                      variant={error.type}
                      onClose={() =>
                        setError({ status: false, msg: "", type: "" })
                      }
                      dismissible
                    >
                      {error.msg}
                    </Alert>
                  )} */}
              <form
                action="#"
                onSubmit={handleSubmit(onSubmit)}
                noValidate>
                <Row>
                  <Col col={6}>
                    <FormGroup mb="20px">
                      <Input
                        id={Trans("DB_PREFIX", language)}
                        label={Trans("DB_PREFIX", language)}
                        placeholder={Trans("DB_PREFIX", language)}
                        className="form-control"
                        {...register("db_prefix")}
                      />
                    </FormGroup>
                  </Col>
                  <Col col={12}>
                    <fieldset className="form-fieldset">
                      <legend>{Trans("ACTIVE", language)}</legend>
                      <Row>
                        {dbSuffixList.length > 0 &&
                          dbSuffixList.map((cat, idx) => {
                            const { db_suffix, subscription_id } = cat;
                            return (
                              <Col
                                col={1}
                                className="mb-1">
                                <Checkbox
                                  id={subscription_id}
                                  label={db_suffix}
                                  className="custom-control-input"
                                  {...register("db_name", {
                                    // required: Trans("DB_NAME_REQUIRED", language),
                                  })}
                                  defaultValue={db_suffix}
                                />
                                <span className="required">
                                  <ErrorMessage
                                    errors={errors}
                                    name="db_name"
                                  />
                                </span>
                              </Col>
                            );
                          })}
                      </Row>
                    </fieldset>
                  </Col>

                  <Col col={12}>
                    <fieldset className="form-fieldset">
                      <legend>{Trans("INACTIVE", language)}</legend>
                      <Row>
                        {dbInactiveSuffixList.length > 0 &&
                          dbInactiveSuffixList.map((cat, idx) => {
                            const { db_suffix, subscription_id } = cat;
                            return (
                              <Col
                                col={1}
                                className="mb-1">
                                <Checkbox
                                  id={subscription_id}
                                  label={db_suffix}
                                  className="custom-control-input"
                                  {...register("db_name", {
                                    // required: Trans("DB_NAME_REQUIRED", language),
                                  })}
                                  defaultValue={db_suffix}
                                />
                                <span className="required">
                                  <ErrorMessage
                                    errors={errors}
                                    name="db_name"
                                  />
                                </span>
                              </Col>
                            );
                          })}
                      </Row>
                    </fieldset>
                  </Col>

                  {/* {dbSuffixList.length > 0 &&
                                        dbSuffixList.map((cat, idx) => {
                                            const {
                                                db_suffix,
                                                subscription_id
                                            } = cat;
                                            return (<Col col={1} className="mb-1">


                                                <Checkbox
                                                    id={subscription_id}
                                                    label={db_suffix}
                                                    className="custom-control-input"
                                                    {...register("db_name", {
                                                        // required: Trans("DB_NAME_REQUIRED", language),
                                                    })}
                                                    defaultValue={db_suffix}
                                                />
                                                <span className="required">
                                                    <ErrorMessage errors={errors} name="db_name" />
                                                </span>


                                            </Col>
                                            );

                                        })} */}

                  <Col
                    col={12}
                    className="mt-1">
                    <FormGroup mb="20px">
                      <TextArea
                        id={Trans("QUERY", language)}
                        label={Trans("QUERY", language)}
                        placeholder={Trans("QUERY", language)}
                        className="form-control"
                        {...register(`query`)}
                      />
                    </FormGroup>
                  </Col>

                  <Col col={4}>
                    <LoaderButton
                      formLoadStatus={formloadingStatus}
                      btnName={Trans("SUBMIT", language)}
                      className="btn btn-sm btn-bg btn-block"
                    />
                  </Col>
                </Row>
              </form>
            </div>
          </div>
        </CheckPermission>
      </div>
    </Content>
  );
};

export default Create;
