import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Content from "layouts/content";
import { roleUrl, deleteRoleUrl, RoleSortOrderUrl } from "config";
import Create from "./create";
import Edit from "./Edit";
import Loading from "component/Preloader";
import Pagination from "component/pagination/index";
import SearchBox from "component/SearchBox";
import RecordPerPage from "component/RecordPerPage";
import { Col, BadgeShow, Anchor, IconButton } from "component/UIElement/UIElement";
import FeatherIcon from "feather-icons-react";
import { PageRole, PreAdd, PreView, PreExport } from "config/PermissionName";
import { Modal, Button, Row } from "react-bootstrap";
import Notify from "component/Notify";
import View from "./view";

function Index() {
  const { apiToken, language } = useSelector((state) => state.login);
  const [rolelist, SetRoleList] = useState([]);

  const [Pagi, SetPagi] = useState(0);
  const [currPage, SetcurrPage] = useState(0);
  const [searchItem, SetSEarchItem] = useState("");
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");
  const [perPageItem, SetPerPageItem] = useState(10);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const showColumn = [
    { label: Trans("SL_NO", language), field: "sl_no", sort: true },
    { label: Trans("NAME", language), field: "roles_name", sort: true },
    {
      label: Trans("PERMISSION", language),
      field: "permissionList",
      sort: false,
    },
    {
      label: Trans("ACTION", language),
      field: "action",
      action_list: ["edit_fun", "delete"],
      sort: false,
    },
  ];



  const getUser = (pagev, perPageItem, searchData, sortBys, OrderBy) => {
    const filterData = {
      api_token: apiToken,
      page: pagev,
      perPage: perPageItem,
      search: searchData,
      sortBy: sortBys,
      orderBY: OrderBy,
    };
    POST(roleUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetRoleList(data.data);
          SetPagi(data.total_page);
          SetcurrPage(data.current_page);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };




  const UpdateOrderStatus = (update_id, sortOrder) => {
    const editData = {
      api_token: apiToken,
      roles_id: update_id,
      sort_order: sortOrder,
    };
    POST(RoleSortOrderUrl, editData)
      .then((response) => {
        const { message } = response.data;
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  const deleteRole = (roleID) => {
    const editData = {
      api_token: apiToken,
      deleteId: roleID,
    };
    POST(deleteRoleUrl, editData)
      .then((response) => {
        const { message } = response.data;
        filterItem("refresh", "", "");
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  const [EditRoleID, SetEditRoleID] = useState();

  const editRoleTe = (roleId) => {
    SeteditShow(true);
    SetEditRoleID(roleId);
  };

  const filterItem = (name, value, other) => {
    switch (name) {
      case "perpage":
        SetloadingStatus(true);
        const per = Number(value);
        SetPerPageItem(per);
        getUser(1, per, searchItem, sortByS, orderByS);
        break;
      case "searchbox":
        SetSEarchItem(value);
        getUser(1, perPageItem, value, sortByS, orderByS);
        break;
      case "sortby":
        SetOrderByS(other);
        SetsortByS(value);
        getUser(1, perPageItem, searchItem, value, other);
        break;
      case "pagi":
        SetcurrPage(value);
        getUser(value, perPageItem, searchItem, sortByS, orderByS);
        break;
      default:
        getUser(currPage, perPageItem, searchItem, sortByS, orderByS);
        break;
    }
  };

  // useEffect(() => {
  //   document.title = "Role | WorkerMan";
  //   getUser(1, perPageItem, searchItem, sortByS, orderByS);
  //   return () => {
  //     getUser(1, perPageItem, searchItem, sortByS, orderByS);
  //   };
  // }, []);

  useEffect(() => {
    document.title = "Role | WorkerMan";
    // let abortController = new AbortController();

    getUser(1, perPageItem, searchItem, sortByS, orderByS);
    return () => {
      getUser(1, perPageItem, searchItem, sortByS, orderByS);
    };
  }, []);


  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);
  const [editShow, SeteditShow] = useState(false);
  const edithandleModalClose = () => SeteditShow(false);

  const viewFunction = (view_id) => {
    SetEditRoleID(view_id);
    SetViewModalShow(true);
  };
  const [viewModalShow, SetViewModalShow] = useState(false);
  const handleviewClose = () => SetViewModalShow(false);



  const viewFun = (editId) => {
    viewFunction(editId);
  };


  let rowId = (currPage > 1) ? (currPage - 1) * perPageItem : 0;



  return (
    <>
      <Content>

        <div className="row row-xs">
          <div className="col-sm-12 col-lg-12">
            <CheckPermission PageAccess={PageRole} PageAction={PreView}>
              <div className="card">
                <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                  <h6 className=" tx-semibold mg-b-0">
                    {Trans("ROLE", language)}
                  </h6>
                  <div className="d-md-flex">
                    <CheckPermission PageAccess={PageRole} PageAction={PreAdd}>
                      <Button  
                    //  variant=""
                    //  className="btn-sm btn-bg"
                      style={{backgroundColor:"#ffce00",borderColor:"#ffce00",color:"#000"}}
                        onClick={handleModalShow}>
                        <FeatherIcon
                            icon="plus"
                          fill="white"
                          className="wd-10 mg-r-5"
                        />
                        {Trans("CREATE_ROLE", language)}
                      </Button>


                    </CheckPermission>
                  </div>
                </div>


                <div className="card-body">
                  <div className="d-flex">

                    <div className="">
                      <RecordPerPage
                        filterItem={filterItem}
                        perPageItem={perPageItem}
                      />
                    </div>
                    <div className="mx-3">
                      <SearchBox filterItem={filterItem} />
                    </div>

                  </div>
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">
                      <Row>
                        <Col col={12}>
                          <div className="table-responsive">
                            <table className="table">
                              <thead>
                                <tr>
                                  <th>{Trans("SL_NO", language)}</th>
                                  <th className="text-center">
                                    {Trans("NAME", language)}
                                  </th>
                                  <th className="text-center">
                                    {Trans("NUMBER_OF_USERS", language)}
                                  </th>

                                  <th className="text-center">
                                    {Trans("SORT_ORDER", language)}
                                  </th>
                                  <th className="text-center">
                                    {Trans("ACTION", language)}
                                  </th>
                                  {/* <th className="text-center">
                                    {Trans("PERMISSION", language)}
                                  </th> */}
                                </tr>
                              </thead>
                              <tbody>
                                {rolelist &&
                                  rolelist.map((role, idx) => {
                                    rowId++;
                                    return (
                                      <tr key={idx}>
                                        <td>{rowId}</td>
                                        <td className="text-center">
                                          {role.roles_name}
                                        </td>
                                        <td className="text-center">
                                          {role.userCount}
                                        </td>

                                        <td className="text-center">
                                          <input
                                            type="number"
                                            name=""
                                            id=""
                                            defaultValue={role.sort_order}

                                            style={{ width: "50px", 'text-align': "center" }}
                                            onBlur={(e) => {
                                              UpdateOrderStatus(
                                                role.roles_id,
                                                e.target.value
                                              );
                                            }}
                                          />
                                        </td>
                                        <td className="text-center">
                                          {role.is_editable === 1 && (



                                            <Button variant="" 
                                           
                                               className="btn btn-sm  table_btn py-1 px-2"
                                              onClick={() =>
                                                editRoleTe(role?.roles_id)
                                              }
                                            >
                                              <FeatherIcon
                                                icon="edit-2"

                                                fill="white"
                                                onClick={() =>
                                                  editRoleTe(role?.roles_id)
                                                }
                                              />

                                            </Button>



                                          )}

                                          {" "}
                                          {/* <IconButton
                              color="primary"
                              onClick={() => viewFun(role?.roles_id)}
                            >
                              <FeatherIcon
                                icon="eye"
                                size={20}
                                onClick={() => viewFun(role?.roles_id)}
                              />
                            </IconButton>{" "} */}
                                        </td>


                                      </tr>
                                    );
                                  })}

                                {rolelist.length === 0 ? (
                                  <tr>
                                    <td colSpan={6} className="text-center">
                                      {Trans(
                                        "NOT_FOUND",
                                        language
                                      )}
                                    </td>
                                  </tr>
                                ) : null}
                              </tbody>
                            </table>
                          </div>
                        </Col>
                      </Row>
                    </div>
                  )}
                </div>
              </div>
            </CheckPermission>
          </div>
          <Modal show={editShow} onHide={edithandleModalClose} size={"lg"}>
            <Modal.Header>
              <Modal.Title>{Trans("EDIT_ROLE", language)}</Modal.Title>
              <Button variant="danger" onClick={edithandleModalClose}>
                X
              </Button>
            </Modal.Header>
            <Modal.Body>
              <Edit
                filterItem={filterItem}
                handleModalClose={edithandleModalClose}
                editId={EditRoleID}
              />
            </Modal.Body>
          </Modal>
        </div>

        {/* add modal */}
        <Modal show={show} onHide={handleModalClose} size={"lg"}>
          <Modal.Header>
            <Modal.Title>{Trans("CREATE_ROLE", language)}</Modal.Title>
            <Button variant="danger" onClick={handleModalClose}>
              X
            </Button>
          </Modal.Header>
          <Modal.Body>
            <Create
              filterItem={filterItem}
              handleModalClose={handleModalClose}
              checkedPermission={[]}
            />
          </Modal.Body>
        </Modal>
        {/* end end modal */}
        {/* end end modal */}
        <Modal show={viewModalShow} onHide={handleviewClose} size="lg">
          <Modal.Header>
            <Modal.Title>{Trans("PERMISSION_INFO", language)}</Modal.Title>
            <Button variant="danger" onClick={handleviewClose}>
              X

            </Button>
          </Modal.Header>
          <Modal.Body>
            <View
              editId={EditRoleID}
              filterItem={filterItem}

              handleModalClose={handleviewClose}
            />
          </Modal.Body>
        </Modal>
      </Content>
    </>
  );
}

export default Index;
