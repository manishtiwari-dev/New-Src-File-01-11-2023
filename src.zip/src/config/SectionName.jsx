export const generalSetting = "General Setting";
export const paymentSetting = "Payment Setting";
export const paymentTerm = "Payment Term";
