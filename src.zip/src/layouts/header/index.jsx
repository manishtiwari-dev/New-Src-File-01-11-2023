

import React from "react";
import Moment from "react-moment";
import { useSelector, useDispatch } from "react-redux";
import { ApplicationDomain } from "config/StaticKey";
import { GetKeyValue } from "global/GetKeyValue";


function Index() {
  const date = new Date();
  const { isAuthenticated, superSettingInfo } = useSelector(
    (state) => state.login
  );

  return (
    <header className={isAuthenticated ? "header" : "header ml-0"}>
      <div>
        <span>
          @ <Moment format="YYYY">{date}</Moment>{" "}
          {GetKeyValue(ApplicationDomain, superSettingInfo)
            ? GetKeyValue(ApplicationDomain, superSettingInfo)
            : "WorkerMan"}
        </span>
      </div>
    </header>
  );
}

export default Index;
