import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import FeatherIcon from "feather-icons-react";
import POST from "axios/post";
import { Image, Anchor } from "component/UIElement/UIElement";
import { notificationUrl, notificationReadStatusUrl } from "config";
import Moment from "react-moment";

function ClockIn() {
  const [notificationList, SetnotificationList] = useState([]);
  const [notificationCount, SetNotificationCount] = useState(0);
  const { apiToken } = useSelector((state) => state.login);


  return (
    
     
     <div id="clock">
            <p
                className="mb-0 text-lg-right text-md-right f-18 font-weight-bold text-dark-grey d-grid align-items-center">
                {/* <input type="hidden" id="current-latitude" value="{{ $userdataList->locationData->latitude }}"
                    name="current_latitude">
                <input type="hidden" id="current-longitude" value="{{ $userdataList->locationData->longitude }}"
                    name="current_longitude"> */}
            
                    <span className="f-11 font-weight-normal text-lightest">

                    </span>
              
            </p>

         
                <a href="#clock-in" data-bs-toggle="modal" className="btn btn-primary btn-bg"><i
                        data-feather="log-in"></i>Clock
                    In</a>
          

        
                <a href="#clock" id="clock-out" data-bs-toggle="modal" className="btn btn-sm btn-danger"><i
                        data-feather="log-in"></i>Clock
                    Out</a>
            

        </div> 


  );
}

export default ClockIn;
